# No custom rules required for the current non-minified release build.
