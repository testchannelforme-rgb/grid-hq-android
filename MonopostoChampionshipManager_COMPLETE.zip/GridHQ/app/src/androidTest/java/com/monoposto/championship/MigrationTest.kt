package com.monoposto.championship

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.monoposto.championship.data.*
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class MigrationTest {
    @Test fun versionOneDataSurvivesMigrationAndV2Save() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val name = "migration-${System.nanoTime()}.db"
        val path = context.getDatabasePath(name); path.parentFile!!.mkdirs()
        SQLiteDatabase.openOrCreateDatabase(path, null).use { db ->
            db.execSQL("CREATE TABLE championships (id INTEGER NOT NULL PRIMARY KEY, name TEXT NOT NULL, season TEXT NOT NULL, fastestLapPoints INTEGER NOT NULL)")
            db.execSQL("CREATE TABLE teams (championshipId INTEGER NOT NULL, id INTEGER NOT NULL, name TEXT NOT NULL, abbreviation TEXT NOT NULL, colorArgb INTEGER NOT NULL, PRIMARY KEY(championshipId,id), FOREIGN KEY(championshipId) REFERENCES championships(id) ON DELETE CASCADE)")
            db.execSQL("CREATE TABLE drivers (championshipId INTEGER NOT NULL, id INTEGER NOT NULL, name TEXT NOT NULL, number INTEGER NOT NULL, abbreviation TEXT NOT NULL, teamId INTEGER NOT NULL, PRIMARY KEY(championshipId,id), FOREIGN KEY(championshipId) REFERENCES championships(id) ON DELETE CASCADE)")
            db.execSQL("CREATE TABLE races (championshipId INTEGER NOT NULL, id INTEGER NOT NULL, round INTEGER NOT NULL, name TEXT NOT NULL, PRIMARY KEY(championshipId,id), FOREIGN KEY(championshipId) REFERENCES championships(id) ON DELETE CASCADE)")
            db.execSQL("CREATE TABLE results (championshipId INTEGER NOT NULL, raceId INTEGER NOT NULL, driverId INTEGER NOT NULL, finishPosition INTEGER, status TEXT NOT NULL, points INTEGER NOT NULL, fastestLap INTEGER NOT NULL, PRIMARY KEY(championshipId,raceId,driverId), FOREIGN KEY(championshipId) REFERENCES championships(id) ON DELETE CASCADE)")
            db.execSQL("CREATE TABLE scoring (championshipId INTEGER NOT NULL, position INTEGER NOT NULL, points INTEGER NOT NULL, PRIMARY KEY(championshipId,position), FOREIGN KEY(championshipId) REFERENCES championships(id) ON DELETE CASCADE)")
            listOf("teams", "drivers", "races", "results", "scoring").forEach { db.execSQL("CREATE INDEX index_${it}_championshipId ON $it(championshipId)") }
            db.execSQL("CREATE INDEX index_results_championshipId_raceId ON results(championshipId,raceId)")
            db.execSQL("INSERT INTO championships VALUES(1,'Old championship','2026',1)")
            for (i in 1..12) db.execSQL("INSERT INTO teams VALUES(1,?,'Team','T',0)", arrayOf(i))
            for (i in 1..24) {
                db.execSQL("INSERT INTO drivers VALUES(1,?,'Driver',?,'D',?)", arrayOf(i, i, (i - 1) / 2 + 1))
                db.execSQL("INSERT INTO scoring VALUES(1,?,?)", arrayOf(i, ScoringRules().positionPoints[i - 1]))
                db.execSQL("INSERT INTO results VALUES(1,1,?,?,'FINISHED',?,0)", arrayOf(i, i, ScoringRules().positionPoints[i - 1]))
            }
            db.execSQL("INSERT INTO races VALUES(1,1,1,'Round One')")
            db.version = 1
        }
        val database = Room.databaseBuilder(context, ChampionshipDatabase::class.java, name).addMigrations(ChampionshipDatabase.MIGRATION_1_2).build()
        try {
            val repository = ChampionshipRepository(database)
            val old = repository.loadAll().single()
            assertEquals(24, old.drivers.size); assertEquals(12, old.teams.size)
            assertEquals(24, old.races.single().results.size); assertEquals(25, old.races.single().results.first { it.driverId == 1 }.points)
            assertFalse(old.developmentEnabled); assertEquals("", old.races.single().notes)
            repository.save(old.copy(races = old.races.map { it.copy(notes = "Migration kept my season") }))
            val updated = repository.loadAll().single()
            assertEquals("Migration kept my season", updated.races.single().notes)
            assertEquals(old.races.single().results, updated.races.single().results)
            try { repository.save(old); fail("Stale save must fail") } catch (_: IllegalArgumentException) { }
            assertEquals("Migration kept my season", repository.loadAll().single().races.single().notes)
        } finally { database.close(); context.deleteDatabase(name) }
    }
}
