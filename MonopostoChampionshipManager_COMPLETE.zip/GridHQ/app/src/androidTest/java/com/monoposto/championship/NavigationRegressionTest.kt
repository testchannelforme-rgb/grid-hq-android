package com.monoposto.championship

import androidx.compose.runtime.*
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.monoposto.championship.data.*
import com.monoposto.championship.domain.ChampionshipEngine
import com.monoposto.championship.ui.AppTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class NavigationRegressionTest {
    @get:Rule val compose = createComposeRule()
    private fun fixture(): Championship {
        val c = ChampionshipFactory.create("Navigation QA", "2026", 3)
        val results = c.drivers.mapIndexed { i, d -> DriverRaceResult(d.id, i + 1, ResultStatus.FINISHED, teamId = d.teamId) }
        return ChampionshipEngine.recalculateAll(c.copy(races = c.races.map { it.copy(results = results) }))
    }
    @Test fun constructorThenDriverThenRaceWithOverlappingIds() {
        val c = fixture()
        compose.setContent {
            var screen by remember { mutableStateOf("standings") }
            var id by remember { mutableIntStateOf(0) }
            AppTheme {
                when(screen) {
                    "team" -> TeamDetailScreen(c, id) { screen = "standings" }
                    "driver" -> DriverDetailScreen(c, id) { screen = "races" }
                    "race" -> WeekendScreen(c, id, { screen = "standings" }, {})
                    "races" -> RacesScreen(c, { id = it; screen = "race" }, {})
                    else -> StandingsScreen(c, { id = it; screen = "driver" }, { id = it; screen = "team" })
                }
            }
        }
        compose.onNodeWithText("Constructors").performClick()
        compose.onNodeWithText(c.teams[0].name).performClick()
        compose.onNodeWithText("Driver contribution").assertIsDisplayed()
        compose.onNodeWithContentDescription("Back").performClick()
        compose.onNodeWithText("Drivers", useUnmergedTree = true).performClick()
        compose.onNodeWithText(c.drivers[0].name).performClick()
        compose.onNodeWithText("Race-by-race performance").assertIsDisplayed()
        compose.onNodeWithContentDescription("Back").performClick()
        compose.onNodeWithText(c.races[0].name).performClick()
        compose.onNodeWithContentDescription("Back").performClick()
        compose.onNodeWithText("Standings").assertIsDisplayed()
    }
    @Test fun missingConstructorShowsRecoverableState() {
        compose.setContent { AppTheme { TeamDetailScreen(fixture(), -999) {} } }
        compose.onNodeWithText("This entry is no longer available").assertIsDisplayed()
    }
}
