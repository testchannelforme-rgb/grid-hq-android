package com.monoposto.championship.domain

import com.monoposto.championship.data.BackupCodec
import com.monoposto.championship.data.ChampionshipFactory
import com.monoposto.championship.data.ResultStatus
import com.monoposto.championship.data.ScoringRules
import org.junit.Assert.*
import org.junit.Test

class BackupCodecTest {
    @Test fun exportImportRecoversCompleteChampionshipAndCreatesIndependentId() {
        val original0 = ChampionshipFactory.create("2026 Season", "2026", 3).copy(id = 12345L)
        val ids = original0.drivers.map { it.id }
        val results = ChampionshipEngine.normalizeRaceResults(
            original0,
            orderedFinishedDriverIds = ids.dropLast(2),
            dnfDriverIds = setOf(ids[22]),
            dnsDriverIds = setOf(ids[23]),
            fastestLapDriverId = ids[0]
        )
        val original = original0.copy(
            races = original0.races.map { if (it.id == original0.races.first().id) it.copy(results = results) else it },
            scoring = ScoringRules(original0.scoring.positionPoints, 2)
        ).let { ChampionshipEngine.recalculateAll(it) }

        val json = BackupCodec.export(original)
        val restored = BackupCodec.import(json, forceNewId = true)

        assertNotEquals(original.id, restored.id)
        assertEquals(original.name, restored.name)
        assertEquals(original.season, restored.season)
        assertEquals(12, restored.teams.size)
        assertEquals(24, restored.drivers.size)
        assertEquals(3, restored.races.size)
        assertEquals(24, restored.races.first().results.size)
        assertEquals(2, restored.scoring.fastestLapPoints)
        assertEquals(1, restored.races.first().results.count { it.fastestLap })
        assertEquals(1, restored.races.first().results.count { it.status == ResultStatus.DNF })
        assertEquals(1, restored.races.first().results.count { it.status == ResultStatus.DNS })
    }
}
