package com.monoposto.championship.domain

import com.monoposto.championship.data.*
import org.junit.Assert.*
import org.junit.Test
import java.time.*
import kotlin.random.Random

class DailyHighlightsTest {
    @Test fun targetsVaryAndStayInsideWindow() {
        val random = Random(9)
        val targets = List(1000) { DailyHighlights.targetMinute(8, 21, random) }
        assertTrue(targets.all { it in 480 until 1260 })
        assertTrue(targets.distinct().size > 100)
    }
    @Test fun quietHoursAndOnePerLocalDay() {
        val now = ZonedDateTime.of(2026, 9, 24, 12, 30, 0, 0, ZoneId.of("Asia/Kolkata"))
        assertTrue(DailyHighlights.isDue(now, 600, null, 8, 21))
        assertFalse(DailyHighlights.isDue(now, 600, now.toLocalDate(), 8, 21))
        assertFalse(DailyHighlights.isDue(now.withHour(7), 400, null, 8, 21))
        assertFalse(DailyHighlights.isDue(now.withHour(21), 600, null, 8, 21))
        assertFalse(DailyHighlights.isDue(now, 800, null, 8, 21))
        assertTrue(DailyHighlights.isDue(now.plusDays(1), 600, now.toLocalDate(), 8, 21))
    }
    @Test fun missingChampionshipHasHonestEmptyMessage() {
        val result = DailyHighlights.build(null, LocalDate.of(2026, 1, 1))
        assertNull(result.championshipId)
        assertTrue(result.body.contains("Create"))
    }
    @Test fun freshRaceResultsAndDeepLink() {
        val c = ChampionshipFactory.create("Test", "2026", 2)
        val results = c.drivers.mapIndexed { i, d -> DriverRaceResult(d.id, i + 1, ResultStatus.FINISHED) }
        val recorded = c.copy(races = c.races.mapIndexed { i, r -> if (i == 1) r.copy(results = results) else r })
        val day = LocalDate.of(2026, 1, 1)
        val before = DailyHighlights.build(recorded, day)
        assertEquals(recorded.races[1].id, before.raceId)
        assertTrue(before.body.contains(c.drivers[0].name))
        val renamed = recorded.copy(drivers = recorded.drivers.mapIndexed { i,d -> if (i == 0) d.copy(name = "Fresh winner") else d })
        assertTrue(DailyHighlights.build(renamed, day).body.contains("Fresh winner"))
    }
    @Test fun missingTeamAndDriverFieldsDegradeGracefully() {
        val c = ChampionshipFactory.create("Test", "2026", 1)
        assertEquals("Unknown driver", c.driverOrPlaceholder(-99).name)
        assertEquals("Unassigned team", c.teamOrPlaceholder(-99).name)
        assertEquals(c.drivers.size, ChampionshipEngine.driverStandings(c.copy(teams = emptyList())).size)
    }
}
