package com.monoposto.championship.domain

import com.monoposto.championship.data.*
import org.junit.Assert.*
import org.junit.Test

class ChampionshipEngineTest {
    private fun base(races: Int = 3) = ChampionshipFactory.create("Test", "2026", races).copy(id = 1L)

    private fun resultRace(c: Championship, race: Race, order: List<Int>, dnfs: Set<Int> = emptySet(), dns: Set<Int> = emptySet(), fastest: Int? = null): Race {
        val finished = order.filterNot { it in dnfs || it in dns }
        val all = c.drivers.map { it.id }.toSet()
        val missing = all - finished.toSet() - dnfs - dns
        return race.copy(results = ChampionshipEngine.normalizeRaceResults(c, finished, dnfs, dns + missing, fastest))
    }

    @Test fun factoryCreatesExactlyTwelveTeamsAndTwentyFourDrivers() {
        val c = base()
        assertEquals(12, c.teams.size)
        assertEquals(24, c.drivers.size)
        c.teams.forEach { team -> assertEquals(2, c.drivers.count { it.teamId == team.id }) }
        assertEquals(24, c.drivers.map { it.number }.distinct().size)
    }

    @Test fun normalizedResultHasUniqueAutomaticPositionsAndStatuses() {
        val c = base(1)
        val all = c.drivers.map { it.id }
        val rr = ChampionshipEngine.normalizeRaceResults(c, all.drop(2), setOf(all[0]), setOf(all[1]), all[2])
        assertEquals(24, rr.size)
        assertEquals(ResultStatus.DNF, rr.first { it.driverId == all[0] }.status)
        assertEquals(ResultStatus.DNS, rr.first { it.driverId == all[1] }.status)
        val pos = rr.mapNotNull { it.finishPosition }
        assertEquals(pos.size, pos.distinct().size)
        assertEquals((1..22).toList(), pos.sorted())
    }

    @Test fun fastestLapPointIsAwarded() {
        val c = base(1)
        val ids = c.drivers.map { it.id }
        val r = resultRace(c, c.races[0], ids, fastest = ids[0])
        val winner = r.results.first { it.driverId == ids[0] }
        assertEquals(26, winner.points)
        assertTrue(winner.fastestLap)
    }

    @Test fun dnfAndDnsScoreZeroPositionPointsAndAreTracked() {
        val c0 = base(1)
        val ids = c0.drivers.map { it.id }
        val race = resultRace(c0, c0.races[0], ids, dnfs = setOf(ids[0]), dns = setOf(ids[1]))
        val c = c0.copy(races = listOf(race))
        val ds = ChampionshipEngine.driverStandings(c).associateBy { it.driver.id }
        assertEquals(1, ds.getValue(ids[0]).dnfs)
        assertEquals(0, ds.getValue(ids[0]).points)
        assertEquals(1, ds.getValue(ids[1]).dns)
        assertEquals(0, ds.getValue(ids[1]).raceStarts)
    }

    @Test fun threeRaceStandingsAndConstructorPointsAreCorrect() {
        val c0 = base(3)
        val ids = c0.drivers.map { it.id }
        val r1 = resultRace(c0, c0.races[0], ids, fastest = ids[0])
        val r2order = ids.toMutableList().also { val x = it.removeAt(1); it.add(0, x) }
        val r2 = resultRace(c0, c0.races[1], r2order, fastest = ids[1])
        val r3 = resultRace(c0, c0.races[2], ids, dnfs = setOf(ids[1]), fastest = ids[0])
        val c = c0.copy(races = listOf(r1, r2, r3))
        val ds = ChampionshipEngine.driverStandings(c).associateBy { it.driver.id }
        assertEquals(26 + 18 + 26, ds.getValue(ids[0]).points)
        assertEquals(18 + 26 + 0, ds.getValue(ids[1]).points)
        val team1 = ChampionshipEngine.teamStandings(c).first { it.team.id == 1 }
        assertEquals(ds.getValue(ids[0]).points + ds.getValue(ids[1]).points, team1.points)
        assertEquals(3, team1.raceSummaries.size)
    }

    @Test fun tieBreakUsesWinsThenSecondPlacesThroughAllPositions() {
        val scoring = ScoringRules(List(24) { if (it < 2) 10 else 0 }, 0)
        val c0 = base(1).copy(scoring = scoring)
        val ids = c0.drivers.map { it.id }
        val order = listOf(ids[1], ids[0]) + ids.drop(2)
        val c = c0.copy(races = listOf(resultRace(c0, c0.races[0], order)))
        val ds = ChampionshipEngine.driverStandings(c)
        assertEquals(10, ds[0].points)
        assertEquals(10, ds[1].points)
        assertEquals(ids[1], ds[0].driver.id) // same points, win beats second place
    }

    @Test fun editingOldRaceRecalculatesChampion() {
        val c0 = base(2)
        val ids = c0.drivers.map { it.id }
        val r1 = resultRace(c0, c0.races[0], ids)
        val r2 = resultRace(c0, c0.races[1], ids)
        val cBefore = c0.copy(races = listOf(r1, r2))
        assertEquals(ids[0], ChampionshipEngine.driverStandings(cBefore).first().driver.id)

        val swapped = ids.toMutableList().also { val x = it.removeAt(1); it.add(0, x) }
        val editedR1 = resultRace(c0, c0.races[0], swapped)
        val editedR2 = resultRace(c0, c0.races[1], swapped)
        val cAfter = c0.copy(races = listOf(editedR1, editedR2))
        assertEquals(ids[1], ChampionshipEngine.driverStandings(cAfter).first().driver.id)
    }

    @Test fun scoringChangeRecalculatesStoredRacePoints() {
        val c0 = base(1)
        val ids = c0.drivers.map { it.id }
        val c1 = c0.copy(races = listOf(resultRace(c0, c0.races[0], ids, fastest = ids[0])))
        assertEquals(26, ChampionshipEngine.driverStandings(c1).first().points)
        val scoring = ScoringRules(List(24) { i -> if (i == 0) 50 else 0 }, 3)
        val c2 = ChampionshipEngine.recalculateAll(c1.copy(scoring = scoring))
        assertEquals(53, ChampionshipEngine.driverStandings(c2).first().points)
    }

    @Test fun seasonStatisticsIncludesRequestedExtremes() {
        val c0 = base(1)
        val ids = c0.drivers.map { it.id }
        val c = c0.copy(races = listOf(resultRace(c0, c0.races[0], ids, dnfs = setOf(ids.last()), fastest = ids[0])))
        val stats = ChampionshipEngine.seasonStatistics(c)
        assertEquals(ids[0], stats.championshipLeader?.driver?.id)
        assertEquals(ids[0], stats.mostFastestLaps?.driver?.id)
        assertEquals(ids.last(), stats.mostDnfs?.driver?.id)
        assertNotNull(stats.highestScoringTeam)
        assertNotNull(stats.lowestScoringTeam)
    }
    @Test fun constructorTieBreakUsesSameFinishCountback() {
        val scoring = ScoringRules(List(24) { if (it < 2) 10 else 0 }, 0)
        val c0 = base(1).copy(scoring = scoring)
        val ids = c0.drivers.map { it.id }
        // Team 1 driver wins, Team 2 driver is second: both teams score 10, so the win decides the tie.
        val order = listOf(ids[0], ids[2]) + ids.filterNot { it == ids[0] || it == ids[2] }
        val c = c0.copy(races = listOf(resultRace(c0, c0.races[0], order)))
        val teams = ChampionshipEngine.teamStandings(c)
        assertEquals(10, teams[0].points)
        assertEquals(10, teams[1].points)
        assertEquals(1, teams[0].team.id)
    }

}
