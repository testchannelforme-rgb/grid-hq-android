package com.monoposto.championship.domain

import com.monoposto.championship.data.*
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class GridHQTest {
    private fun base() = ChampionshipFactory.create("Test", "2026", 3).copy(id = 1)
    private fun results(c: Championship, reverse: Boolean = false): List<DriverRaceResult> {
        val ids = c.drivers.map { it.id }.let { if (reverse) it.reversed() else it }
        return ChampionshipEngine.normalizeRaceResults(c, ids, emptySet(), emptySet(), null)
    }
    private fun weekend(): Championship {
        val c = base()
        return ChampionshipEngine.recalculateAll(c.copy(races = c.races.mapIndexed { i, r -> if (i == 0) r.copy(results = results(c), sprintEnabled = true, sprintResults = results(c.copy(scoring = c.sprintScoring)), notes = "Safety car on lap 5") else r }))
    }
    @Test fun sprintCountsInBothStandingsButNotMainRaceWins() {
        val c = weekend()
        val driver = ChampionshipEngine.driverStandings(c).first()
        assertEquals(33, driver.points); assertEquals(1, driver.wins)
        assertEquals(58, ChampionshipEngine.teamStandings(c).first().points)
    }
    @Test fun sprintOnlyWeekendCountsBeforeMainRace() {
        val c = weekend().let { it.copy(races = it.races.map { r -> r.copy(results = emptyList()) }) }
        assertEquals(8, ChampionshipEngine.driverStandings(c).first().points)
        assertEquals(0, ChampionshipEngine.driverStandings(c).first().wins)
        assertEquals(1, Insights.progression(c, 1, false).size)
    }
    @Test fun deletionRemovesSprintPointsAndLeavesNotes() {
        val c = weekend().let { it.copy(races = it.races.map { r -> r.copy(sprintResults = emptyList()) }) }
        assertEquals(25, ChampionshipEngine.driverStandings(c).first().points)
        assertEquals("Safety car on lap 5", c.races.first().notes)
    }
    @Test fun teamTransferDoesNotReassignRecordedPoints() {
        val c = weekend()
        val swapped = c.copy(drivers = c.drivers.map { when (it.id) { 1 -> it.copy(teamId = 2); 3 -> it.copy(teamId = 1); else -> it } })
        Validation.check(swapped)
        assertEquals(ChampionshipEngine.teamStandings(c).map { it.points }, ChampionshipEngine.teamStandings(swapped).map { it.points })
    }
    @Test fun dnsAndDsqNeverReceiveFastestLapBonus() {
        assertEquals(0, ChampionshipEngine.racePoints(null, ResultStatus.DNS, ScoringRules(), true))
        assertEquals(0, ChampionshipEngine.racePoints(null, ResultStatus.DSQ, ScoringRules(), true))
        assertEquals(0, ChampionshipEngine.racePoints(null, ResultStatus.DNF, ScoringRules(allowDnfFastestLap = false), true))
        assertEquals(0, ChampionshipEngine.racePoints(11, ResultStatus.FINISHED, ScoringRules(fastestLapTop = 10), true))
    }
    @Test fun penaltiesCanProduceNegativePointsAndChartsReflectThem() {
        val c = weekend().let { c -> c.copy(races = c.races.map { r -> r.copy(results = r.results.map { if (it.driverId == 1) it.copy(penalty = 100) else it }) }) }.let(ChampionshipEngine::recalculateAll)
        Validation.check(c)
        assertEquals(-67, Insights.progression(c, 1, false).first().total)
    }
    @Test fun invalidGridRejected() {
        val c = weekend().let { it.copy(races = it.races.map { r -> r.copy(results = r.results.map { rr -> rr.copy(gridPosition = 1) }) }) }
        assertThrows(IllegalArgumentException::class.java) { Validation.check(c) }
    }
    @Test fun duplicateFinishingPositionRejected() {
        val c = weekend().let { it.copy(races = it.races.map { r -> r.copy(results = r.results.map { rr -> rr.copy(finishPosition = 1) }) }) }
        assertThrows(IllegalArgumentException::class.java) { Validation.check(c) }
    }
    @Test fun unknownDriverRejected() {
        val c = weekend().let { it.copy(races = it.races.map { r -> r.copy(results = r.results.map { rr -> if (rr.driverId == 1) rr.copy(driverId = 99) else rr }) }) }
        assertThrows(IllegalArgumentException::class.java) { Validation.check(c) }
    }
    @Test fun backupRoundTripIncludesEveryV2Field() {
        val c = Insights.upgrade(weekend().copy(developmentEnabled = true), 1, DevelopmentArea.CHASSIS).let {
            it.copy(races = it.races.map { r -> r.copy(results = r.results.map { rr -> rr.copy(gridPosition = rr.driverId, penalty = 2) }) })
        }.let(ChampionshipEngine::recalculateAll)
        val restored = BackupCodec.import(BackupCodec.export(c), false)
        Validation.check(restored); assertEquals(c, restored)
    }
    @Test fun v1BackupUsesSafeDefaultsAndHistoricalTeamSnapshot() {
        val root = JSONObject(BackupCodec.export(weekend()))
        root.put("version", 1)
        val c = root.getJSONObject("championship")
        c.remove("sprintScoring"); c.remove("developmentEnabled"); c.remove("upgrades"); c.remove("revision")
        val races = c.getJSONArray("races")
        for (i in 0 until races.length()) {
            val r = races.getJSONObject(i); r.remove("sprintEnabled"); r.remove("sprintResults"); r.remove("notes")
            val rs = r.getJSONArray("results")
            for (j in 0 until rs.length()) { val rr = rs.getJSONObject(j); rr.remove("teamId"); rr.remove("gridPosition"); rr.remove("penalty") }
        }
        val restored = BackupCodec.import(root.toString(), false)
        Validation.check(restored)
        assertFalse(restored.developmentEnabled); assertFalse(restored.races.first().sprintEnabled)
        assertEquals(1, restored.races.first().results.first().teamId)
    }
    @Test fun futureBackupRejected() {
        val root = JSONObject(BackupCodec.export(base())).put("version", 999)
        assertThrows(IllegalArgumentException::class.java) { BackupCodec.import(root.toString()) }
    }
    @Test fun predictionsDeterministicAndNeverChangeResults() {
        val c = weekend(); val copy = c.copy()
        assertEquals(Insights.predictions(c), Insights.predictions(c)); assertEquals(copy, c)
        assertEquals(1, Insights.predictions(c).first().driver.id)
        assertEquals(100.0, Insights.weights.values.sum(), .001)
    }
    @Test fun emptyPredictionHasNoFalseConfidence() {
        val ps = Insights.predictions(base())
        assertTrue(ps.all { it.confidence == "No race data" }); assertEquals(1, ps.first().driver.id)
    }
    @Test fun upgradesRespectBudgetAndNeverChangePoints() {
        val c = weekend().copy(developmentEnabled = true)
        var upgraded = c
        repeat(5) { upgraded = Insights.upgrade(upgraded, 1, DevelopmentArea.POWER) }
        assertEquals(45, upgraded.upgrades.sumOf { it.cost })
        assertThrows(IllegalArgumentException::class.java) { Insights.upgrade(upgraded, 1, DevelopmentArea.POWER) }
        assertEquals(ChampionshipEngine.driverStandings(c), ChampionshipEngine.driverStandings(upgraded))
        assertTrue(Insights.predictions(upgraded).first().score > Insights.predictions(c).first().score)
    }
    @Test fun developmentCannotBeAppliedMidSprintWeekend() {
        val c = weekend().let { it.copy(developmentEnabled = true, races = it.races.map { r -> r.copy(results = emptyList()) }) }
        assertThrows(IllegalArgumentException::class.java) { Insights.upgrade(c, 1, DevelopmentArea.POWER) }
    }
    @Test fun streaksResetOnNonScoringResults() {
        assertEquals(2 to 3, Insights.streak(listOf(true, true, true, false, true, true)))
    }
    @Test fun chartUsesRoundOrderRatherThanListOrder() {
        val c = base().let { it.copy(races = it.races.map { r -> r.copy(results = results(it)) }.reversed()) }
        val p = Insights.progression(c, 1, false)
        assertEquals(listOf(1, 2, 3), p.map { it.round }); assertEquals(listOf(25, 50, 75), p.map { it.total })
    }
    @Test fun resultEditingChangesGraphAndPrediction() {
        val c = weekend(); val edited = c.copy(races = c.races.mapIndexed { i, r -> if (i == 0) r.copy(results = results(c, true)) else r })
        assertNotEquals(Insights.progression(c, 1, false), Insights.progression(edited, 1, false))
        assertNotEquals(Insights.predictions(c), Insights.predictions(edited))
    }
}
