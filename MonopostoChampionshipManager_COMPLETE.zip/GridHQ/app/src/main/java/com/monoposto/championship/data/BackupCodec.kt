package com.monoposto.championship.data

import org.json.JSONArray
import org.json.JSONObject

object BackupCodec {
    const val FORMAT_VERSION = 2

    fun export(championship: Championship): String = JSONObject().apply {
        put("format", "Monoposto Championship Manager")
        put("version", FORMAT_VERSION)
        put("championship", championshipToJson(championship))
    }.toString(2)

    fun import(json: String, forceNewId: Boolean = true): Championship {
        val root = JSONObject(json)
        require(root.optString("format") == "Monoposto Championship Manager") { "Not a supported GridHQ / legacy championship backup." }
        val version = root.optInt("version", -1)
        require(version in 1..FORMAT_VERSION) { "Unsupported backup version: $version" }
        val c = championshipFromJson(root.getJSONObject("championship"))
        return if (forceNewId) c.copy(id = java.util.UUID.randomUUID().mostSignificantBits.and(Long.MAX_VALUE), revision = 0) else c
    }

    private fun championshipToJson(c: Championship) = JSONObject().apply {
        put("id", c.id)
        put("name", c.name)
        put("season", c.season)
        put("revision", c.revision)
        put("developmentEnabled", c.developmentEnabled)
        put("upgrades", JSONArray().apply { c.upgrades.forEach { u -> put(JSONObject().apply {
            put("teamId", u.teamId); put("area", u.area.name); put("level", u.level); put("cost", u.cost); put("afterRound", u.afterRound)
        }) } })
        put("sprintScoring", rulesJson(c.sprintScoring))
        put("scoring", JSONObject().apply {
            put("positionPoints", JSONArray(c.scoring.positionPoints))
            put("fastestLapPoints", c.scoring.fastestLapPoints)
            put("fastestLapTop", c.scoring.fastestLapTop)
            put("allowDnfFastestLap", c.scoring.allowDnfFastestLap)
        })
        put("teams", JSONArray().apply { c.teams.forEach { t -> put(JSONObject().apply {
            put("id", t.id); put("name", t.name); put("abbreviation", t.abbreviation); put("colorArgb", t.colorArgb)
        }) } })
        put("drivers", JSONArray().apply { c.drivers.forEach { d -> put(JSONObject().apply {
            put("id", d.id); put("name", d.name); put("number", d.number); put("abbreviation", d.abbreviation); put("teamId", d.teamId)
        }) } })
        put("races", JSONArray().apply { c.races.forEach { r -> put(JSONObject().apply {
            put("id", r.id); put("round", r.round); put("name", r.name)
            put("sprintEnabled", r.sprintEnabled); put("notes", r.notes)
            put("sprintResults", JSONArray().apply { r.sprintResults.forEach { put(resultJson(it)) } })
            put("results", JSONArray().apply { r.results.forEach { rr -> put(JSONObject().apply {
                put("driverId", rr.driverId)
                put("finishPosition", rr.finishPosition ?: JSONObject.NULL)
                put("status", rr.status)
                put("points", rr.points)
                put("fastestLap", rr.fastestLap)
                put("gridPosition", rr.gridPosition ?: JSONObject.NULL)
                put("teamId", rr.teamId ?: JSONObject.NULL)
                put("penalty", rr.penalty)
            }) } })
        }) } })
    }

    private fun championshipFromJson(o: JSONObject): Championship {
        val scoringObject = o.getJSONObject("scoring")
        val pointsArray = scoringObject.getJSONArray("positionPoints")
        val points = List(DRIVER_COUNT) { i -> if (i < pointsArray.length()) pointsArray.getInt(i) else 0 }
        val teamsArray = o.getJSONArray("teams")
        val teams = List(teamsArray.length()) { i -> teamsArray.getJSONObject(i).let { t ->
            Team(t.getInt("id"), t.getString("name"), t.getString("abbreviation"), t.getInt("colorArgb"))
        } }
        val driversArray = o.getJSONArray("drivers")
        val drivers = List(driversArray.length()) { i -> driversArray.getJSONObject(i).let { d ->
            Driver(d.getInt("id"), d.getString("name"), d.getInt("number"), d.getString("abbreviation"), d.getInt("teamId"))
        } }
        val racesArray = o.getJSONArray("races")
        val races = List(racesArray.length()) { i -> racesArray.getJSONObject(i).let { r ->
            val resultArray = r.getJSONArray("results")
            val results = List(resultArray.length()) { j -> resultArray.getJSONObject(j).let { rr ->
                DriverRaceResult(
                    driverId = rr.getInt("driverId"),
                    finishPosition = if (rr.isNull("finishPosition")) null else rr.getInt("finishPosition"),
                    status = rr.getString("status"),
                    points = rr.getInt("points"),
                    fastestLap = rr.getBoolean("fastestLap"),
                    gridPosition = nullableInt(rr, "gridPosition"),
                    teamId = nullableInt(rr, "teamId") ?: drivers.firstOrNull { it.id == rr.getInt("driverId") }?.teamId,
                    penalty = rr.optInt("penalty", 0)
                )
            } }
            val sprint = r.optJSONArray("sprintResults") ?: JSONArray()
            Race(r.getInt("id"), r.getInt("round"), r.getString("name"), results,
                r.optBoolean("sprintEnabled", false), List(sprint.length()) { resultFromJson(sprint.getJSONObject(it)) }, r.optString("notes", ""))
        } }
        return Championship(
            id = o.getLong("id"),
            name = o.getString("name"),
            season = o.getString("season"),
            races = races,
            teams = teams,
            drivers = drivers,
            scoring = ScoringRules(points, scoringObject.getInt("fastestLapPoints"), scoringObject.optInt("fastestLapTop", 24), scoringObject.optBoolean("allowDnfFastestLap", true)),
            sprintScoring = o.optJSONObject("sprintScoring")?.let { rulesFromJson(it) } ?: ScoringRules(List(24) { if (it < 8) 8 - it else 0 }, 0),
            developmentEnabled = o.optBoolean("developmentEnabled", false),
            upgrades = (o.optJSONArray("upgrades") ?: JSONArray()).let { a -> List(a.length()) { i -> a.getJSONObject(i).let {
                Upgrade(it.getInt("teamId"), DevelopmentArea.valueOf(it.getString("area")), it.getInt("level"), it.getInt("cost"), it.getInt("afterRound"))
            } } },
            revision = o.optLong("revision", 0)
        )
    }

    private fun nullableInt(o: JSONObject, key: String): Int? = if (!o.has(key) || o.isNull(key)) null else o.getInt(key)
    private fun resultJson(r: DriverRaceResult) = JSONObject().apply {
        put("driverId", r.driverId); put("finishPosition", r.finishPosition ?: JSONObject.NULL)
        put("status", r.status); put("points", r.points); put("fastestLap", r.fastestLap)
        put("gridPosition", r.gridPosition ?: JSONObject.NULL); put("teamId", r.teamId ?: JSONObject.NULL); put("penalty", r.penalty)
    }
    private fun resultFromJson(o: JSONObject) = DriverRaceResult(o.getInt("driverId"), nullableInt(o, "finishPosition"), o.getString("status"), o.getInt("points"), o.getBoolean("fastestLap"), nullableInt(o, "gridPosition"), nullableInt(o, "teamId"), o.optInt("penalty", 0))
    private fun rulesJson(r: ScoringRules) = JSONObject().apply {
        put("positionPoints", JSONArray(r.positionPoints)); put("fastestLapPoints", r.fastestLapPoints)
        put("fastestLapTop", r.fastestLapTop); put("allowDnfFastestLap", r.allowDnfFastestLap)
    }
    private fun rulesFromJson(o: JSONObject): ScoringRules {
        val a = o.getJSONArray("positionPoints")
        require(a.length() == 24) { "Scoring must contain 24 positions." }
        return ScoringRules(List(24) { a.getInt(it) }, o.getInt("fastestLapPoints"), o.optInt("fastestLapTop", 24), o.optBoolean("allowDnfFastestLap", true))
    }
}
