@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.monoposto.championship

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.monoposto.championship.data.*
import com.monoposto.championship.domain.ChampionshipEngine
import com.monoposto.championship.ui.*
import java.util.Locale

@Composable
internal fun RacesScreen(c: Championship, onRace: (Int) -> Unit, onSave: (Championship) -> Unit) {
    var showAdd by remember { mutableStateOf(false) }
    var editRace by remember { mutableStateOf<Race?>(null) }
    var deleteRace by remember { mutableStateOf<Race?>(null) }
    Column(Modifier.fillMaxSize()) {
        SectionHeader("Race calendar", "${c.races.count { it.completed }} completed · ${c.races.size} total") {
            FilledTonalIconButton(onClick = { Feedback.emit(); showAdd = true }) { Icon(Icons.Default.Add, "Add race") }
        }
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(c.races.sortedBy { it.round }, key = { _, r -> r.id }) { index, race ->
                RaceCard(c, race, onOpen = { onRace(race.id) }, onEdit = { editRace = race }, onDelete = { deleteRace = race }, onMove = { direction ->
                    val ordered = c.races.sortedBy { it.round }.toMutableList()
                    val target = index + direction
                    if (target in ordered.indices) {
                        val temp = ordered[index]; ordered[index] = ordered[target]; ordered[target] = temp
                        onSave(c.copy(races = ordered.mapIndexed { i, r -> r.copy(round = i + 1) }))
                    }
                })
            }
        }
    }
    if (showAdd) RaceNameDialog(title = "Add race", initial = "Race ${c.races.size + 1}", onDismiss = { showAdd = false }) { name ->
        val nextId = (c.races.maxOfOrNull { it.id } ?: 0) + 1
        onSave(c.copy(races = c.races + Race(nextId, c.races.size + 1, name))); showAdd = false
    }
    editRace?.let { race -> RaceNameDialog(title = "Edit race", initial = race.name, onDismiss = { editRace = null }) { name ->
        onSave(c.copy(races = c.races.map { if (it.id == race.id) it.copy(name = name) else it })); editRace = null
    } }
    deleteRace?.let { race -> ConfirmDialog("Delete ${race.name}?", "Its stored race result will also be removed. Standings will be recalculated.", "Delete", onDismiss = { deleteRace = null }) {
        val newRaces = c.races.filterNot { it.id == race.id }.sortedBy { it.round }.mapIndexed { i, r -> r.copy(round = i + 1) }
        onSave(c.copy(races = newRaces)); deleteRace = null
    } }
}

@Composable
internal fun RaceCard(c: Championship, race: Race, onOpen: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit, onMove: (Int) -> Unit) {
    val ordered = race.results.filter { it.status == ResultStatus.FINISHED }.sortedBy { it.finishPosition }
    val winner = ordered.getOrNull(0)?.let { rr -> c.drivers.firstOrNull { it.id == rr.driverId } }
    val second = ordered.getOrNull(1)?.let { rr -> c.drivers.firstOrNull { it.id == rr.driverId } }
    val third = ordered.getOrNull(2)?.let { rr -> c.drivers.firstOrNull { it.id == rr.driverId } }
    val fastest = race.results.firstOrNull { it.fastestLap }?.let { rr -> c.drivers.firstOrNull { it.id == rr.driverId } }
    Card(Modifier.fillMaxWidth().animateContentSize(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.fillMaxWidth().clickable(onClick = { Feedback.emit(); onOpen() }).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(if (race.completed) MaterialTheme.colorScheme.primary.copy(alpha = .16f) else MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                Text(race.round.toString(), fontWeight = FontWeight.Black, color = if (race.completed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(race.name, fontWeight = FontWeight.Bold)
                if (race.notes.isNotBlank()) Text("Note saved", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                if (race.sprintEnabled) Text(if (race.sprintCompleted) "Sprint recorded" else "Sprint weekend", fontSize = 11.sp)
                if (race.completed) {
                    Text("Completed · Winner: ${winner?.name ?: "—"}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("2nd ${second?.name ?: "—"} · 3rd ${third?.name ?: "—"}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Fastest lap: ${fastest?.name ?: "—"}", fontSize = 10.sp, color = McmGold)
                } else Text("Upcoming", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Row(Modifier.fillMaxWidth().padding(8.dp, 0.dp, 8.dp, 8.dp), horizontalArrangement = Arrangement.End) {
            IconButton(onClick = { Feedback.emit(); onMove(-1) }) { Icon(Icons.Default.KeyboardArrowUp, "Move up") }
            IconButton(onClick = { Feedback.emit(); onMove(1) }) { Icon(Icons.Default.KeyboardArrowDown, "Move down") }
            IconButton(onClick = { Feedback.emit(); onEdit() }) { Icon(Icons.Default.Edit, "Rename") }
            IconButton(onClick = { Feedback.emit(); onDelete() }, enabled = c.races.size > 1) { Icon(Icons.Default.DeleteOutline, "Delete", tint = if (c.races.size > 1) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}

@Composable
internal fun RaceDetailScreen(c: Championship, raceId: Int, onBack: () -> Unit, onSave: (Championship) -> Unit) {
    val race = c.races.firstOrNull { it.id == raceId }
    if (race == null) { MissingDetail("Race unavailable", onBack); return }
    var editing by rememberSaveable(race.id, race.results) { mutableStateOf(!race.completed) }
    var leave by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Column { Text("Round ${race.round}", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary); Text(race.name, fontWeight = FontWeight.Bold) } },
            navigationIcon = { IconButton(onClick = { Feedback.emit(); if (editing) leave = true else onBack() }) { Icon(Icons.Default.ArrowBack, "Back") } },
            actions = { if (race.completed && !editing) IconButton(onClick = { Feedback.emit(); editing = true }) { Icon(Icons.Default.Edit, "Edit result") } },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
        )
        if (editing) RaceEntryEditor(c, race, onCancel = { if (race.completed) editing = false else onBack() }) { result ->
            val updated = c.copy(races = c.races.map { if (it.id == race.id) result else it })
            onSave(updated)
        } else RaceResultView(c, race)
    }
    if (leave) ConfirmDialog("Discard result edits?", "Only saved results will be kept.", "Discard", { leave = false }, onBack)
}

@Composable
internal fun RaceEntryEditor(c: Championship, race: Race, onCancel: () -> Unit, onSave: (Race) -> Unit) {
    val initialFinished = remember(race.id, race.results) {
        if (race.completed) race.results.filter { it.status == ResultStatus.FINISHED }.sortedBy { it.finishPosition }.map { it.driverId }
        else c.drivers.map { it.id }
    }
    val setSaver = androidx.compose.runtime.saveable.listSaver<Set<Int>, Int>(save = { it.toList() }, restore = { it.toSet() })
    val listSaver = androidx.compose.runtime.saveable.listSaver<List<Int>, Int>(save = { it }, restore = { it })
    var finished by rememberSaveable(race.id, race.results, stateSaver = listSaver) { mutableStateOf(initialFinished) }
    var dnf by rememberSaveable(race.id, race.results, stateSaver = setSaver) { mutableStateOf(if (race.completed) race.results.filter { it.status == ResultStatus.DNF }.map { it.driverId }.toSet() else emptySet()) }
    var dns by rememberSaveable(race.id, race.results, stateSaver = setSaver) { mutableStateOf(if (race.completed) race.results.filter { it.status == ResultStatus.DNS }.map { it.driverId }.toSet() else emptySet()) }
    var dsq by rememberSaveable(race.id, race.results, stateSaver = setSaver) { mutableStateOf(race.results.filter { it.status == ResultStatus.DSQ }.map { it.driverId }.toSet()) }
    var fastest by rememberSaveable(race.id, race.results) { mutableStateOf(race.results.firstOrNull { it.fastestLap }?.driverId) }
    var error by remember { mutableStateOf<String?>(null) }
    var discard by remember { mutableStateOf(false) }
    BackHandler { discard = true }
    if (discard) ConfirmDialog("Discard result edits?", "Only saved results will be kept.", "Discard", { discard = false }, onCancel)

    fun setStatus(id: Int, status: String) {
        finished = finished.filterNot { it == id }
        dnf = dnf - id
        dns = dns - id
        dsq = dsq - id
        if (status == ResultStatus.DNS || status == ResultStatus.DSQ) { if (fastest == id) fastest = null }
        when (status) {
            ResultStatus.FINISHED -> finished = finished + id
            ResultStatus.DNF -> dnf = dnf + id
            ResultStatus.DNS -> dns = dns + id
            ResultStatus.DSQ -> dsq = dsq + id
        }
    }

    Column(Modifier.fillMaxSize()) {
        Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(Modifier.padding(14.dp)) {
                Text("FAST RESULT ENTRY", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Black, fontSize = 11.sp)
                Text("Positions come from the order below. Tap a P-number to jump a driver directly to any position, use arrows for fine changes, and mark DNF/DNS with one tap.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
            }
        }
        val visibleDriverIds = finished + dnf.sorted() + dns.sorted() + dsq.sorted()
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(visibleDriverIds, key = { it }) { driverId ->
                val driver = c.driverOrPlaceholder(driverId)
                val team = c.teamOrPlaceholder(driver.teamId)
                val status = when (driver.id) { in dnf -> ResultStatus.DNF; in dns -> ResultStatus.DNS; in dsq -> ResultStatus.DSQ; else -> ResultStatus.FINISHED }
                val position = finished.indexOf(driver.id).takeIf { it >= 0 }?.plus(1)
                ResultEntryRow(
                    driver = driver,
                    team = team,
                    status = status,
                    position = position,
                    positionCount = finished.size,
                    isFastest = fastest == driver.id,
                    onStatus = { setStatus(driver.id, it) },
                    onFastest = { if (status != ResultStatus.DNS && status != ResultStatus.DSQ) fastest = if (fastest == driver.id) null else driver.id },
                    onMoveTo = { targetIndex ->
                        val i = finished.indexOf(driver.id)
                        if (i >= 0) finished = finished.toMutableList().also { list ->
                            val id = list.removeAt(i)
                            list.add(targetIndex.coerceIn(0, list.size), id)
                        }
                    },
                    onUp = {
                        val i = finished.indexOf(driver.id)
                        if (i > 0) finished = finished.toMutableList().also { list -> val tmp = list[i - 1]; list[i - 1] = list[i]; list[i] = tmp }
                    },
                    onDown = {
                        val i = finished.indexOf(driver.id)
                        if (i >= 0 && i < finished.lastIndex) finished = finished.toMutableList().also { list -> val tmp = list[i + 1]; list[i + 1] = list[i]; list[i] = tmp }
                    }
                )
            }
        }
        Surface(tonalElevation = 3.dp, color = MaterialTheme.colorScheme.surface) {
            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { Feedback.emit(); discard = true }, modifier = Modifier.weight(1f)) { Text("Cancel") }
                Button(onClick = { Feedback.emit();
                    runCatching { ChampionshipEngine.normalizeRaceResults(c, finished, dnf, dns + dsq, fastest).map { rr ->
                        val old = race.results.firstOrNull { it.driverId == rr.driverId }
                        rr.copy(status = if (rr.driverId in dsq) ResultStatus.DSQ else rr.status, gridPosition = old?.gridPosition, teamId = old?.teamId ?: rr.teamId, penalty = old?.penalty ?: 0)
                    } }
                        .onSuccess { results -> onSave(race.copy(results = results)) }
                        .onFailure { error = it.message }
                }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(7.dp)); Text("Save result") }
            }
        }
    }
}

@Composable
internal fun ResultEntryRow(driver: Driver, team: Team, status: String, position: Int?, positionCount: Int, isFastest: Boolean, onStatus: (String) -> Unit, onFastest: () -> Unit, onMoveTo: (Int) -> Unit, onUp: () -> Unit, onDown: () -> Unit) {
    val isFinished = status == ResultStatus.FINISHED
    var showPositions by remember { mutableStateOf(false) }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(4.dp).fillMaxHeight().background(Color(team.colorArgb)))
            Box(Modifier.width(58.dp), contentAlignment = Alignment.Center) {
                Surface(
                    modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable(enabled = isFinished) { showPositions = true },
                    color = if (isFinished) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        position?.let { "P$it" } ?: status,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 7.dp),
                        fontWeight = FontWeight.Black,
                        fontSize = if (position != null) 15.sp else 10.sp,
                        color = if (status == ResultStatus.DNF) MaterialTheme.colorScheme.error else if (status == ResultStatus.DNS) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                    )
                }
                DropdownMenu(expanded = showPositions, onDismissRequest = { showPositions = false }) {
                    (1..positionCount).forEach { p ->
                        DropdownMenuItem(text = { Text("P$p") }, onClick = { Feedback.emit(); onMoveTo(p - 1); showPositions = false })
                    }
                }
            }
            Column(Modifier.weight(1f).padding(vertical = 9.dp)) {
                Text(driver.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                Text("#${driver.number} · ${team.abbreviation}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Column {
                  Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TinyStatusChip("FIN", status == ResultStatus.FINISHED) { onStatus(ResultStatus.FINISHED) }
                    TinyStatusChip("DNF", status == ResultStatus.DNF) { onStatus(ResultStatus.DNF) }
                  }
                  Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TinyStatusChip("DNS", status == ResultStatus.DNS) { onStatus(ResultStatus.DNS) }
                    TinyStatusChip("DSQ", status == ResultStatus.DSQ) { onStatus(ResultStatus.DSQ) }
                  }
                }
            }
            IconButton(onClick = { Feedback.emit(); onFastest() }) { Icon(Icons.Default.Bolt, "Fastest lap", tint = if (isFastest) McmGold else MaterialTheme.colorScheme.onSurfaceVariant) }
            Column {
                IconButton(onClick = { Feedback.emit(); onUp() }, enabled = isFinished && (position ?: 1) > 1, modifier = Modifier.size(48.dp)) { Icon(Icons.Default.KeyboardArrowUp, "Move up") }
                IconButton(onClick = { Feedback.emit(); onDown() }, enabled = isFinished, modifier = Modifier.size(48.dp)) { Icon(Icons.Default.KeyboardArrowDown, "Move down") }
            }
        }
    }
}

@Composable
internal fun TinyStatusChip(text: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(selected = selected, onClick = { Feedback.emit(); onClick() }, label = { Text(text, fontSize = 9.sp) }, modifier = Modifier.heightIn(min = 48.dp))
}

@Composable
internal fun RaceResultView(c: Championship, race: Race) {
    val orderedFinished = race.results.filter { it.status == ResultStatus.FINISHED }.sortedBy { it.finishPosition }
    val nonFinished = race.results.filter { it.status != ResultStatus.FINISHED }.sortedWith(compareBy<DriverRaceResult> { it.status }.thenBy { it.driverId })
    val teamPoints = c.teams.map { team -> team to race.results.filter { r -> c.driverOrPlaceholder(r.driverId).teamId == team.id }.sumOf { it.points } }.sortedByDescending { it.second }
    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            val podium = orderedFinished.take(3)
            Card(Modifier.fillMaxWidth().padding(12.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(18.dp)) {
                    Text("RACE RESULT", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp, fontWeight = FontWeight.Black)
                    podium.forEachIndexed { i, rr ->
                        val d = c.driverOrPlaceholder(rr.driverId)
                        Text("${listOf("🏆", "🥈", "🥉")[i]}  ${d.name}  ·  ${rr.points} PTS", fontSize = if (i == 0) 19.sp else 15.sp, fontWeight = if (i == 0) FontWeight.Black else FontWeight.Bold, modifier = Modifier.padding(top = 7.dp))
                    }
                    val fl = race.results.firstOrNull { it.fastestLap }?.let { rr -> c.driverOrPlaceholder(rr.driverId) }
                    if (fl != null) Text("⚡ Fastest Lap · ${fl.name}", color = McmGold, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
                }
            }
        }
        item { SectionHeader("Classification") }
        items(orderedFinished, key = { it.driverId }) { rr -> RaceClassificationRow(c, rr) }
        if (nonFinished.isNotEmpty()) item { SectionHeader("DNF / DNS") }
        items(nonFinished, key = { it.driverId }) { rr -> RaceClassificationRow(c, rr) }
        item { SectionHeader("Team points this race") }
        items(teamPoints, key = { it.first.id }) { (team, pts) ->
            ListItem(
                headlineContent = { Text(team.name, fontWeight = FontWeight.Bold) },
                leadingContent = { Box(Modifier.size(9.dp).clip(RoundedCornerShape(9.dp)).background(Color(team.colorArgb))) },
                trailingContent = { Text("$pts PTS", fontWeight = FontWeight.Black) },
                colors = ListItemDefaults.colors(containerColor = Color.Transparent)
            )
        }
    }
}

@Composable
internal fun RaceClassificationRow(c: Championship, rr: DriverRaceResult) {
    val d = c.driverOrPlaceholder(rr.driverId)
    val team = c.teamOrPlaceholder(d.teamId)
    ListItem(
        headlineContent = { Text(d.name, fontWeight = FontWeight.Bold) },
        supportingContent = { Text(team.name, fontSize = 11.sp) },
        leadingContent = { Text(if (rr.status == ResultStatus.FINISHED) "P${rr.finishPosition}" else rr.status, fontWeight = FontWeight.Black, color = if (rr.status == ResultStatus.DNF) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface) },
        trailingContent = { Row(verticalAlignment = Alignment.CenterVertically) { if (rr.fastestLap) Icon(Icons.Default.Bolt, null, tint = McmGold, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("${rr.points} PTS", fontWeight = FontWeight.Black) } },
        colors = ListItemDefaults.colors(containerColor = Color.Transparent)
    )
}
