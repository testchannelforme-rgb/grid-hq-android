@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.monoposto.championship

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.monoposto.championship.data.*
import com.monoposto.championship.domain.ChampionshipEngine
import com.monoposto.championship.ui.*
import java.util.Locale

@Composable
internal fun StandingsScreen(c: Championship, onDriver: (Int) -> Unit, onTeam: (Int) -> Unit) {
    var mode by rememberSaveable(c.id) { mutableIntStateOf(0) }
    val ds = remember(c) { ChampionshipEngine.driverStandings(c) }
    val ts = remember(c) { ChampionshipEngine.teamStandings(c) }
    Column(Modifier.fillMaxSize()) {
        SectionHeader("Standings", "Updated from every stored race result")
        TabRow(selectedTabIndex = mode) {
            Tab(selected = mode == 0, onClick = { Feedback.emit(); mode = 0 }, text = { Text("Drivers") })
            Tab(selected = mode == 1, onClick = { Feedback.emit(); mode = 1 }, text = { Text("Constructors") })
        }
        if (mode == 0 && ds.isEmpty() || mode == 1 && ts.isEmpty()) EmptyCard("No entries yet", "Add drivers and constructors in Settings to see their standings.")
        else if (mode == 0) LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(ds, key = { _, s -> s.driver.id }) { index, s -> DriverStandingCard(index + 1, s, onDriver) }
        } else LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(ts, key = { _, s -> s.team.id }) { index, s -> TeamStandingCard(index + 1, s, onTeam) }
        }
    }
}

@Composable
internal fun DriverStandingCard(position: Int, s: DriverStanding, onDriver: (Int) -> Unit) {
    val teamColor = Color(s.team.colorArgb)
    val bg by animateColorAsState(if (position == 1) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface, label = "leader")
    Card(Modifier.fillMaxWidth().clickable { Feedback.emit(FeedbackKind.NAVIGATION); onDriver(s.driver.id) }, colors = CardDefaults.cardColors(containerColor = bg)) {
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(4.dp).fillMaxHeight().background(teamColor))
            Text(position.toString(), Modifier.width(48.dp).padding(start = 14.dp), fontSize = 20.sp, fontWeight = FontWeight.Black, color = if (position == 1) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
            Column(Modifier.weight(1f).padding(vertical = 12.dp)) {
                Text(s.driver.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                Text(s.team.name, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("${s.wins} W  ·  ${s.podiums} POD", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Column(Modifier.padding(end = 14.dp), horizontalAlignment = Alignment.End) {
                AnimatedPoints(s.points)
                Text("PTS", color = MaterialTheme.colorScheme.primary, fontSize = 10.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
internal fun TeamStandingCard(position: Int, s: TeamStanding, onTeam: (Int) -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { Feedback.emit(FeedbackKind.NAVIGATION); onTeam(s.team.id) }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(5.dp).fillMaxHeight().background(Color(s.team.colorArgb)))
            Text(position.toString(), Modifier.width(50.dp).padding(start = 14.dp), fontSize = 20.sp, fontWeight = FontWeight.Black)
            Column(Modifier.weight(1f).padding(vertical = 14.dp)) {
                Text(s.team.name, fontWeight = FontWeight.Bold)
                Text("${s.wins} wins · ${s.podiums} podiums", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("${s.points} PTS", Modifier.padding(end = 14.dp), fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
        }
    }
}

