package com.monoposto.championship.data

const val DRIVER_COUNT = 24
const val TEAM_COUNT = 12

object ResultStatus {
    const val FINISHED = "FINISHED"
    const val DNF = "DNF"
    const val DNS = "DNS"
    const val DSQ = "DSQ"
}

data class DriverRaceResult(
    val driverId: Int,
    val finishPosition: Int? = null,
    val status: String = ResultStatus.DNS,
    val points: Int = 0,
    val fastestLap: Boolean = false,
    val gridPosition: Int? = null,
    val teamId: Int? = null,
    val penalty: Int = 0
)

data class Race(
    val id: Int,
    val round: Int,
    val name: String,
    val results: List<DriverRaceResult> = emptyList(),
    val sprintEnabled: Boolean = false,
    val sprintResults: List<DriverRaceResult> = emptyList(),
    val notes: String = ""
) {
    val completed: Boolean get() = results.size == DRIVER_COUNT
    val sprintCompleted: Boolean get() = sprintEnabled && sprintResults.size == DRIVER_COUNT
    val allResults: List<DriverRaceResult> get() = results + if (sprintEnabled) sprintResults else emptyList()
}

data class Driver(
    val id: Int,
    val name: String,
    val number: Int,
    val abbreviation: String,
    val teamId: Int
)

data class Team(
    val id: Int,
    val name: String,
    val abbreviation: String,
    val colorArgb: Int
)

data class ScoringRules(
    val positionPoints: List<Int> = listOf(
        25, 18, 15, 12, 10, 8, 6, 4, 2, 1,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
    ),
    val fastestLapPoints: Int = 1,
    val fastestLapTop: Int = 24,
    val allowDnfFastestLap: Boolean = true
)

data class Championship(
    val id: Long,
    val name: String,
    val season: String,
    val races: List<Race>,
    val teams: List<Team>,
    val drivers: List<Driver>,
    val scoring: ScoringRules = ScoringRules(),
    val sprintScoring: ScoringRules = ScoringRules(List(24) { if (it < 8) 8 - it else 0 }, 0),
    val developmentEnabled: Boolean = false,
    val upgrades: List<Upgrade> = emptyList(),
    val revision: Long = 0
)

enum class DevelopmentArea { PERFORMANCE, RELIABILITY, AERODYNAMICS, POWER, CHASSIS, PIT_OPERATIONS }
data class Upgrade(val teamId: Int, val area: DevelopmentArea, val level: Int, val cost: Int, val afterRound: Int)

data class DriverStanding(
    val driver: Driver,
    val team: Team,
    val points: Int,
    val wins: Int,
    val podiums: Int,
    val top5: Int,
    val top10: Int,
    val fastestLaps: Int,
    val dnfs: Int,
    val dns: Int,
    val bestFinish: Int?,
    val worstFinish: Int?,
    val averageFinish: Double?,
    val averagePointsPerRace: Double,
    val raceStarts: Int,
    val completedRaces: Int,
    val positionCounts: List<Int>,
    val raceResults: List<Pair<Race, DriverRaceResult>>
)

data class TeamRaceSummary(
    val race: Race,
    val points: Int,
    val bestFinish: Int?,
    val results: List<DriverRaceResult>
)

data class TeamStanding(
    val team: Team,
    val points: Int,
    val wins: Int,
    val podiums: Int,
    val bestFinish: Int?,
    val averagePointsPerRace: Double,
    val driverStandings: List<DriverStanding>,
    val positionCounts: List<Int>,
    val raceSummaries: List<TeamRaceSummary>
)

data class SeasonStatistics(
    val championshipLeader: DriverStanding?,
    val mostWins: DriverStanding?,
    val mostPodiums: DriverStanding?,
    val mostFastestLaps: DriverStanding?,
    val mostDnfs: DriverStanding?,
    val bestAverageFinish: DriverStanding?,
    val mostPointsInOneRaceDriver: Driver?,
    val mostPointsInOneRace: Int,
    val highestScoringTeam: TeamStanding?,
    val lowestScoringTeam: TeamStanding?
)
