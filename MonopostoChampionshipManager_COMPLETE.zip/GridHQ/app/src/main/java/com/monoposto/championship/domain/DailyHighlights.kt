package com.monoposto.championship.domain

import com.monoposto.championship.data.*
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZonedDateTime
import kotlin.random.Random

data class DailyHighlight(val championshipId: Long?, val raceId: Int?, val title: String, val body: String)

object DailyHighlights {
    /** A target is chosen once per local day, never at a fixed hour. End is exclusive. */
    fun targetMinute(startHour: Int, endHour: Int, random: Random = Random.Default): Int {
        require(startHour in 0..23 && endHour in 1..24 && startHour < endHour)
        return random.nextInt(startHour * 60, endHour * 60)
    }
    fun isDue(now: ZonedDateTime, targetMinute: Int, lastSent: LocalDate?, startHour: Int, endHour: Int): Boolean {
        val minute = now.hour * 60 + now.minute
        return now.toLocalDate() != lastSent && minute >= targetMinute && minute >= startHour * 60 && minute < endHour * 60
    }
    fun build(championship: Championship?, day: LocalDate): DailyHighlight {
        val c = championship ?: return DailyHighlight(null, null, "Your next season starts here", "Create a championship in Grid HQ and record your first race.")
        val latest = c.races.filter { it.completed }.maxByOrNull { it.round }
        if (latest != null && day.dayOfYear % 3 != 0) {
            val podium = latest.results.filter { it.status == ResultStatus.FINISHED && it.finishPosition in 1..3 }
                .sortedBy { it.finishPosition }.joinToString(" · ") { "P${it.finishPosition} ${c.driverOrPlaceholder(it.driverId).name}" }
            return DailyHighlight(c.id, latest.id, "${latest.name} · Latest recorded race", podium.ifBlank { "Round ${latest.round} is complete. See the full classification." })
        }
        if (c.races.none { it.completed || it.sprintCompleted }) return DailyHighlight(c.id, null, "${c.name} · Ready to race", "Record your first result to start the championship story.")
        val leader = ChampionshipEngine.driverStandings(c).firstOrNull()
        return DailyHighlight(c.id, null, "${c.name} · Championship highlight", if (leader == null) "Add your drivers to get started." else
            "${leader.driver.name} leads with ${leader.points} points · ${leader.wins} wins · ${leader.podiums} podiums.")
    }
}
