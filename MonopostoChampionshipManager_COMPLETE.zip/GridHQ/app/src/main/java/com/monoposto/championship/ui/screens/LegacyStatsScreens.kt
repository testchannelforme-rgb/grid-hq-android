@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.monoposto.championship

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.monoposto.championship.data.*
import com.monoposto.championship.domain.ChampionshipEngine
import com.monoposto.championship.ui.*
import java.util.Locale

@Composable
internal fun StatsScreen(c: Championship, onDriver: (Int) -> Unit, onTeam: (Int) -> Unit, onInsights: () -> Unit = {}) {
    val stats = remember(c) { ChampionshipEngine.seasonStatistics(c) }
    LazyColumn(contentPadding = PaddingValues(bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { SectionHeader("Season statistics", c.name) }
        item { OutlinedButton(onInsights, Modifier.fillMaxWidth().padding(horizontal = 16.dp)) { Icon(Icons.Default.Insights, null); Spacer(Modifier.width(8.dp)); Text("Graphs, predictions & development") } }
        item { StatTile("Championship leader", stats.championshipLeader?.driver?.name ?: "—", stats.championshipLeader?.let { "${it.points} pts" } ?: "No results", Icons.Default.EmojiEvents) { stats.championshipLeader?.let { onDriver(it.driver.id) } } }
        item { StatTile("Most wins", stats.mostWins?.driver?.name ?: "—", "${stats.mostWins?.wins ?: 0}", Icons.Default.MilitaryTech) { stats.mostWins?.let { onDriver(it.driver.id) } } }
        item { StatTile("Most podiums", stats.mostPodiums?.driver?.name ?: "—", "${stats.mostPodiums?.podiums ?: 0}", Icons.Default.WorkspacePremium) { stats.mostPodiums?.let { onDriver(it.driver.id) } } }
        item { StatTile("Most fastest laps", stats.mostFastestLaps?.driver?.name ?: "—", "${stats.mostFastestLaps?.fastestLaps ?: 0}", Icons.Default.Bolt) { stats.mostFastestLaps?.let { onDriver(it.driver.id) } } }
        item { StatTile("Most DNFs", stats.mostDnfs?.driver?.name ?: "—", "${stats.mostDnfs?.dnfs ?: 0}", Icons.Default.WarningAmber) { stats.mostDnfs?.let { onDriver(it.driver.id) } } }
        item { StatTile("Most points in one race", stats.mostPointsInOneRaceDriver?.name ?: "—", "${stats.mostPointsInOneRace} pts", Icons.Default.Star) { stats.mostPointsInOneRaceDriver?.let { onDriver(it.id) } } }
        item { StatTile("Best average finish", stats.bestAverageFinish?.driver?.name ?: "—", stats.bestAverageFinish?.averageFinish?.let { "P${"%.2f".format(it)}" } ?: "—", Icons.Default.TrendingUp) { stats.bestAverageFinish?.let { onDriver(it.driver.id) } } }
        item { StatTile("Highest scoring team", stats.highestScoringTeam?.team?.name ?: "—", "${stats.highestScoringTeam?.points ?: 0} pts", Icons.Default.Groups) { stats.highestScoringTeam?.let { onTeam(it.team.id) } } }
        item { StatTile("Lowest scoring team", stats.lowestScoringTeam?.team?.name ?: "—", "${stats.lowestScoringTeam?.points ?: 0} pts", Icons.Default.Groups) { stats.lowestScoringTeam?.let { onTeam(it.team.id) } } }
    }
}

@Composable
internal fun StatTile(label: String, name: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp).clickable(onClick = { Feedback.emit(); onClick() }), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = .12f)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary) }
            Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(name, fontWeight = FontWeight.Bold) }
            Text(value, fontWeight = FontWeight.Black, fontSize = 17.sp)
        }
    }
}

@Composable
internal fun DriverDetailScreen(c: Championship, driverId: Int, onBack: () -> Unit) {
    val s = remember(c, driverId) { ChampionshipEngine.driverStandings(c).firstOrNull { it.driver.id == driverId } }
    if (s == null) { MissingDetail("Driver unavailable", onBack); return }
    Column(Modifier.fillMaxSize()) {
        DetailTopBar(s.driver.name, onBack)
        LazyColumn(contentPadding = PaddingValues(bottom = 18.dp)) {
            item {
                Card(Modifier.fillMaxWidth().padding(14.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
                        Box(Modifier.width(5.dp).fillMaxHeight().background(Color(s.team.colorArgb)))
                        Column(Modifier.padding(18.dp).weight(1f)) {
                            Text("#${s.driver.number} · ${s.driver.abbreviation} · ${s.team.name}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${s.points} PTS", fontSize = 32.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                            Text("${s.wins} wins · ${s.podiums} podiums · ${s.fastestLaps} fastest laps", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val entries = listOf(
                        "Top 5" to s.top5.toString(), "Top 10" to s.top10.toString(), "DNF" to s.dnfs.toString(), "DNS" to s.dns.toString(),
                        "Best" to (s.bestFinish?.let { "P$it" } ?: "—"), "Worst" to (s.worstFinish?.let { "P$it" } ?: "—"),
                        "Avg finish" to (s.averageFinish?.let { "%.2f".format(it) } ?: "—"), "Avg pts" to "%.2f".format(s.averagePointsPerRace),
                        "Starts" to s.raceStarts.toString(), "Completed" to s.completedRaces.toString()
                    )
                    items(entries) { (label, value) -> SmallStat(label, value) }
                }
            }
            item { SectionHeader("Race-by-race performance") }
            items(s.raceResults, key = { it.first.id }) { (race, rr) ->
                ListItem(
                    headlineContent = { Text(race.name, fontWeight = FontWeight.Bold) },
                    supportingContent = { Text("Round ${race.round}") },
                    leadingContent = { Text(if (rr.status == ResultStatus.FINISHED) "P${rr.finishPosition}" else rr.status, fontWeight = FontWeight.Black) },
                    trailingContent = { Row(verticalAlignment = Alignment.CenterVertically) { if (rr.fastestLap) Icon(Icons.Default.Bolt, null, tint = McmGold, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text("${rr.points} pts", fontWeight = FontWeight.Bold) } },
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                )
            }
        }
    }
}

@Composable
internal fun TeamDetailScreen(c: Championship, teamId: Int, onBack: () -> Unit) {
    val s = remember(c, teamId) { ChampionshipEngine.teamStandings(c).firstOrNull { it.team.id == teamId } }
    if (s == null) { MissingDetail("Constructor unavailable", onBack); return }
    Column(Modifier.fillMaxSize()) {
        DetailTopBar(s.team.name, onBack)
        LazyColumn(contentPadding = PaddingValues(bottom = 18.dp)) {
            item {
                Card(Modifier.fillMaxWidth().padding(14.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
                        Box(Modifier.width(6.dp).fillMaxHeight().background(Color(s.team.colorArgb)))
                        Column(Modifier.weight(1f).padding(18.dp)) {
                            Text(s.team.abbreviation, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                            Text("${s.points} PTS", fontSize = 32.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                            Text("${s.wins} wins · ${s.podiums} podiums · Best ${s.bestFinish?.let { "P$it" } ?: "—"}")
                            Text("Average ${"%.2f".format(s.averagePointsPerRace)} points / race", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            item { SectionHeader("Driver contribution") }
            items(c.drivers.filter { d -> d.teamId == teamId || s.raceSummaries.any { r -> r.results.any { it.driverId == d.id } } }, key = { "driver:${it.id}" }) { d ->
                val contributed = s.raceSummaries.sumOf { r -> r.results.filter { it.driverId == d.id }.sumOf { it.points } }
                ListItem(headlineContent = { Text(d.name, fontWeight = FontWeight.Bold) }, supportingContent = { Text("Points earned representing this team") }, trailingContent = { Text("$contributed pts", fontWeight = FontWeight.Black) }, colors = ListItemDefaults.colors(containerColor = Color.Transparent))
            }
            item { SectionHeader("Race-by-race") }
            if (s.raceSummaries.isEmpty()) item { EmptyCard("No results yet", "Record a race or sprint to see this team’s progress.") }
            items(s.raceSummaries, key = { "race:${it.race.id}" }) { r ->
                val resultText = r.results.joinToString(" · ") { rr ->
                    val d = c.driverOrPlaceholder(rr.driverId)
                    "${d.abbreviation} ${if (rr.status == ResultStatus.FINISHED) "P${rr.finishPosition}" else rr.status}"
                }
                ListItem(
                    headlineContent = { Text(r.race.name, fontWeight = FontWeight.Bold) },
                    supportingContent = { Text("$resultText · Best ${r.bestFinish?.let { "P$it" } ?: "—"}") },
                    trailingContent = { Text("${r.points} pts", fontWeight = FontWeight.Black) },
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                )
            }
        }
    }
}

@Composable
internal fun SmallStat(label: String, value: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) { Column(Modifier.padding(12.dp)) { Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(value, fontSize = 17.sp, fontWeight = FontWeight.Black) } }
}

@Composable
internal fun DetailTopBar(title: String, onBack: () -> Unit) {
    TopAppBar(title = { Text(title, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis) }, navigationIcon = { IconButton(onClick = { Feedback.emit(FeedbackKind.NAVIGATION); onBack() }) { Icon(Icons.Default.ArrowBack, "Back") } }, colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background))
}
