@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.monoposto.championship

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.monoposto.championship.data.*
import com.monoposto.championship.domain.ChampionshipEngine
import com.monoposto.championship.ui.*
import java.util.Locale

@Composable
internal fun MonopostoApp(vm: ChampionshipViewModel, notification: NotificationRoute? = null, onNotificationConsumed: () -> Unit = {}) {
    val state by vm.state.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableStateOf(TopTab.HOME) }
    var detail by rememberSaveable(stateSaver = androidx.compose.runtime.saveable.Saver<DetailRoute?, String>(
        save = { when (it) { is DetailRoute.Driver -> "d:${it.id}"; is DetailRoute.Team -> "t:${it.id}"; is DetailRoute.Race -> "r:${it.id}"; DetailRoute.People -> "p"; DetailRoute.Scoring -> "s"; DetailRoute.Insights -> "i"; null -> "" } },
        restore = { when { it.startsWith("d:") -> it.substring(2).toIntOrNull()?.let(DetailRoute::Driver); it.startsWith("t:") -> it.substring(2).toIntOrNull()?.let(DetailRoute::Team); it.startsWith("r:") -> it.substring(2).toIntOrNull()?.let(DetailRoute::Race); it == "p" -> DetailRoute.People; it == "s" -> DetailRoute.Scoring; it == "i" -> DetailRoute.Insights; else -> null } }
    )) { mutableStateOf<DetailRoute?>(null) }
    var showPicker by remember { mutableStateOf(false) }
    var showNew by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val reduced = context.getSharedPreferences("gridhq_experience", 0).getBoolean("reduce_motion", false)
    val snackbar = remember { SnackbarHostState() }
    val importBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.importFrom(uri) }

    LaunchedEffect(notification, state.loading) {
        if (notification != null && !state.loading) {
            val target = state.championships.firstOrNull { it.id == notification.championshipId }
            if (target != null) {
                vm.select(target.id)
                detail = notification.raceId?.takeIf { id -> target.races.any { it.id == id } }?.let(DetailRoute::Race)
                tab = TopTab.STANDINGS
            }
            onNotificationConsumed()
        }
    }
    LaunchedEffect(state.success) {
        state.success?.let { Feedback.emit(FeedbackKind.SUCCESS); snackbar.showSnackbar(it); vm.clearSuccess() }
    }
    LaunchedEffect(state.error) {
        state.error?.let { Feedback.emit(FeedbackKind.ERROR); snackbar.showSnackbar(it); if (state.championships.isNotEmpty()) vm.clearError() }
    }

    if (state.loading && state.championships.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }

    BackHandler(enabled = detail != null) { Feedback.emit(FeedbackKind.NAVIGATION); detail = null }

    val c = state.selected
    if (c == null) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) {
                if (state.error != null) EmptyCard("Couldn’t load your championships", "Your saved data has not been reset. Please try again.", "Retry") { vm.refresh() }
                else EmptyState(onCreate = { showNew = true })
            }
            OutlinedButton({ Feedback.emit(); importBackup.launch(arrayOf("application/json", "text/plain")) }, Modifier.fillMaxWidth().padding(16.dp)) { Text("Restore championship backup") }
            SnackbarHost(snackbar)
        }
        if (showNew) NewChampionshipDialog(onDismiss = { showNew = false }) { name, season, count ->
            vm.create(name, season, count); showNew = false
        }
        return
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            if (detail == null) AppTopBar(c, onChampionship = { showPicker = true })
        },
        bottomBar = {
            if (detail == null) BottomNavigation(tab) { Feedback.emit(FeedbackKind.SELECTION); tab = it }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.TopCenter) {
            AnimatedContent(targetState = detail to tab, modifier = Modifier.widthIn(max = 840.dp).fillMaxSize(), transitionSpec = { fadeIn(tween(if (reduced) 0 else 220)) togetherWith fadeOut(tween(if (reduced) 0 else 150)) }, label = "route") { (route, currentTab) ->
                if (route != null) {
                    when (route) {
                        is DetailRoute.Driver -> DriverDetailScreen(c, route.id, onBack = { detail = null })
                        is DetailRoute.Team -> TeamDetailScreen(c, route.id, onBack = { detail = null })
                        is DetailRoute.Race -> WeekendScreen(c, route.id, onBack = { detail = null }, onSave = vm::save)
                        DetailRoute.Insights -> InsightsScreen(c, onBack = { detail = null }, onSave = vm::save)
                        DetailRoute.People -> PeopleScreen(c, onBack = { detail = null }, onSave = vm::save)
                        DetailRoute.Scoring -> ScoringScreen(c, onBack = { detail = null }, onSave = vm::save)
                    }
                } else {
                    when (currentTab) {
                        TopTab.HOME -> PullToRefreshBox(isRefreshing = state.loading, onRefresh = { Feedback.emit(FeedbackKind.CONFIRM); vm.refresh() }) {
                            HomeScreen(c, onRace = { detail = DetailRoute.Race(it) }, onStandings = { tab = TopTab.STANDINGS })
                        }
                        TopTab.STANDINGS -> StandingsScreen(c, onDriver = { detail = DetailRoute.Driver(it) }, onTeam = { detail = DetailRoute.Team(it) })
                        TopTab.RACES -> RacesScreen(c, onRace = { detail = DetailRoute.Race(it) }, onSave = vm::save)
                        TopTab.STATS -> StatsScreen(c, onDriver = { detail = DetailRoute.Driver(it) }, onTeam = { detail = DetailRoute.Team(it) }, onInsights = { detail = DetailRoute.Insights })
                        TopTab.SETTINGS -> SettingsScreen(
                            c = c,
                            vm = vm,
                            onPeople = { detail = DetailRoute.People },
                            onScoring = { detail = DetailRoute.Scoring },
                            onRaces = { tab = TopTab.RACES },
                            onDeleted = { detail = null; tab = TopTab.HOME }
                        )
                    }
                }
            }
        }
    }

    if (showPicker) ChampionshipPickerDialog(
        championships = state.championships,
        selectedId = c.id,
        onDismiss = { showPicker = false },
        onSelect = { vm.select(it); showPicker = false; detail = null; tab = TopTab.HOME },
        onNew = { showPicker = false; showNew = true },
        onDuplicate = { vm.duplicate(c); showPicker = false }
    )
    if (showNew) NewChampionshipDialog(onDismiss = { showNew = false }) { name, season, count ->
        vm.create(name, season, count); showNew = false; detail = null; tab = TopTab.HOME
    }
}
