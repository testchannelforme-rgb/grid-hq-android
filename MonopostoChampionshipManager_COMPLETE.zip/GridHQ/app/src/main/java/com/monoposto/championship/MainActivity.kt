@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.monoposto.championship

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.monoposto.championship.data.*
import com.monoposto.championship.domain.ChampionshipEngine
import com.monoposto.championship.ui.*
import java.util.Locale

data class NotificationRoute(val championshipId: Long?, val raceId: Int?)

class MainActivity : ComponentActivity() {
    private val vm: ChampionshipViewModel by viewModels()
    private var notificationRoute by mutableStateOf<NotificationRoute?>(null)
    private fun readRoute(intent: android.content.Intent?) {
        if (intent?.getBooleanExtra("highlight", false) == true) {
            notificationRoute = NotificationRoute(intent.getLongExtra("championship_id", -1).takeIf { it != -1L }, intent.getIntExtra("race_id", -1).takeIf { it != -1 })
            intent.removeExtra("highlight")
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Feedback.attach(window.decorView)
        readRoute(intent)
        com.monoposto.championship.notifications.DailyNotifications.schedule(this)
        setContent {
            val state by vm.state.collectAsStateWithLifecycle()
            AppTheme { LaunchExperience(loading = state.loading && state.championships.isEmpty()) {
                MonopostoApp(vm, notificationRoute) { notificationRoute = null }
            } }
        }
    }
    override fun onNewIntent(intent: android.content.Intent) { super.onNewIntent(intent); setIntent(intent); readRoute(intent) }
    override fun onDestroy() { Feedback.release(); super.onDestroy() }
}
