package com.monoposto.championship.data

import android.content.Context
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONArray

object ReleaseConfiguration {
    // Public repository hosting release APKs, in owner/repository format. Never put a token here.
    const val PUBLIC_RELEASE_REPOSITORY = ""
}

data class DownloadCount(val count: Long, val timestamp: Long)

class DownloadCounter(context: Context) {
    private val prefs = context.getSharedPreferences("gridhq_downloads", 0)
    private val repo = ReleaseConfiguration.PUBLIC_RELEASE_REPOSITORY
    fun cached(): DownloadCount? = if (prefs.getString("repository", "") == repo && prefs.contains("count")) DownloadCount(prefs.getLong("count", 0), prefs.getLong("timestamp", 0)) else null
    fun refresh(): DownloadCount {
        require(repo.matches(Regex("[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+"))) { "Public release repository has not been configured." }
        cached()?.let { if (System.currentTimeMillis() - it.timestamp < 15 * 60 * 1000) return it }
        var total = 0L
        for (page in 1..20) {
            val connection = URL("https://api.github.com/repos/$repo/releases?per_page=100&page=$page").openConnection() as HttpURLConnection
            val releases = try {
                connection.connectTimeout = 10000; connection.readTimeout = 10000
                connection.setRequestProperty("Accept", "application/vnd.github+json")
                connection.setRequestProperty("User-Agent", "GridHQ")
                require(connection.responseCode == 200) { "GitHub returned ${connection.responseCode}. Check connectivity, public repository access or rate limits." }
                JSONArray(connection.inputStream.bufferedReader().use { it.readText() })
            } finally { connection.disconnect() }
            for (i in 0 until releases.length()) {
                val assets = releases.getJSONObject(i).getJSONArray("assets")
                for (j in 0 until assets.length()) {
                    val a = assets.getJSONObject(j)
                    if (a.getString("name").endsWith(".apk", ignoreCase = true)) total += a.getLong("download_count")
                }
            }
            if (releases.length() < 100) {
                val result = DownloadCount(total, System.currentTimeMillis())
                check(prefs.edit().putString("repository", repo).putLong("count", total).putLong("timestamp", result.timestamp).commit()) { "Unable to cache download count." }
                return result
            }
        }
        error("Release list too large; no partial total was saved.")
    }
}
