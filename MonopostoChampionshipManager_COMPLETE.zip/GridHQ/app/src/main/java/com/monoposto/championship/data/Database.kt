package com.monoposto.championship.data

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Entity(tableName = "championships")
data class ChampionshipEntity(
    @PrimaryKey val id: Long,
    val name: String,
    val season: String,
    val fastestLapPoints: Int,
    @ColumnInfo(defaultValue = "''") val payload: String = ""
)

@Entity(
    tableName = "teams",
    primaryKeys = ["championshipId", "id"],
    foreignKeys = [ForeignKey(
        entity = ChampionshipEntity::class,
        parentColumns = ["id"],
        childColumns = ["championshipId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("championshipId")]
)
data class TeamEntity(
    val championshipId: Long,
    val id: Int,
    val name: String,
    val abbreviation: String,
    val colorArgb: Int
)

@Entity(
    tableName = "drivers",
    primaryKeys = ["championshipId", "id"],
    foreignKeys = [ForeignKey(
        entity = ChampionshipEntity::class,
        parentColumns = ["id"],
        childColumns = ["championshipId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("championshipId")]
)
data class DriverEntity(
    val championshipId: Long,
    val id: Int,
    val name: String,
    val number: Int,
    val abbreviation: String,
    val teamId: Int
)

@Entity(
    tableName = "races",
    primaryKeys = ["championshipId", "id"],
    foreignKeys = [ForeignKey(
        entity = ChampionshipEntity::class,
        parentColumns = ["id"],
        childColumns = ["championshipId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("championshipId")]
)
data class RaceEntity(
    val championshipId: Long,
    val id: Int,
    val round: Int,
    val name: String
)

@Entity(
    tableName = "results",
    primaryKeys = ["championshipId", "raceId", "driverId"],
    foreignKeys = [ForeignKey(
        entity = ChampionshipEntity::class,
        parentColumns = ["id"],
        childColumns = ["championshipId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("championshipId"), Index(value = ["championshipId", "raceId"])]
)
data class ResultEntity(
    val championshipId: Long,
    val raceId: Int,
    val driverId: Int,
    val finishPosition: Int?,
    val status: String,
    val points: Int,
    val fastestLap: Boolean
)

@Entity(
    tableName = "scoring",
    primaryKeys = ["championshipId", "position"],
    foreignKeys = [ForeignKey(
        entity = ChampionshipEntity::class,
        parentColumns = ["id"],
        childColumns = ["championshipId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("championshipId")]
)
data class ScoringEntity(
    val championshipId: Long,
    val position: Int,
    val points: Int
)

@Dao
interface ChampionshipDao {
    @Query("SELECT * FROM championships WHERE id=:id")
    suspend fun championship(id: Long): ChampionshipEntity?

    @Upsert
    suspend fun upsertChampionship(entity: ChampionshipEntity)
    @Query("SELECT * FROM championships ORDER BY id DESC")
    suspend fun championships(): List<ChampionshipEntity>

    @Query("SELECT * FROM teams WHERE championshipId=:championshipId ORDER BY id")
    suspend fun teams(championshipId: Long): List<TeamEntity>

    @Query("SELECT * FROM drivers WHERE championshipId=:championshipId ORDER BY id")
    suspend fun drivers(championshipId: Long): List<DriverEntity>

    @Query("SELECT * FROM races WHERE championshipId=:championshipId ORDER BY round")
    suspend fun races(championshipId: Long): List<RaceEntity>

    @Query("SELECT * FROM results WHERE championshipId=:championshipId")
    suspend fun results(championshipId: Long): List<ResultEntity>

    @Query("SELECT * FROM scoring WHERE championshipId=:championshipId ORDER BY position")
    suspend fun scoring(championshipId: Long): List<ScoringEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChampionship(entity: ChampionshipEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeams(entities: List<TeamEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDrivers(entities: List<DriverEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRaces(entities: List<RaceEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertResults(entities: List<ResultEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScoring(entities: List<ScoringEntity>)

    @Query("DELETE FROM championships WHERE id=:championshipId")
    suspend fun deleteChampionship(championshipId: Long)
}

@Database(
    entities = [
        ChampionshipEntity::class,
        TeamEntity::class,
        DriverEntity::class,
        RaceEntity::class,
        ResultEntity::class,
        ScoringEntity::class
    ],
    version = 2,
    exportSchema = true
)
abstract class ChampionshipDatabase : RoomDatabase() {
    abstract fun dao(): ChampionshipDao

    companion object {
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE championships ADD COLUMN payload TEXT NOT NULL DEFAULT ''")
            }
        }
        @Volatile private var INSTANCE: ChampionshipDatabase? = null

        fun get(context: Context): ChampionshipDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                ChampionshipDatabase::class.java,
                "monoposto_championship.db"
            ).addMigrations(MIGRATION_1_2).build().also { INSTANCE = it }
        }
    }
}
