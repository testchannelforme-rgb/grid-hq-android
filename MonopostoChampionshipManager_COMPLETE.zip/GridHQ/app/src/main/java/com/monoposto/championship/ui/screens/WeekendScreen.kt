@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.monoposto.championship

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.monoposto.championship.data.*
import com.monoposto.championship.domain.*

@Composable
internal fun WeekendScreen(c: Championship, raceId: Int, onBack: () -> Unit, onSave: (Championship) -> Unit) {
    val race = c.races.firstOrNull { it.id == raceId }
    if (race == null) { MissingDetail("Race unavailable", onBack); return }
    var page by rememberSaveable(c.id, raceId) { mutableStateOf("weekend") }
    var notes by rememberSaveable(c.id, raceId, race.notes) { mutableStateOf(race.notes) }
    var confirm by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var returnAfterSave by remember { mutableStateOf(false) }
    var savedPulse by remember { mutableStateOf(0) }
    LaunchedEffect(c.revision) { if (returnAfterSave) { page = "weekend"; returnAfterSave = false; savedPulse++ } }
    fun save(updated: Race) {
        runCatching { c.copy(races = c.races.map { if (it.id == raceId) updated else it }).also(Validation::check) }
            .onSuccess(onSave).onFailure { error = it.message }
    }
    fun back() { if (notes != race.notes) confirm = "leave" else onBack() }
    BackHandler { if (page != "weekend") page = "weekend" else back() }
    when (page) {
        "race", "sprint" -> {
            val sprint = page == "sprint"
            val session = race.copy(name = "${race.name} · ${if (sprint) "Sprint" else "Race"}", results = if (sprint) race.sprintResults else race.results)
            val proxy = c.copy(scoring = if (sprint) c.sprintScoring else c.scoring, races = c.races.map { if (it.id == raceId) session else it })
            RaceDetailScreen(proxy, raceId, { page = "weekend" }) { edited ->
                val result = edited.races.first { it.id == raceId }.results
                save(if (sprint) race.copy(sprintResults = result) else race.copy(results = result))
                returnAfterSave = true
            }
        }
        "grid", "sprintGrid" -> GridEditor(c, race, page == "sprintGrid", { page = "weekend" }) { save(it); returnAfterSave = true }
        else -> Column(Modifier.fillMaxSize()) {
            DetailTopBar("Round ${race.round} · ${race.name}", ::back)
            LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { ResultMoment(savedPulse, race.completed || race.sprintCompleted) { savedPulse = 0 } }
                item { error?.let { Text(it, color = MaterialTheme.colorScheme.error) } }
                item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Sprint weekend")
                    Switch(race.sprintEnabled, { if (!it && race.sprintResults.isNotEmpty()) confirm = "disable" else save(race.copy(sprintEnabled = it)) })
                } }
                item { Button({ Feedback.emit(); page = "race" }, Modifier.fillMaxWidth()) { Text(if (race.completed) "View / edit race result" else "Enter race result") } }
                if (race.sprintEnabled) item { FilledTonalButton({ Feedback.emit(); page = "sprint" }, Modifier.fillMaxWidth()) { Text(if (race.sprintCompleted) "View / edit sprint result" else "Enter sprint result") } }
                if (race.completed) item { OutlinedButton({ Feedback.emit(); page = "grid" }, Modifier.fillMaxWidth()) { Text("Race grid positions & points penalties") } }
                if (race.sprintCompleted) item { OutlinedButton({ Feedback.emit(); page = "sprintGrid" }, Modifier.fillMaxWidth()) { Text("Sprint grid positions & points penalties") } }
                item { Text("Race notes", style = MaterialTheme.typography.titleLarge) }
                item { OutlinedTextField(notes, { if (it.length <= 20000) notes = it }, Modifier.fillMaxWidth().heightIn(min = 160.dp), label = { Text("Incidents, strategy, memories…") }, supportingText = { Text("${notes.length} / 20,000 · ${if (notes == race.notes) "Saved" else "Unsaved changes"}") }) }
                item { Button({ Feedback.emit(); save(race.copy(notes = notes)) }, Modifier.fillMaxWidth(), enabled = notes != race.notes) { Text("Save notes") } }
                if (race.completed) item { TextButton({ Feedback.emit(); confirm = "race" }) { Text("Delete race result", color = MaterialTheme.colorScheme.error) } }
                if (race.sprintCompleted) item { TextButton({ Feedback.emit(); confirm = "sprint" }) { Text("Delete sprint result", color = MaterialTheme.colorScheme.error) } }
            }
        }
    }
    confirm?.let { action ->
        ConfirmDialog(if (action == "leave") "Discard unsaved notes?" else "Remove recorded results?", if (action == "leave") "Your saved note will remain unchanged." else "Standings and statistics will be recalculated. Notes are kept.", if (action == "leave") "Discard" else "Remove", { confirm = null }) {
            when (action) { "leave" -> onBack(); "race" -> save(race.copy(results = emptyList())); "sprint" -> save(race.copy(sprintResults = emptyList())); "disable" -> save(race.copy(sprintEnabled = false, sprintResults = emptyList())) }
            confirm = null
        }
    }
}

@Composable
private fun GridEditor(c: Championship, race: Race, sprint: Boolean, onBack: () -> Unit, onSave: (Race) -> Unit) {
    val results = if (sprint) race.sprintResults else race.results
    var grids by rememberSaveable(c.id, race.id, sprint) { mutableStateOf(results.joinToString(",") { it.gridPosition?.toString() ?: "" }) }
    var penalties by rememberSaveable(c.id, race.id, sprint) { mutableStateOf(results.joinToString(",") { it.penalty.toString() }) }
    var error by remember { mutableStateOf<String?>(null) }
    var discard by remember { mutableStateOf(false) }
    BackHandler { discard = true }
    Column {
        DetailTopBar("${if (sprint) "Sprint" else "Race"} grid & penalties", { discard = true })
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Text("Grid positions are optional. Leave unknown positions blank. Penalties deduct points and may produce negative totals. Grid P1 is not necessarily a qualifying pole.") }
            items(results.indices.toList()) { i ->
                Text(c.driverOrPlaceholder(results[i].driverId).name)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(grids.split(',')[i], { v -> if (v.length <= 2 && v.all(Char::isDigit)) grids = grids.split(',').toMutableList().also { it[i] = v }.joinToString(",") }, Modifier.weight(1f), label = { Text("Grid 1–24") }, singleLine = true)
                    OutlinedTextField(penalties.split(',')[i], { v -> if (v.length <= 4 && v.all(Char::isDigit)) penalties = penalties.split(',').toMutableList().also { it[i] = v }.joinToString(",") }, Modifier.weight(1f), label = { Text("Penalty points") }, singleLine = true)
                }
            }
        }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp)) }
        Button({ Feedback.emit(); runCatching {
            val edited = results.mapIndexed { i, r -> r.copy(gridPosition = grids.split(',')[i].toIntOrNull(), penalty = penalties.split(',')[i].toIntOrNull() ?: 0) }
            val updated = if (sprint) race.copy(sprintResults = edited) else race.copy(results = edited)
            Validation.check(c.copy(races = c.races.map { if (it.id == race.id) updated else it })); updated
        }.onSuccess(onSave).onFailure { error = it.message } }, Modifier.fillMaxWidth().padding(12.dp)) { Text("Save grid & penalties") }
    }
    if (discard) ConfirmDialog("Discard grid edits?", "Only saved values will be kept.", "Discard", { discard = false }, onBack)
}
