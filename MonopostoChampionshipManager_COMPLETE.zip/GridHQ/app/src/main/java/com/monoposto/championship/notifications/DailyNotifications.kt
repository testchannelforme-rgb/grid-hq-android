package com.monoposto.championship.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import com.monoposto.championship.MainActivity
import com.monoposto.championship.R
import com.monoposto.championship.data.*
import com.monoposto.championship.domain.DailyHighlights
import java.time.LocalDate
import java.time.ZonedDateTime
import java.util.concurrent.TimeUnit

object DailyNotifications {
    const val CHANNEL = "daily_championship"
    private const val WORK = "gridhq_daily_highlight"
    fun prefs(context: Context) = context.getSharedPreferences("gridhq_notifications", Context.MODE_PRIVATE)
    fun permitted(context: Context): Boolean = (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) && NotificationManagerCompat.from(context).areNotificationsEnabled()
    fun schedule(context: Context) {
        if (prefs(context).getBoolean("enabled", false)) {
            val request = PeriodicWorkRequestBuilder<DailyHighlightWorker>(15, TimeUnit.MINUTES).build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.KEEP, request)
        } else WorkManager.getInstance(context).cancelUniqueWork(WORK)
    }
    fun enable(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean("enabled", enabled).apply()
        schedule(context)
        if (!enabled) NotificationManagerCompat.from(context).cancel(4201)
    }
}

class DailyHighlightWorker(context: Context, parameters: WorkerParameters) : CoroutineWorker(context, parameters) {
    override suspend fun doWork(): Result {
        val context = applicationContext
        val prefs = DailyNotifications.prefs(context)
        if (!prefs.getBoolean("enabled", false) || !DailyNotifications.permitted(context)) return Result.success()
        val now = ZonedDateTime.now()
        val start = prefs.getInt("start", 8).coerceIn(0, 23)
        val end = prefs.getInt("end", 21).coerceIn(start + 1, 24)
        val dayKey = "${now.toLocalDate()}:${now.zone.id}:$start:$end"
        if (prefs.getString("target_day", null) != dayKey) {
            prefs.edit().putString("target_day", dayKey).putInt("target_minute", DailyHighlights.targetMinute(start, end)).commit()
        }
        val last = runCatching { LocalDate.parse(prefs.getString("last_sent", null)) }.getOrNull()
        if (!DailyHighlights.isDue(now, prefs.getInt("target_minute", start * 60), last, start, end)) return Result.success()
        return try {
            // Read Room at delivery time, not a cached notification payload or a network feed.
            val all = ChampionshipRepository(ChampionshipDatabase.get(context)).loadAll()
            val selectedId = context.getSharedPreferences("gridhq", 0).getLong("selected", -1)
            val c = all.firstOrNull { it.id == selectedId } ?: all.firstOrNull()
            val highlight = DailyHighlights.build(c, now.toLocalDate())
            // Recheck after I/O: never post after opt-out or beyond quiet hours.
            if (!prefs.getBoolean("enabled", false) || !DailyHighlights.isDue(ZonedDateTime.now(), prefs.getInt("target_minute", start * 60), last, start, end)) return Result.success()
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(DailyNotifications.CHANNEL, "Daily race highlights", NotificationManager.IMPORTANCE_LOW).apply {
                description = "A daily recap of your recorded races and standings"; setSound(null, null); enableVibration(false)
            })
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra("highlight", true)
                highlight.championshipId?.let { putExtra("championship_id", it) }
                highlight.raceId?.let { putExtra("race_id", it) }
            }
            val pending = PendingIntent.getActivity(context, 4201, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val notification = NotificationCompat.Builder(context, DailyNotifications.CHANNEL)
                .setSmallIcon(R.drawable.ic_notification).setContentTitle(highlight.title).setContentText(highlight.body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(highlight.body)).setContentIntent(pending)
                .setAutoCancel(true).setOnlyAlertOnce(true).setSilent(true).build()
            manager.notify(4201, notification)
            prefs.edit().putString("last_sent", now.toLocalDate().toString()).commit()
            Result.success()
        } catch (e: SecurityException) { Result.success() }
        catch (e: Exception) {
            if (e is kotlinx.coroutines.CancellationException) throw e
            Result.retry()
        }
    }
}
