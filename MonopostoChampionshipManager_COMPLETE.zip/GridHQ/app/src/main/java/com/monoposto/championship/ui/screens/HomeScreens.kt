@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.monoposto.championship

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.monoposto.championship.data.*
import com.monoposto.championship.domain.ChampionshipEngine
import com.monoposto.championship.ui.*
import java.util.Locale

@Composable
internal fun AppTopBar(c: Championship, onChampionship: () -> Unit) {
    TopAppBar(
        title = {
            Column(Modifier.clickable(onClick = onChampionship)) {
                Text(c.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
                Text(c.season, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        actions = { IconButton(onClick = onChampionship) { Icon(Icons.Default.ExpandMore, "Switch championship") } },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
    )
}

@Composable
internal fun BottomNavigation(tab: TopTab, onSelect: (TopTab) -> Unit) {
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
        val icons = mapOf(
            TopTab.HOME to Icons.Default.Home,
            TopTab.STANDINGS to Icons.Default.EmojiEvents,
            TopTab.RACES to Icons.Default.SportsScore,
            TopTab.STATS to Icons.Default.BarChart,
            TopTab.SETTINGS to Icons.Default.Settings
        )
        TopTab.entries.forEach { item ->
            NavigationBarItem(
                selected = tab == item,
                onClick = { Feedback.emit(); onSelect(item) },
                icon = { Icon(icons.getValue(item), item.label) },
                label = { Text(item.label, fontSize = 10.sp) },
                colors = NavigationBarItemDefaults.colors(indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = .16f))
            )
        }
    }
}

@Composable
internal fun EmptyState(onCreate: () -> Unit) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(72.dp).clip(RoundedCornerShape(22.dp)).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.SportsMotorsports, null, Modifier.size(42.dp), tint = Color.White)
                }
                Spacer(Modifier.height(20.dp))
                Text("GRIDHQ", color = MaterialTheme.colorScheme.primary, letterSpacing = 4.sp, fontWeight = FontWeight.Black)
                Text("Championship Manager", fontSize = 28.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(10.dp))
                Text("Offline season tracking for 24 drivers and 12 teams.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(22.dp))
                Button(onClick = onCreate, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Create championship") }
            }
        }
    }
}

@Composable
internal fun SectionHeader(title: String, subtitle: String? = null, action: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 22.sp, fontWeight = FontWeight.Black)
            if (subtitle != null) Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        }
        action?.invoke()
    }
}

@Composable
internal fun HomeScreen(c: Championship, onRace: (Int) -> Unit, onStandings: () -> Unit) {
    val ds = remember(c) { ChampionshipEngine.driverStandings(c) }
    val ts = remember(c) { ChampionshipEngine.teamStandings(c) }
    val completed = c.races.filter { it.completed }
    val latest = completed.maxByOrNull { it.round }
    val next = c.races.firstOrNull { !it.completed }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 20.dp)) {
        item {
            Column(Modifier.padding(18.dp, 12.dp, 18.dp, 6.dp)) {
                Text("GRIDHQ", color = MaterialTheme.colorScheme.primary, letterSpacing = 4.sp, fontWeight = FontWeight.Black)
                Text("CHAMPIONSHIP MANAGER", fontSize = 25.sp, fontWeight = FontWeight.Black)
            }
        }
        item {
            LeaderHero(c, ds.firstOrNull().takeIf { c.races.any { it.completed || it.sprintCompleted } }, ts.firstOrNull().takeIf { c.races.any { it.completed || it.sprintCompleted } }, completed.size)
        }
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                item { MiniMetric("Season progress", "${completed.size} / ${c.races.size}", Icons.Default.Timeline) }
                item { MiniMetric("Driver leader", ds.firstOrNull()?.let { "${it.points} pts" } ?: "0 pts", Icons.Default.Person) }
                item { MiniMetric("Constructor", ts.firstOrNull()?.let { "${it.points} pts" } ?: "0 pts", Icons.Default.Groups) }
            }
        }
        item {
            SectionHeader("Race control", if (next != null) "Next: Round ${next.round} · ${next.name}" else "Season complete")
        }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { Feedback.emit(); (next ?: latest)?.let { onRace(it.id) } }, enabled = next != null || latest != null, modifier = Modifier.weight(1f)) {
                    Icon(if (next != null) Icons.Default.Edit else Icons.Default.Visibility, null); Spacer(Modifier.width(7.dp)); Text(if (next != null) "Enter result" else "Latest result")
                }
                OutlinedButton(onClick = onStandings, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Leaderboard, null); Spacer(Modifier.width(7.dp)); Text("Standings") }
            }
        }
        item { SectionHeader("Latest race") }
        item {
            LatestRaceCard(c, latest, onRace)
        }
    }
}

@Composable
internal fun LeaderHero(c: Championship, driver: DriverStanding?, team: TeamStanding?, completed: Int) {
    val stripe = driver?.team?.let { Color(it.colorArgb) } ?: MaterialTheme.colorScheme.primary
    ElevatedCard(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Row(
            Modifier.fillMaxWidth().height(IntrinsicSize.Min).background(
                Brush.horizontalGradient(listOf(stripe.copy(alpha = .13f), MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.surfaceVariant))
            )
        ) {
            Box(Modifier.width(5.dp).fillMaxHeight().background(stripe))
            Column(Modifier.padding(18.dp).weight(1f)) {
                Text("CURRENT CHAMPIONSHIP", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.1.sp)
                Text(c.name, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Text("CHAMPIONSHIP LEADER", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 1.3.sp)
                Text(driver?.driver?.name ?: "No results yet", fontSize = 28.sp, fontWeight = FontWeight.Black)
                Text(driver?.let { "${it.team.name}  •  ${it.points} PTS" } ?: "Complete a race to create standings", color = MaterialTheme.colorScheme.onSurfaceVariant)
                HorizontalDivider(Modifier.padding(vertical = 14.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = .45f))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Text("CONSTRUCTOR LEADER", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(team?.let { "${it.team.name} · ${it.points} PTS" } ?: "—", fontWeight = FontWeight.Bold) }
                    Column(horizontalAlignment = Alignment.End) { Text("PROGRESS", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant); Text("RACE $completed / ${c.races.size}", fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}

@Composable
internal fun MiniMetric(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(10.dp))
            Column { Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(value, fontWeight = FontWeight.Black) }
        }
    }
}

@Composable
internal fun LatestRaceCard(c: Championship, race: Race?, onRace: (Int) -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp).clickable(enabled = race != null) { race?.let { onRace(it.id) } }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        if (race == null) {
            Text("No completed races yet.", Modifier.padding(18.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            val ordered = race.results.filter { it.status == ResultStatus.FINISHED }.sortedBy { it.finishPosition }
            val winner = ordered.firstOrNull()?.let { r -> c.drivers.firstOrNull { it.id == r.driverId } }
            val fl = race.results.firstOrNull { it.fastestLap }?.let { r -> c.drivers.firstOrNull { it.id == r.driverId } }
            Column(Modifier.padding(18.dp)) {
                Text("ROUND ${race.round}", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp, fontWeight = FontWeight.Black)
                Text(race.name, fontSize = 22.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Winner", color = MaterialTheme.colorScheme.onSurfaceVariant); Text(winner?.name ?: "—", fontWeight = FontWeight.Bold) }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Fastest lap", color = MaterialTheme.colorScheme.onSurfaceVariant); Text(fl?.name ?: "—", fontWeight = FontWeight.Bold) }
            }
        }
    }
}
