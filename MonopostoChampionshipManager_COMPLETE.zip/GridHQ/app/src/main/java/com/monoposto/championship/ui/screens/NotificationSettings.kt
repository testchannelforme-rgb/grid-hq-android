package com.monoposto.championship

import android.Manifest
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.monoposto.championship.notifications.DailyNotifications

@Composable
internal fun NotificationSettings() {
    val context = LocalContext.current
    val prefs = remember { DailyNotifications.prefs(context) }
    var enabled by remember { mutableStateOf(prefs.getBoolean("enabled", false)) }
    var explain by remember { mutableStateOf(false) }
    var denied by remember { mutableStateOf(false) }
    var start by remember { mutableIntStateOf(prefs.getInt("start", 8)) }
    var end by remember { mutableIntStateOf(prefs.getInt("end", 21)) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        enabled = granted; denied = !granted
        DailyNotifications.enable(context, granted)
        Feedback.emit(if (granted) FeedbackKind.SUCCESS else FeedbackKind.SELECTION)
    }
    SettingsGroup("Daily race highlights") {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Get daily race results", style = MaterialTheme.typography.titleMedium)
                Text("Latest saved results or a standings highlight, once a day.", style = MaterialTheme.typography.bodySmall)
            }
            Switch(enabled, { value ->
                Feedback.emit(FeedbackKind.SELECTION)
                if (value) explain = true else { enabled = false; DailyNotifications.enable(context, false) }
            })
        }
        if (enabled) {
            Text("Delivery window · %02d:00–%02d:00".format(start, end), Modifier.padding(horizontal = 16.dp))
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = start == 8, onClick = { start = 8; end = 21; prefs.edit().putInt("start", start).putInt("end", end).apply(); Feedback.emit(FeedbackKind.SELECTION) }, label = { Text("08–21") })
                FilterChip(selected = start == 10, onClick = { start = 10; end = 20; prefs.edit().putInt("start", start).putInt("end", end).apply(); Feedback.emit(FeedbackKind.SELECTION) }, label = { Text("10–20") })
            }
        }
        Text("A random time in your local delivery window. Battery restrictions may delay or skip a day; Grid HQ never intentionally sends during quiet hours. Uses your recorded championships, with no live racing feed.", Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (denied || (enabled && !DailyNotifications.permitted(context))) {
            Text("Notifications are blocked by Android. You can enable them in system settings whenever you want.", Modifier.padding(horizontal = 16.dp))
            TextButton({ runCatching { context.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)) } }) { Text("Open notification settings") }
        }
    }
    if (explain) AlertDialog(onDismissRequest = { explain = false }, title = { Text("Get daily race results") }, text = { Text("Receive one daily recap of your latest recorded race or championship standings. Tap it to open the relevant results. You can turn this off at any time.") }, confirmButton = {
        Button({
            explain = false
            if (Build.VERSION.SDK_INT >= 33 && !DailyNotifications.permitted(context)) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
            else if (DailyNotifications.permitted(context)) { enabled = true; DailyNotifications.enable(context, true) }
            else denied = true
        }) { Text("Enable highlights") }
    }, dismissButton = { TextButton({ explain = false }) { Text("Not now") } })
}
