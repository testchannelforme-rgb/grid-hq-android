@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.monoposto.championship

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.monoposto.championship.data.*
import com.monoposto.championship.domain.ChampionshipEngine
import com.monoposto.championship.ui.*
import java.util.Locale

@Composable
internal fun PeopleScreen(c: Championship, onBack: () -> Unit, onSave: (Championship) -> Unit) {
    var editTeam by remember { mutableStateOf<Team?>(null) }
    var editDriver by remember { mutableStateOf<Driver?>(null) }
    Column(Modifier.fillMaxSize()) {
        DetailTopBar("Drivers & Teams", onBack)
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(c.teams.sortedBy { it.id }, key = { it.id }) { team ->
                val drivers = c.drivers.filter { it.teamId == team.id }.sortedBy { it.id }
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
                        Box(Modifier.width(5.dp).fillMaxHeight().background(Color(team.colorArgb)))
                        Column(Modifier.padding(14.dp).weight(1f)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) { Text(team.name, fontWeight = FontWeight.Black, fontSize = 18.sp); Text(team.abbreviation, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp) }
                                IconButton(onClick = { Feedback.emit(); editTeam = team }) { Icon(Icons.Default.Edit, "Edit team") }
                            }
                            drivers.forEach { d ->
                                Row(Modifier.fillMaxWidth().clickable { Feedback.emit(FeedbackKind.NAVIGATION); editDriver = d }.padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("#${d.number}", Modifier.width(46.dp), fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                                    Column(Modifier.weight(1f)) { Text(d.name, fontWeight = FontWeight.Bold); Text(d.abbreviation, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                                    Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    editTeam?.let { team -> TeamEditDialog(team, onDismiss = { editTeam = null }) { updated -> onSave(c.copy(teams = c.teams.map { if (it.id == updated.id) updated else it })); editTeam = null } }
    editDriver?.let { driver -> DriverEditDialog(c, driver, onDismiss = { editDriver = null }) { updated, swapWith ->
        var drivers = c.drivers.map { if (it.id == updated.id) updated else it }
        if (swapWith != null && swapWith.id != updated.id && swapWith.teamId != updated.teamId) {
            val originalTeam = driver.teamId
            val targetTeam = swapWith.teamId
            drivers = drivers.map {
                when (it.id) {
                    updated.id -> updated.copy(teamId = targetTeam)
                    swapWith.id -> it.copy(teamId = originalTeam)
                    else -> it
                }
            }
        }
        onSave(c.copy(drivers = drivers)); editDriver = null
    } }
}

