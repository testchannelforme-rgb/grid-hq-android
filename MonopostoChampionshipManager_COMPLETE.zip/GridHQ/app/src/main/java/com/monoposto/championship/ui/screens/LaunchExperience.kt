package com.monoposto.championship

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

// Community invitation supplied by the app owner.
internal object CommunityConfig { const val DISCORD_INVITE = "https://discord.gg/yCHkDv9dTK" }

private val Electric = Color(0xFFF32E43)
private fun prefs(context: Context) = context.getSharedPreferences("gridhq_experience", Context.MODE_PRIVATE)

/** Plays the owner's supplied film without cropping, then waits for actual database readiness. */
@Composable
internal fun LaunchExperience(loading: Boolean, content: @Composable () -> Unit) {
    val context = LocalContext.current
    val reduced = remember { prefs(context).getBoolean("reduce_motion", false) || !android.animation.ValueAnimator.areAnimatorsEnabled() }
    var filmDone by rememberSaveable { mutableStateOf(reduced) }
    var invitation by rememberSaveable { mutableStateOf(true) }
    var slow by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(1200); slow = true }
    val showing = !filmDone || loading
    Box(Modifier.fillMaxSize()) {
        content()
        AnimatedVisibility(showing, enter = fadeIn(tween(0)), exit = fadeOut(tween(if (reduced) 0 else 280))) {
            Box(Modifier.fillMaxSize().background(Color.Black).safeDrawingPadding(), contentAlignment = Alignment.Center) {
                Image(painterResource(R.drawable.gridhq_poster), "Grid HQ. Your Championship Manager App", Modifier.fillMaxWidth(), contentScale = androidx.compose.ui.layout.ContentScale.Fit)
                if (!filmDone) IntroFilm { filmDone = true }
                Column(Modifier.align(Alignment.BottomCenter).padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (slow && loading) {
                        CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = Electric)
                        Text("Preparing your championship…", color = Color.White, style = MaterialTheme.typography.bodySmall)
                    }
                    if (!filmDone) TextButton({ filmDone = true }) { Text("Skip animation", color = Electric) }
                }
            }
        }
    }
    if (!showing && invitation) DiscordInvitation { invitation = false }
}

@Composable
private fun IntroFilm(onFinished: () -> Unit) {
    val context = LocalContext.current
    val done by rememberUpdatedState(onFinished)
    val owner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    val video = remember {
        android.widget.VideoView(context).apply {
            setVideoURI(android.net.Uri.parse("android.resource://${context.packageName}/${R.raw.gridhq_intro}"))
            setOnPreparedListener { player ->
                // Keep the launch film silent; UI feedback has its own user-controlled channel.
                player.setVolume(0f, 0f)
                start()
            }
            setOnCompletionListener { done() }
            setOnErrorListener { _, _, _ -> done(); true }
        }
    }
    DisposableEffect(video, owner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            when (event) {
                androidx.lifecycle.Lifecycle.Event.ON_PAUSE -> video.pause()
                androidx.lifecycle.Lifecycle.Event.ON_RESUME -> video.start()
                else -> Unit
            }
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer); video.stopPlayback() }
    }
    // An aspect-ratio box lets VideoView keep the complete supplied composition on every display.
    BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        val ratio = 1920f / 1078f
        val width = minOf(maxWidth, maxHeight * ratio)
        androidx.compose.ui.viewinterop.AndroidView(factory = { video }, modifier = Modifier.width(width).height(width / ratio))
    }
}

@Composable
private fun DiscordInvitation(onDismiss: () -> Unit) {
    val uri = LocalUriHandler.current
    var error by remember { mutableStateOf<String?>(null) }
    val configured = CommunityConfig.DISCORD_INVITE.startsWith("https://discord.gg/") || CommunityConfig.DISCORD_INVITE.startsWith("https://discord.com/invite/")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Join our Discord", Modifier.weight(1f))
            IconButton(onDismiss) { Icon(Icons.Default.Close, "Close invitation") }
        } },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Please join our Discord! Share your championship, suggest features and meet other players.")
            if (configured) Text(CommunityConfig.DISCORD_INVITE)
            else Text("The community invite has not been configured in this build.")
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        } },
        confirmButton = { Button(onClick = {
            runCatching { uri.openUri(CommunityConfig.DISCORD_INVITE) }
                .onSuccess { onDismiss() }
                .onFailure { error = "Could not open Discord. Try the invite in your browser." }
        }, enabled = configured) { Text("Join Discord") } },
        dismissButton = { TextButton(onDismiss) { Text("Maybe later") } }
    )
}

@Composable
internal fun ExperienceSettings() {
    val context = LocalContext.current
    var sound by remember { mutableStateOf(prefs(context).getBoolean("sound", true)) }
    var haptics by remember { mutableStateOf(prefs(context).getBoolean("haptics", true)) }
    var motion by remember { mutableStateOf(prefs(context).getBoolean("reduce_motion", false)) }
    SettingsGroup("Look & sound") {
        Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Sound effects", Modifier.weight(1f))
            Switch(sound, { sound = it; prefs(context).edit().putBoolean("sound", it).apply() })
        }
        Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Haptic feedback", Modifier.weight(1f))
            Switch(haptics, { haptics = it; prefs(context).edit().putBoolean("haptics", it).apply(); Feedback.emit(FeedbackKind.SELECTION) })
        }
        Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Reduce motion", Modifier.weight(1f))
            Switch(motion, { motion = it; prefs(context).edit().putBoolean("reduce_motion", it).apply() })
        }
        Text("Intro motion changes apply on the next launch. Sounds follow media volume and silent mode.", Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
internal fun ResultMoment(savedPulse: Int, recorded: Boolean, onConsumed: () -> Unit) {
    val context = LocalContext.current
    val reduced = remember { prefs(context).getBoolean("reduce_motion", false) }
    var celebrate by remember { mutableStateOf(false) }
    LaunchedEffect(savedPulse) {
        if (savedPulse > 0) {
            try {
                celebrate = true
                Feedback.emit(FeedbackKind.SUCCESS)
                delay(3000)
            } finally {
                celebrate = false
                onConsumed()
            }
        }
    }
    Column {
        Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF351C25), Color(0xFF11161C)))).padding(20.dp)) {
            Column {
                Text(if (recorded) "SESSION RECORDED" else "READY FOR LIGHTS OUT", color = Electric, style = MaterialTheme.typography.labelLarge)
                Text(if (recorded) "Every point tells a story." else "Make this round count.", color = Color.White, style = MaterialTheme.typography.titleLarge)
            }
        }
        AnimatedVisibility(celebrate, enter = fadeIn(tween(if (reduced) 0 else 220)) + expandVertically(tween(if (reduced) 0 else 220)), exit = fadeOut(tween(if (reduced) 0 else 180)) + shrinkVertically(tween(if (reduced) 0 else 180))) {
            Text("✓ Results saved · Standings updated", Modifier.fillMaxWidth().padding(16.dp), color = Electric, style = MaterialTheme.typography.titleMedium)
        }
    }
}
