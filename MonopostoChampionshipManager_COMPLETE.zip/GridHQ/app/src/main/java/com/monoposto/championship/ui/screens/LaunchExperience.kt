package com.monoposto.championship

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

// Community invitation supplied by the app owner.
internal object CommunityConfig { const val DISCORD_INVITE = "https://discord.gg/yCHkDv9dTK" }

private val Electric = Color(0xFF48E5C2)
private fun prefs(context: Context) = context.getSharedPreferences("gridhq_experience", Context.MODE_PRIVATE)

/** Short synthesized cue; obeys media volume, silent mode, and the local opt-out. */
private suspend fun playSavedCue(context: Context) {
    if (!prefs(context).getBoolean("sound", true)) return
    val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    if (audio.ringerMode != AudioManager.RINGER_MODE_NORMAL || audio.getStreamVolume(AudioManager.STREAM_MUSIC) == 0) return
    val tone = runCatching { ToneGenerator(AudioManager.STREAM_MUSIC, 25) }.getOrNull() ?: return
    try {
        tone.startTone(ToneGenerator.TONE_PROP_ACK, 140)
        delay(180)
    } finally { tone.release() }
}

@Composable
internal fun LaunchExperience(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val reduced = remember { prefs(context).getBoolean("reduce_motion", false) }
    // Survives rotation and process restoration; a fresh launch invites again.
    var intro by rememberSaveable { mutableStateOf(true) }
    var invitation by rememberSaveable { mutableStateOf(true) }
    val progress = remember { Animatable(if (reduced) 1f else 0f) }
    LaunchedEffect(Unit) {
        if (intro) {
            if (!reduced) progress.animateTo(1f, tween(1500))
            delay(if (reduced) 100 else 250)
            intro = false
        }
    }
    Box(Modifier.fillMaxSize()) {
        content() // Load real data while the intro plays; never a fake progress bar.
        if (intro) {
            Surface(Modifier.fillMaxSize(), color = Color(0xFF090F19)) {
                Column(Modifier.fillMaxSize().safeDrawingPadding(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Image(painterResource(R.drawable.ic_launcher_foreground), "Grid HQ logo", Modifier.size(120.dp).graphicsLayer { alpha = if (reduced) 1f else ((progress.value - .35f) / .4f).coerceIn(0f, 1f) })
                    Text("GRID HQ", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Black, color = Color.White)
                    Text("YOUR SEASON. YOUR STORY.", color = Electric, style = MaterialTheme.typography.labelMedium)
                    Canvas(Modifier.fillMaxWidth().height(100.dp)) {
                        val y = size.height * .62f
                        drawLine(Electric.copy(alpha = .35f), Offset(0f, y + 16.dp.toPx()), Offset(size.width, y + 16.dp.toPx()), 2.dp.toPx())
                        val carWidth = 94.dp.toPx()
                        val x = if (reduced) (size.width - carWidth) / 2 else -carWidth + (size.width + carWidth * 2) * progress.value
                        // Original geometric open-wheel silhouette; no team livery or badges.
                        drawRoundRect(Electric, Offset(x + carWidth * .15f, y - 10.dp.toPx()), Size(carWidth * .7f, 16.dp.toPx()), androidx.compose.ui.geometry.CornerRadius(8f))
                        drawRect(Color.White, Offset(x + carWidth * .72f, y - 8.dp.toPx()), Size(carWidth * .28f, 6.dp.toPx()))
                        drawRect(Electric, Offset(x, y - 20.dp.toPx()), Size(carWidth * .08f, 22.dp.toPx()))
                        drawCircle(Color(0xFF53627A), 12.dp.toPx(), Offset(x + carWidth * .2f, y + 3.dp.toPx()))
                        drawCircle(Color(0xFF53627A), 10.dp.toPx(), Offset(x + carWidth * .8f, y + 5.dp.toPx()))
                        drawCircle(Color(0xFF090F19), 6.dp.toPx(), Offset(x + carWidth * .44f, y - 9.dp.toPx()))
                    }
                    TextButton({ intro = false }) { Text("Skip intro", color = Electric) }
                }
            }
        }
    }
    if (!intro && invitation) DiscordInvitation { invitation = false }
}

@Composable
private fun DiscordInvitation(onDismiss: () -> Unit) {
    val uri = LocalUriHandler.current
    var error by remember { mutableStateOf<String?>(null) }
    val configured = CommunityConfig.DISCORD_INVITE.startsWith("https://discord.gg/") || CommunityConfig.DISCORD_INVITE.startsWith("https://discord.com/invite/")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Join our Discord", Modifier.weight(1f))
            IconButton(onDismiss) { Icon(Icons.Default.Close, "Close invitation") }
        } },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Please join our Discord! Share your championship, suggest features and meet other players.")
            if (configured) Text(CommunityConfig.DISCORD_INVITE)
            else Text("The community invite has not been configured in this build.")
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        } },
        confirmButton = { Button(onClick = {
            runCatching { uri.openUri(CommunityConfig.DISCORD_INVITE) }
                .onSuccess { onDismiss() }
                .onFailure { error = "Could not open Discord. Try the invite in your browser." }
        }, enabled = configured) { Text("Join Discord") } },
        dismissButton = { TextButton(onDismiss) { Text("Maybe later") } }
    )
}

@Composable
internal fun ExperienceSettings() {
    val context = LocalContext.current
    var sound by remember { mutableStateOf(prefs(context).getBoolean("sound", true)) }
    var motion by remember { mutableStateOf(prefs(context).getBoolean("reduce_motion", false)) }
    SettingsGroup("Look & sound") {
        Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Result confirmation sound", Modifier.weight(1f))
            Switch(sound, { sound = it; prefs(context).edit().putBoolean("sound", it).apply() })
        }
        Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Reduce motion", Modifier.weight(1f))
            Switch(motion, { motion = it; prefs(context).edit().putBoolean("reduce_motion", it).apply() })
        }
        Text("Intro motion changes apply on the next launch. Sounds follow media volume and silent mode.", Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
internal fun ResultMoment(savedPulse: Int, recorded: Boolean, onConsumed: () -> Unit) {
    val context = LocalContext.current
    val reduced = remember { prefs(context).getBoolean("reduce_motion", false) }
    var celebrate by remember { mutableStateOf(false) }
    LaunchedEffect(savedPulse) {
        if (savedPulse > 0) {
            try {
                celebrate = true
                playSavedCue(context)
                delay(3000)
            } finally {
                celebrate = false
                onConsumed()
            }
        }
    }
    Column {
        Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF143E41), Color(0xFF101A2A)))).padding(20.dp)) {
            Column {
                Text(if (recorded) "SESSION RECORDED" else "READY FOR LIGHTS OUT", color = Electric, style = MaterialTheme.typography.labelLarge)
                Text(if (recorded) "Every point tells a story." else "Make this round count.", color = Color.White, style = MaterialTheme.typography.titleLarge)
            }
        }
        AnimatedVisibility(celebrate, enter = fadeIn(tween(if (reduced) 0 else 220)) + expandVertically(tween(if (reduced) 0 else 220)), exit = fadeOut(tween(if (reduced) 0 else 180)) + shrinkVertically(tween(if (reduced) 0 else 180))) {
            Text("✓ Results saved · Standings updated", Modifier.fillMaxWidth().padding(16.dp), color = Electric, style = MaterialTheme.typography.titleMedium)
        }
    }
}
