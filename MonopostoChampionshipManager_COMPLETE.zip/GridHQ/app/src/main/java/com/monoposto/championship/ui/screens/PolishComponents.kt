package com.monoposto.championship

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
internal fun EmptyCard(title: String, message: String, action: String? = null, onAction: () -> Unit = {}) {
    Card(Modifier.fillMaxWidth().padding(16.dp)) {
        Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(Icons.Default.Flag, null, tint = MaterialTheme.colorScheme.primary)
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (action != null) OutlinedButton(onAction) { Text(action) }
        }
    }
}

@Composable
internal fun MissingDetail(title: String, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().safeDrawingPadding()) {
        DetailTopBar(title, onBack)
        EmptyCard("This entry is no longer available", "It may have been removed or changed. Your other championship records are safe.", "Back to championship", onBack)
    }
}

@Composable
internal fun AnimatedPoints(points: Int) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val reduced = context.getSharedPreferences("gridhq_experience", 0).getBoolean("reduce_motion", false)
    val display = androidx.compose.animation.core.animateIntAsState(points, animationSpec = androidx.compose.animation.core.tween(if (reduced) 0 else 450), label = "Championship points")
    Text("${display.value}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
}
