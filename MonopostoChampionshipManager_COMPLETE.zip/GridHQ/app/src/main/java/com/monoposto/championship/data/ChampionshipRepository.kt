package com.monoposto.championship.data

import androidx.room.withTransaction

class ChampionshipRepository(private val db: ChampionshipDatabase) {
    private val dao = db.dao()

    suspend fun loadAll(): List<Championship> = db.withTransaction { dao.championships().map { load(it) } }

    private suspend fun load(root: ChampionshipEntity): Championship {
        if (root.payload.isNotEmpty()) return BackupCodec.import(root.payload, false).also { com.monoposto.championship.domain.Validation.check(it) }
        val teams = dao.teams(root.id).map { Team(it.id, it.name, it.abbreviation, it.colorArgb) }
        val drivers = dao.drivers(root.id).map { Driver(it.id, it.name, it.number, it.abbreviation, it.teamId) }
        val resultRows = dao.results(root.id).groupBy { it.raceId }
        val races = dao.races(root.id).map { race ->
            Race(
                id = race.id,
                round = race.round,
                name = race.name,
                results = resultRows[race.id].orEmpty().map { r ->
                    DriverRaceResult(r.driverId, r.finishPosition, r.status, r.points, r.fastestLap, teamId = drivers.first { it.id == r.driverId }.teamId)
                }
            )
        }
        val scoringRows = dao.scoring(root.id)
        val scoring = ScoringRules(
            positionPoints = (1..DRIVER_COUNT).map { p -> scoringRows.firstOrNull { it.position == p }?.points ?: 0 },
            fastestLapPoints = root.fastestLapPoints
        )
        return Championship(root.id, root.name, root.season, races, teams, drivers, scoring)
    }

    suspend fun save(championship: Championship) = db.withTransaction {
        com.monoposto.championship.domain.Validation.check(championship)
        val existing = dao.championship(championship.id)
        require(existing != null || championship.revision == 0L) { "This championship was deleted. Import a backup to restore it." }
        val revision = existing?.let { if (it.payload.isEmpty()) 0L else BackupCodec.import(it.payload, false).revision }
        require(revision == null || revision == championship.revision) { "This championship changed while editing. Reopen it and try again." }
        val saved = com.monoposto.championship.domain.ChampionshipEngine.recalculateAll(championship).copy(revision = championship.revision + 1)
        dao.upsertChampionship(ChampionshipEntity(saved.id, saved.name, saved.season, saved.scoring.fastestLapPoints, BackupCodec.export(saved)))
    }

    suspend fun delete(championshipId: Long) = dao.deleteChampionship(championshipId)

}
