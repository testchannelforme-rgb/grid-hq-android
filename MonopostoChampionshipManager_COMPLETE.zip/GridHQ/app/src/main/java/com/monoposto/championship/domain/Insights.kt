package com.monoposto.championship.domain

import com.monoposto.championship.data.*
import kotlin.math.sqrt

data class Prediction(val driver: Driver, val score: Double, val confidence: String, val factors: Map<String, Double>)
data class ProgressPoint(val round: Int, val name: String, val total: Int, val gained: Int, val position: Int)

object Insights {
    // Scores are normalized to 0..1 before weighting; these are heuristic scores, not win probabilities.
    val weights = linkedMapOf("Recent form" to 30.0, "Average finish" to 12.0, "Wins" to 8.0,
        "Podiums" to 8.0, "Reliability" to 12.0, "Consistency" to 8.0, "Fastest laps" to 4.0,
        "Grid performance" to 5.0, "Positions gained" to 5.0, "Season points" to 4.0, "Development" to 4.0)

    fun consistency(results: List<DriverRaceResult>): Double? {
        val ps = results.filter { it.status == ResultStatus.FINISHED }.mapNotNull { it.finishPosition?.toDouble() }
        if (ps.size < 2) return null
        val mean = ps.average()
        return (1.0 - sqrt(ps.map { (it - mean) * (it - mean) }.average()) / 11.5).coerceIn(0.0, 1.0)
    }

    fun predictions(c: Championship): List<Prediction> {
        val standings = ChampionshipEngine.driverStandings(c)
        val maxPoints = standings.maxOfOrNull { it.points }?.coerceAtLeast(1) ?: 1
        return standings.map { s ->
            val rs = s.raceResults.map { it.second }.filter { it.status != ResultStatus.DNS }
            val recent = rs.takeLast(5)
            fun finish(r: DriverRaceResult) = if (r.status == ResultStatus.FINISHED) (25.0 - (r.finishPosition ?: 24)) / 24.0 else 0.0
            val form = if (recent.isEmpty()) 0.5 else recent.mapIndexed { i, r -> finish(r) * (i + 1) }.sum() / (recent.size * (recent.size + 1) / 2.0)
            val knownGrid = rs.filter { it.gridPosition != null }
            val gained = rs.filter { it.gridPosition != null && it.finishPosition != null }
            val n = rs.size.coerceAtLeast(1).toDouble()
            val raw = linkedMapOf(
                "Recent form" to form,
                "Average finish" to (if (rs.isEmpty()) .5 else rs.map(::finish).average()),
                "Wins" to s.wins / n, "Podiums" to s.podiums / n,
                "Reliability" to (if (rs.isEmpty()) .5 else rs.count { it.status == ResultStatus.FINISHED } / n),
                "Consistency" to (consistency(rs) ?: .5), "Fastest laps" to s.fastestLaps / n,
                "Grid performance" to (if (knownGrid.isEmpty()) .5 else knownGrid.map { (25.0 - it.gridPosition!!) / 24.0 }.average()),
                "Positions gained" to (if (gained.isEmpty()) .5 else gained.map { (.5 + (it.gridPosition!! - it.finishPosition!!) / 46.0).coerceIn(0.0, 1.0) }.average()),
                "Season points" to (if (rs.isEmpty()) .5 else (s.points.toDouble() / maxPoints).coerceIn(0.0, 1.0)),
                "Development" to (if (c.developmentEnabled) developmentStrength(c, s.driver.teamId) else .5)
            )
            val contributions = raw.mapValues { (k, v) -> v * weights.getValue(k) }
            Prediction(s.driver, contributions.values.sum(), when { rs.isEmpty() -> "No race data"; rs.size < 5 -> "Low · ${rs.size} starts"; else -> "Moderate · ${rs.size} starts" }, contributions)
        }.sortedWith(compareByDescending<Prediction> { it.score }.thenBy { it.driver.number }.thenBy { it.driver.id })
    }

    fun developmentStrength(c: Championship, teamId: Int): Double = DevelopmentArea.entries.map { area ->
        val level = c.upgrades.filter { it.teamId == teamId && it.area == area }.maxOfOrNull { it.level } ?: 0
        sqrt(level / 5.0)
    }.average()

    fun upgrade(c: Championship, teamId: Int, area: DevelopmentArea): Championship {
        require(c.developmentEnabled) { "Enable development first." }
        require(c.races.none { it.sprintCompleted && !it.completed }) { "Finish the active sprint weekend before upgrading." }
        val history = c.upgrades.filter { it.teamId == teamId }
        val level = (history.filter { it.area == area }.maxOfOrNull { it.level } ?: 0) + 1
        require(level <= 5) { "Maximum level reached." }
        require(history.sumOf { it.cost } + level * 3 <= 60) { "Not enough development credits." }
        return c.copy(upgrades = c.upgrades + Upgrade(teamId, area, level, level * 3, c.races.filter { it.completed }.maxOfOrNull { it.round } ?: 0)).also(Validation::check)
    }

    fun progression(c: Championship, id: Int, team: Boolean): List<ProgressPoint> {
        if (if (team) c.teams.none { it.id == id } else c.drivers.none { it.id == id }) return emptyList()
        var previous = 0
        return c.races.sortedBy { it.round }.filter { it.completed || it.sprintCompleted }.map { r ->
            val prefix = c.copy(races = c.races.filter { it.round <= r.round })
            val pairs = if (team) ChampionshipEngine.teamStandings(prefix).map { it.team.id to it.points } else ChampionshipEngine.driverStandings(prefix).map { it.driver.id to it.points }
            val total = pairs.first { it.first == id }.second
            ProgressPoint(r.round, r.name, total, total - previous, pairs.indexOfFirst { it.first == id } + 1).also { previous = total }
        }
    }

    fun streak(values: List<Boolean>): Pair<Int, Int> {
        var current = 0; var best = 0
        values.forEach { current = if (it) current + 1 else 0; best = maxOf(best, current) }
        return current to best
    }

    fun driverStats(c: Championship, id: Int): List<Pair<String, String>> {
        val s = ChampionshipEngine.driverStandings(c).firstOrNull { it.driver.id == id } ?: return listOf("Driver unavailable" to "Return and select another driver")
        val rs = s.raceResults.map { it.second }
        val gains = rs.filter { it.gridPosition != null && it.finishPosition != null }.map { it.gridPosition!! - it.finishPosition!! }
        val sprint = c.races.filter { it.sprintCompleted }.mapNotNull { r -> r.sprintResults.firstOrNull { it.driverId == id } }
        val pointsStreak = streak(rs.map { it.points > 0 }); val podiumStreak = streak(rs.map { it.finishPosition in 1..3 })
        val bestWeekend = c.races.filter { it.completed || it.sprintCompleted }.maxByOrNull { it.allResults.filter { r -> r.driverId == id }.sumOf { it.points } }
        return listOf(
            "Total points (race + sprint)" to "${s.points}",
            "Main-race wins / podiums" to "${s.wins} / ${s.podiums}",
            "Sprint wins / podiums" to "${sprint.count { it.finishPosition == 1 }} / ${sprint.count { it.finishPosition in 1..3 }}",
            "Main-race fastest laps" to "${s.fastestLaps}",
            "Grid P1 starts (not qualifying poles)" to "${rs.count { it.gridPosition == 1 && it.status != ResultStatus.DNS }}",
            "Best / worst classified finish" to "${s.bestFinish ?: "—"} / ${s.worstFinish ?: "—"}",
            "Average classified finish" to (s.averageFinish?.let { "%.2f".format(it) } ?: "—"),
            "DNF / starts" to "${s.dnfs} / ${s.raceStarts}",
            "DNF rate" to (if (s.raceStarts == 0) "—" else "%.1f%%".format(100.0 * s.dnfs / s.raceStarts)),
            "Main-race points / start" to (if (s.raceStarts == 0) "—" else "%.2f".format(rs.sumOf { it.points }.toDouble() / s.raceStarts)),
            "Points streak · current / longest" to "${pointsStreak.first} / ${pointsStreak.second}",
            "Podium streak · current / longest" to "${podiumStreak.first} / ${podiumStreak.second}",
            "Highest-scoring weekend" to (bestWeekend?.let { "${it.name}: ${it.allResults.filter { r -> r.driverId == id }.sumOf { it.points }} pts" } ?: "—"),
            "Best recovery · positions gained" to (gains.maxOrNull()?.coerceAtLeast(0)?.toString() ?: "No grid data"),
            "Most positions lost" to (gains.minOrNull()?.let { maxOf(0, -it) }?.toString() ?: "No grid data"),
            "Consistency (classified finishes)" to (consistency(rs)?.let { "%.0f / 100".format(it * 100) } ?: "Needs two finishes"),
            "Last five main races" to rs.takeLast(5).joinToString(" · ") { it.finishPosition?.let { p -> "P$p" } ?: it.status }
        )
    }

    fun teamStats(c: Championship, id: Int): List<Pair<String, String>> {
        val s = ChampionshipEngine.teamStandings(c).firstOrNull { it.team.id == id } ?: return listOf("Team unavailable" to "Return and select another team")
        val main = c.races.filter { it.completed }.map { r -> r.results.filter { (it.teamId ?: c.drivers.firstOrNull { d -> d.id == it.driverId }?.teamId) == id } }
        val started = main.flatten().filter { it.status != ResultStatus.DNS }
        val best = s.raceSummaries.maxByOrNull { it.points }
        return listOf("Total points" to "${s.points}", "Main-race wins / podiums" to "${s.wins} / ${s.podiums}",
            "One-two finishes" to "${main.count { rs -> rs.any { it.finishPosition == 1 } && rs.any { it.finishPosition == 2 } }}",
            "Average points / recorded weekend" to "%.2f".format(s.averagePointsPerRace),
            "Best weekend" to (best?.let { "${it.race.name}: ${it.points} pts" } ?: "—"),
            "Finish rate / main-race starts" to (if (started.isEmpty()) "—" else "%.1f%%".format(100.0 * started.count { it.status == ResultStatus.FINISHED } / started.size))
        ) + c.drivers.mapNotNull { d ->
            val results = s.raceSummaries.flatMap { it.results }.filter { it.driverId == d.id }
            if (results.isEmpty()) null else "${d.name} contribution" to "${results.sumOf { it.points }} pts"
        }
    }
}
