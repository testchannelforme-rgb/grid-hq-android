package com.monoposto.championship

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool
import android.os.Build
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.View
import java.lang.ref.WeakReference

enum class FeedbackKind { TAP, SELECTION, NAVIGATION, CONFIRM, SUCCESS, ERROR }

/** One short cue per deliberate action; scrolling/recomposition never produces feedback. */
internal object Feedback {
    private var view = WeakReference<View>(null)
    private var pool: SoundPool? = null
    private val sounds = mutableMapOf<FeedbackKind, Int>()
    private val ready = mutableSetOf<Int>()
    private var last = 0L
    fun attach(v: View) {
        release()
        view = WeakReference(v)
        pool = SoundPool.Builder().setMaxStreams(2).setAudioAttributes(AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).build().also { p ->
            p.setOnLoadCompleteListener { _, id, status -> if (status == 0) ready.add(id) }
            listOf(R.raw.tap, R.raw.selection, R.raw.navigation, R.raw.confirm, R.raw.success, R.raw.error)
                .forEachIndexed { i, resource -> sounds[FeedbackKind.entries[i]] = p.load(v.context, resource, 1) }
        }
    }
    fun release() { pool?.release(); pool = null; sounds.clear(); ready.clear(); view.clear() }
    fun emit(kind: FeedbackKind = FeedbackKind.TAP) {
        val v = view.get() ?: return
        if (!v.hasWindowFocus()) return
        val now = SystemClock.elapsedRealtime()
        if (now - last < 85) return
        last = now
        val prefs = v.context.getSharedPreferences("gridhq_experience", Context.MODE_PRIVATE)
        if (prefs.getBoolean("haptics", true)) {
            val effect = when (kind) {
                FeedbackKind.SELECTION -> HapticFeedbackConstants.CLOCK_TICK
                FeedbackKind.CONFIRM, FeedbackKind.SUCCESS -> if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.VIRTUAL_KEY
                FeedbackKind.ERROR -> if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.REJECT else HapticFeedbackConstants.LONG_PRESS
                else -> HapticFeedbackConstants.KEYBOARD_TAP
            }
            v.performHapticFeedback(effect)
        }
        val audio = v.context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (!prefs.getBoolean("sound", true) || audio.ringerMode != AudioManager.RINGER_MODE_NORMAL || audio.getStreamVolume(AudioManager.STREAM_MUSIC) == 0) return
        val id = sounds[kind] ?: return
        if (id in ready) pool?.play(id, .16f, .16f, 1, 0, 1f)
    }
}
