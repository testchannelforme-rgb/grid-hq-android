package com.monoposto.championship.domain

import com.monoposto.championship.data.*

object Validation {
    fun check(c: Championship) {
        require(c.name.isNotBlank() && c.season.isNotBlank()) { "Name and season are required." }
        require(c.teams.size == 12 && c.drivers.size == 24) { "Exactly 12 teams and 24 drivers are required." }
        val teams = c.teams.map { it.id }.toSet()
        val drivers = c.drivers.map { it.id }.toSet()
        require(teams.size == 12 && drivers.size == 24) { "Duplicate driver or team IDs." }
        require(c.drivers.map { it.number }.distinct().size == 24 && c.drivers.all { it.number in 0..999 }) { "Use unique driver numbers from 0 to 999." }
        require(c.teams.all { t -> t.name.isNotBlank() && t.abbreviation.isNotBlank() && c.drivers.count { it.teamId == t.id } == 2 }) { "Each team needs a name and two drivers." }
        require(c.drivers.all { it.teamId in teams && it.name.isNotBlank() && it.abbreviation.isNotBlank() }) { "Invalid driver details." }
        require(c.races.size in 1..100) { "Use 1 to 100 rounds." }
        require(c.races.map { it.id }.distinct().size == c.races.size && c.races.map { it.round }.sorted() == (1..c.races.size).toList()) { "Invalid or duplicate rounds." }
        listOf(c.scoring, c.sprintScoring).forEach { s ->
            require(s.positionPoints.size == 24 && s.positionPoints.all { it in 0..9999 } && s.fastestLapPoints in 0..9999 && s.fastestLapTop in 1..24) { "Invalid scoring rules." }
        }
        c.races.forEach { race ->
            require(race.name.isNotBlank() && race.notes.length <= 20000) { "Race name required; notes limited to 20,000 characters." }
            require(race.sprintEnabled || race.sprintResults.isEmpty()) { "Remove sprint results before disabling the sprint." }
            listOf(race.results, race.sprintResults).forEach { results ->
                if (results.isNotEmpty()) {
                    require(results.size == 24 && results.map { it.driverId }.toSet() == drivers) { "Each session must include every driver exactly once." }
                    require(results.count { it.fastestLap } <= 1) { "Select at most one fastest lap." }
                    val positions = results.mapNotNull { it.finishPosition }
                    require(positions.sorted() == (1..positions.size).toList()) { "Finishing positions must be unique and continuous from P1." }
                    val grids = results.mapNotNull { it.gridPosition }
                    require(grids.all { it in 1..24 } && grids.distinct().size == grids.size) { "Grid positions must be unique, from 1 to 24." }
                    results.forEach { r ->
                        require(r.status in setOf(ResultStatus.FINISHED, ResultStatus.DNF, ResultStatus.DNS, ResultStatus.DSQ)) { "Invalid session status." }
                        require((r.status == ResultStatus.FINISHED) == (r.finishPosition != null)) { "Only finished drivers have a finish position." }
                        require(r.teamId == null || r.teamId in teams) { "Unknown historical team." }
                        require(r.penalty in 0..9999) { "Penalty must be between 0 and 9999 points." }
                        require(!r.fastestLap || r.status !in setOf(ResultStatus.DNS, ResultStatus.DSQ)) { "DNS/DSQ drivers cannot hold fastest lap." }
                    }
                }
            }
        }
        c.teams.forEach { team ->
            val history = c.upgrades.filter { it.teamId == team.id }
            require(history.sumOf { it.cost } <= 60) { "Development budget exceeded." }
            DevelopmentArea.entries.forEach { area ->
                val entries = history.filter { it.area == area }
                require(entries.map { it.level } == (1..entries.size).toList() && entries.size <= 5) { "Invalid upgrade levels." }
                require(entries.all { it.cost == it.level * 3 && it.afterRound in 0..100 }) { "Invalid upgrade cost or round." }
            }
        }
        require(c.upgrades.all { it.teamId in teams }) { "Unknown development team." }
    }
}
