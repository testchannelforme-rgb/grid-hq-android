package com.monoposto.championship.data

object ChampionshipFactory {
    private val colors = listOf(
        0xFFEF3340.toInt(), 0xFF3B82F6.toInt(), 0xFF22C55E.toInt(), 0xFFF59E0B.toInt(),
        0xFFA855F7.toInt(), 0xFF06B6D4.toInt(), 0xFFF97316.toInt(), 0xFFE11D48.toInt(),
        0xFF14B8A6.toInt(), 0xFF8B5CF6.toInt(), 0xFFEAB308.toInt(), 0xFF64748B.toInt()
    )

    fun create(name: String, season: String, raceCount: Int): Championship {
        require(raceCount > 0) { "Race count must be at least 1." }
        val teams = (1..TEAM_COUNT).map { i ->
            Team(i, "Team %02d".format(i), "T%02d".format(i), colors[i - 1])
        }
        val drivers = (1..DRIVER_COUNT).map { i ->
            Driver(i, "Driver %02d".format(i), i, "D%02d".format(i), ((i - 1) / 2) + 1)
        }
        val races = (1..raceCount).map { i -> Race(i, i, "Race $i") }
        return Championship(java.util.UUID.randomUUID().mostSignificantBits.and(Long.MAX_VALUE), name, season, races, teams, drivers)
    }
}
