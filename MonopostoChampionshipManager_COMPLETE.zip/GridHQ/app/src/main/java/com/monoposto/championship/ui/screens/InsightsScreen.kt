package com.monoposto.championship

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.monoposto.championship.data.*
import com.monoposto.championship.domain.*

@Composable
internal fun InsightsScreen(c: Championship, onBack: () -> Unit, onSave: (Championship) -> Unit) {
    var page by rememberSaveable(c.id) { mutableStateOf("Overview") }
    val pages = listOf("Overview", "Predictions", "Trends", "Drivers", "Teams", "Development", "Rules")
    Column(Modifier.fillMaxSize()) {
        DetailTopBar("GridHQ · Insights", onBack)
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(pages) { p -> FilterChip(page == p, { page = p }, label = { Text(p) }) }
        }
        Box(Modifier.weight(1f)) {
            when (page) {
                "Overview" -> Overview(c)
                "Predictions" -> Predictions(c)
                "Trends" -> Trends(c)
                "Drivers" -> StatsBrowser(c, false)
                "Teams" -> StatsBrowser(c, true)
                "Development" -> Development(c, onSave)
                "Rules" -> SessionRules(c, onSave)
            }
        }
    }
}

@Composable
private fun Overview(c: Championship) {
    val ds = remember(c) { ChampionshipEngine.driverStandings(c) }
    val ts = remember(c) { ChampionshipEngine.teamStandings(c) }
    val recorded = c.races.filter { it.completed || it.sprintCompleted }
    val leaders = remember(c) { recorded.sortedBy { it.round }.mapNotNull { r -> ChampionshipEngine.driverStandings(c.copy(races = c.races.filter { it.round <= r.round })).firstOrNull()?.driver?.id } }
    val consistent = ds.mapNotNull { s -> Insights.consistency(s.raceResults.map { it.second })?.let { s.driver.name to it } }.maxByOrNull { it.second }
    val improved = ds.mapNotNull { s ->
        val r = s.raceResults.map { it.second }.filter { it.status != ResultStatus.DNS }
        if (r.size < 4) null else s.driver.name to (r.take(2).map { it.finishPosition ?: 24 }.average() - r.takeLast(2).map { it.finishPosition ?: 24 }.average())
    }.maxByOrNull { it.second }
    val close = c.races.filter { it.completed }.minByOrNull { r -> val ps = r.results.map { it.points }.sortedDescending(); ps[0] - ps[1] }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("${recorded.size} recorded weekends · ${c.races.count { it.completed }} main races", style = MaterialTheme.typography.titleLarge) }
        item { Metric("Driver leader", if (recorded.isEmpty()) "No results" else (ds.firstOrNull()?.driver?.name ?: "No drivers")) }
        item { Metric("Team leader", if (recorded.isEmpty()) "No results" else (ts.firstOrNull()?.team?.name ?: "No teams")) }
        item { Metric("Leader changes between recorded rounds", "${leaders.zipWithNext().count { it.first != it.second }}") }
        item { Metric("Most consistent classified finisher", consistent?.let { "${it.first} · %.0f/100".format(it.second * 100) } ?: "Needs two finishes") }
        item { Metric("Most improved · first two vs last two starts", improved?.takeIf { it.second > 0 }?.let { "${it.first} · %.1f positions".format(it.second) } ?: "No positive improvement / insufficient starts") }
        item { Metric("Smallest top-two points gap in a race", close?.name ?: "No results") }
        item { Text("Timing-based closest finishes and winning margins are unavailable: this app does not record race times. Points gaps are not timing gaps. DNF/DSQ count as P24 only for the improvement estimate.") }
        item { Text("Main-race countback decides equal championship points; sprint points contribute to totals, while sprint wins are tracked separately.", style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
private fun Predictions(c: Championship) {
    val predictions = remember(c) { Insights.predictions(c) }
    var expanded by rememberSaveable { mutableIntStateOf(-1) }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Next-race estimate", style = MaterialTheme.typography.headlineSmall) }
        item { Text("Offline weighted scores from your recorded results. These are not win probabilities or machine learning. With no history, tied drivers are ordered by number. Confidence describes data coverage, not guaranteed accuracy.") }
        items(predictions, key = { it.driver.id }) { p ->
            Card(Modifier.fillMaxWidth().clickable { Feedback.emit(FeedbackKind.NAVIGATION); expanded = if (expanded == p.driver.id) -1 else p.driver.id }) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${predictions.indexOf(p) + 1}. ${p.driver.name}", style = MaterialTheme.typography.titleMedium)
                    Text("%.1f / 100 · %s".format(p.score, p.confidence))
                    Text("Largest score contributions: " + p.factors.entries.sortedByDescending { it.value }.take(3).joinToString { it.key.lowercase() })
                    if (expanded == p.driver.id) p.factors.forEach { (name, score) -> Text("$name: %.1f / %.0f".format(score, Insights.weights.getValue(name))) }
                    else Text("Tap for all factors", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
private fun StatsBrowser(c: Championship, team: Boolean) {
    val options = if (team) c.teams.map { it.id to it.name } else c.drivers.map { it.id to it.name }
    var selected by rememberSaveable(c.id, team) { mutableIntStateOf(options.firstOrNull()?.first ?: -1) }
    val values = remember(c, selected, team) { if (team) Insights.teamStats(c, selected) else Insights.driverStats(c, selected) }
    Column {
        LazyRow(contentPadding = PaddingValues(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(options) { (id, name) -> FilterChip(selected == id, { selected = id }, label = { Text(name) }) }
        }
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(values) { (label, value) -> Metric(label, value) }
        }
    }
}

@Composable
internal fun Metric(label: String, value: String) {
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value.ifEmpty { "—" }, style = MaterialTheme.typography.titleMedium)
    } }
}

@Composable
private fun Trends(c: Championship) {
    var team by rememberSaveable(c.id) { mutableStateOf(false) }
    var metric by rememberSaveable(c.id) { mutableStateOf("Total points") }
    val options = if (team) c.teams.map { it.id to it.name } else c.drivers.map { it.id to it.name }
    var selection by rememberSaveable(c.id, team) { mutableStateOf(options.take(3).joinToString(",") { it.first.toString() }) }
    val selected = selection.split(',').mapNotNull { it.toIntOrNull() }.filter { id -> options.any { it.first == id } }.distinct().take(4)
    val data = remember(c, selected, team) { selected.associateWith { Insights.progression(c, it, team) } }
    val rounds = data.values.firstOrNull().orEmpty()
    var selectedRound by rememberSaveable(c.id, team) { mutableIntStateOf(-1) }
    val colors = listOf(Color(0xFF67E8F9), Color(0xFFFBBF24), Color(0xFFF0ABFC), Color(0xFF86EFAC))
    fun value(p: ProgressPoint): Int = when (metric) { "Round points" -> p.gained; "Position" -> p.position; else -> p.total }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(!team, { team = false }, label = { Text("Drivers") }); FilterChip(team, { team = true }, label = { Text("Teams") }) } }
        item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(listOf("Total points", "Round points", "Position")) { m -> FilterChip(metric == m, { metric = m }, label = { Text(m) }) } } }
        item { Text("Choose up to four. Select a round below for exact values. Upcoming rounds are omitted; sprint-only weekends are included.") }
        item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(options) { (id, name) -> FilterChip(id in selected, {
            val next = if (id in selected) selected - id else if (selected.size < 4) selected + id else selected
            selection = next.joinToString(",")
        }, label = { Text(name) }) } } }
        if (rounds.isEmpty()) item { Metric("No chart data", "Select a driver/team and record at least one session.") }
        else {
            val values = data.values.flatten().map(::value)
            val minimum = if (metric == "Position") 1 else minOf(0, values.minOrNull() ?: 0)
            val maximum = if (metric == "Position") (if (team) 12 else 24) else maxOf(minimum + 1, values.maxOrNull() ?: 1)
            item { Text("$metric · ${if (metric == "Position") "P1 at top" else "$minimum to $maximum points"} · rounds ${rounds.first().round}–${rounds.last().round}") }
            item { Canvas(Modifier.fillMaxWidth().height(240.dp)) {
                val pad = 12.dp.toPx(); val w = size.width - pad * 2; val h = size.height - pad * 2
                repeat(5) { i -> val y = pad + h * i / 4; drawLine(Color.Gray.copy(alpha = .25f), Offset(pad, y), Offset(pad + w, y)) }
                data.entries.forEachIndexed { series, entry ->
                    val points = entry.value.mapIndexed { i, point ->
                        val fraction = (value(point) - minimum).toFloat() / (maximum - minimum)
                        Offset(pad + w * i / (rounds.size - 1).coerceAtLeast(1), pad + h * if (metric == "Position") fraction else 1 - fraction)
                    }
                    points.zipWithNext().forEach { (a, b) -> drawLine(colors[series], a, b, 3.dp.toPx()) }
                    points.forEach { drawCircle(colors[series], 4.dp.toPx(), it) }
                }
            } }
            item { selected.forEachIndexed { i, id -> Text("${i + 1} · ${options.first { it.first == id }.second}", color = colors[i]) } }
            item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(rounds) { r -> FilterChip(selectedRound == r.round, { selectedRound = r.round }, label = { Text("R${r.round}") }) } } }
            items(rounds.filter { selectedRound == -1 || it.round == selectedRound }) { r ->
                Metric("R${r.round} · ${r.name}", selected.joinToString("\n") { id -> "${options.first { it.first == id }.second}: ${value(data.getValue(id).first { it.round == r.round })}" })
            }
        }
    }
}

@Composable
private fun Development(c: Championship, onSave: (Championship) -> Unit) {
    var team by rememberSaveable(c.id) { mutableIntStateOf(c.teams.firstOrNull()?.id ?: -1) }
    var reset by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val history = c.upgrades.filter { it.teamId == team }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Enable development"); Switch(c.developmentEnabled, { onSave(c.copy(developmentEnabled = it)) }) } }
        item { Text("Each team has 60 credits for the season. Levels cost 3, 6, 9, 12 and 15 credits. Gains diminish with each level. All six attributes contribute equally to the prediction’s development factor (maximum 4/100 points). Recorded results never change. Disable to ignore development without losing history.") }
        item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(c.teams) { t -> FilterChip(team == t.id, { team = t.id }, label = { Text(t.name) }) } } }
        item { Metric("Credits remaining", "${60 - history.sumOf { it.cost }} / 60") }
        item { error?.let { Text(it, color = MaterialTheme.colorScheme.error) } }
        items(DevelopmentArea.entries.toList()) { area ->
            val level = history.filter { it.area == area }.maxOfOrNull { it.level } ?: 0
            OutlinedButton({ Feedback.emit(); runCatching { Insights.upgrade(c, team, area) }.onSuccess(onSave).onFailure { error = it.message } }, Modifier.fillMaxWidth(), enabled = c.developmentEnabled && level < 5 && (level + 1) * 3 <= 60 - history.sumOf { it.cost }) {
                Text("${area.name.lowercase().replace('_', ' ')} · level $level → ${level + 1} · ${(level + 1) * 3} credits")
            }
        }
        item { TextButton({ Feedback.emit(); reset = true }, enabled = history.isNotEmpty()) { Text("Reset selected team development") } }
        item { Text("Upgrade history", style = MaterialTheme.typography.titleLarge) }
        items(history.reversed()) { u -> Metric("After round ${u.afterRound}", "${u.area.name.lowercase().replace('_', ' ')} · level ${u.level} · ${u.cost} credits") }
    }
    if (reset) ConfirmDialog("Reset development?", "Remove this team's upgrade history and restore its 60 credits. Results remain unchanged.", "Reset", { reset = false }) { onSave(c.copy(upgrades = c.upgrades.filterNot { it.teamId == team })); reset = false }
}

@Composable
private fun SessionRules(c: Championship, onSave: (Championship) -> Unit) {
    var sprint by rememberSaveable(c.id) { mutableStateOf(false) }
    var edit by rememberSaveable(c.id) { mutableStateOf(false) }
    val rules = if (sprint) c.sprintScoring else c.scoring
    fun save(r: ScoringRules) = onSave(if (sprint) c.copy(sprintScoring = r) else c.copy(scoring = r))
    if (edit) ScoringScreen(c.copy(scoring = rules), { edit = false }) { updated -> save(updated.scoring) }
    else LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(!sprint, { sprint = false }, label = { Text("Race") }); FilterChip(sprint, { sprint = true }, label = { Text("Sprint") }) } }
        item { Text("Changes recalculate all recorded sessions of the selected type. Export a backup first if you need to keep the old totals.") }
        item { Button({ Feedback.emit(); edit = true }, Modifier.fillMaxWidth()) { Text("Edit position points & fastest-lap bonus") } }
        item { Text("Fastest-lap eligibility: classified P1–P${rules.fastestLapTop}") }
        item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(listOf(1, 3, 5, 8, 10, 24)) { top -> FilterChip(rules.fastestLapTop == top, { save(rules.copy(fastestLapTop = top)) }, label = { Text("Top $top") }) } } }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Allow fastest-lap bonus for DNF"); Switch(rules.allowDnfFastestLap, { save(rules.copy(allowDnfFastestLap = it)) }) } }
        item { Text("DNS and DSQ are always ineligible. Fastest-lap selection is optional. A recorded fastest lap remains a statistic even when it earns no bonus.") }
    }
}
