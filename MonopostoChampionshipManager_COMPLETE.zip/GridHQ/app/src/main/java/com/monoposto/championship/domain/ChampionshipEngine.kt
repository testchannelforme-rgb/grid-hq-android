package com.monoposto.championship.domain

import com.monoposto.championship.data.*

object ChampionshipEngine {
    fun racePoints(position: Int?, status: String, scoring: ScoringRules, fastestLap: Boolean = false): Int {
        val base = if (status == ResultStatus.FINISHED && position != null && position in 1..DRIVER_COUNT) {
            scoring.positionPoints.getOrElse(position - 1) { 0 }
        } else 0
        val eligible = (status == ResultStatus.FINISHED && position != null && position <= scoring.fastestLapTop) || (status == ResultStatus.DNF && scoring.allowDnfFastestLap)
        return base + if (fastestLap && eligible) scoring.fastestLapPoints else 0
    }

    fun normalizeRaceResults(
        championship: Championship,
        orderedFinishedDriverIds: List<Int>,
        dnfDriverIds: Set<Int>,
        dnsDriverIds: Set<Int>,
        fastestLapDriverId: Int?
    ): List<DriverRaceResult> {
        val allIds = championship.drivers.map { it.id }.toSet()
        require(orderedFinishedDriverIds.distinct().size == orderedFinishedDriverIds.size) { "Duplicate drivers in finishing order." }
        require(orderedFinishedDriverIds.all { it in allIds }) { "Unknown driver in finishing order." }
        require(dnfDriverIds.all { it in allIds } && dnsDriverIds.all { it in allIds }) { "Unknown driver status." }
        require(orderedFinishedDriverIds.toSet().intersect(dnfDriverIds).isEmpty()) { "Driver cannot be both finished and DNF." }
        require(orderedFinishedDriverIds.toSet().intersect(dnsDriverIds).isEmpty()) { "Driver cannot be both finished and DNS." }
        require(dnfDriverIds.intersect(dnsDriverIds).isEmpty()) { "Driver cannot be both DNF and DNS." }
        require((orderedFinishedDriverIds.toSet() + dnfDriverIds + dnsDriverIds) == allIds) { "Every driver must have a race status." }
        require(fastestLapDriverId == null || fastestLapDriverId in allIds) { "Invalid fastest-lap driver." }

        val pos = orderedFinishedDriverIds.withIndex().associate { (i, id) -> id to i + 1 }
        return championship.drivers.map { driver ->
            val status = when (driver.id) {
                in pos -> ResultStatus.FINISHED
                in dnfDriverIds -> ResultStatus.DNF
                else -> ResultStatus.DNS
            }
            val finish = pos[driver.id]
            val fastest = fastestLapDriverId == driver.id
            DriverRaceResult(
                driverId = driver.id,
                finishPosition = finish,
                status = status,
                points = racePoints(finish, status, championship.scoring, fastest),
                fastestLap = fastest && status != ResultStatus.DNS,
                teamId = driver.teamId
            )
        }
    }

    fun recalculateRace(race: Race, scoring: ScoringRules): Race = race.copy(
        results = race.results.map { r ->
            r.copy(points = racePoints(r.finishPosition, r.status, scoring, r.fastestLap) - r.penalty)
        }
    )

    fun recalculateAll(championship: Championship): Championship = championship.copy(
        races = championship.races.map { race -> recalculateRace(race, championship.scoring).copy(
            sprintResults = race.sprintResults.map { r -> r.copy(points = racePoints(r.finishPosition, r.status, championship.sprintScoring, r.fastestLap) - r.penalty) }
        ) }
    )

    fun driverStandings(championship: Championship): List<DriverStanding> {
        val teamMap = championship.teams.associateBy { it.id }
        val completedRaces = championship.races.filter { it.completed }.sortedBy { it.round }
        val standings = championship.drivers.map { driver ->
            val raceResults = completedRaces.mapNotNull { race ->
                race.results.firstOrNull { it.driverId == driver.id }?.let { race to it }
            }
            val finishedPositions = raceResults.mapNotNull { (_, r) ->
                r.finishPosition.takeIf { r.status == ResultStatus.FINISHED }
            }
            val positionCounts = (1..DRIVER_COUNT).map { p -> finishedPositions.count { it == p } }
            val points = raceResults.sumOf { it.second.points } + championship.races.filter { it.sprintCompleted }.sumOf { race -> (race.sprintResults.firstOrNull { it.driverId == driver.id }?.points ?: 0) }
            val starts = raceResults.count { it.second.status != ResultStatus.DNS }
            DriverStanding(
                driver = driver,
                team = championship.teamOrPlaceholder(driver.teamId),
                points = points,
                wins = positionCounts[0],
                podiums = positionCounts.take(3).sum(),
                top5 = positionCounts.take(5).sum(),
                top10 = positionCounts.take(10).sum(),
                fastestLaps = raceResults.count { it.second.fastestLap },
                dnfs = raceResults.count { it.second.status == ResultStatus.DNF },
                dns = raceResults.count { it.second.status == ResultStatus.DNS },
                bestFinish = finishedPositions.minOrNull(),
                worstFinish = finishedPositions.maxOrNull(),
                averageFinish = finishedPositions.takeIf { it.isNotEmpty() }?.average(),
                averagePointsPerRace = if (raceResults.isEmpty()) 0.0 else raceResults.sumOf { it.second.points }.toDouble() / raceResults.size,
                raceStarts = starts,
                completedRaces = raceResults.count { it.second.status == ResultStatus.FINISHED },
                positionCounts = positionCounts,
                raceResults = raceResults
            )
        }
        return standings.sortedWith(driverComparator())
    }

    fun teamStandings(championship: Championship): List<TeamStanding> {
        val driverStandings = driverStandings(championship)
        val completedRaces = championship.races.filter { it.completed || it.sprintCompleted }.sortedBy { it.round }
        val standings = championship.teams.map { team ->
            val driverStats = driverStandings.filter { it.driver.teamId == team.id }
            val raceSummaries = completedRaces.map { race ->
                val results = race.allResults.filter { (it.teamId ?: championship.drivers.firstOrNull { d -> d.id == it.driverId }?.teamId) == team.id }
                TeamRaceSummary(
                    race = race,
                    points = results.sumOf { it.points },
                    bestFinish = results.mapNotNull { result -> result.finishPosition.takeIf { result.status == ResultStatus.FINISHED } }.minOrNull(),
                    results = results
                )
            }
            val allFinished = completedRaces.flatMap { race -> race.results.filter { (it.teamId ?: championship.drivers.firstOrNull { d -> d.id == it.driverId }?.teamId) == team.id } }.mapNotNull { r ->
                r.finishPosition.takeIf { r.status == ResultStatus.FINISHED }
            }
            val positionCounts = (1..DRIVER_COUNT).map { p -> allFinished.count { it == p } }
            val points = raceSummaries.sumOf { it.points }
            TeamStanding(
                team = team,
                points = points,
                wins = positionCounts[0],
                podiums = positionCounts.take(3).sum(),
                bestFinish = allFinished.minOrNull(),
                averagePointsPerRace = if (raceSummaries.isEmpty()) 0.0 else points.toDouble() / raceSummaries.size,
                driverStandings = driverStats,
                positionCounts = positionCounts,
                raceSummaries = raceSummaries
            )
        }
        return standings.sortedWith(teamComparator())
    }

    fun seasonStatistics(championship: Championship): SeasonStatistics {
        val ds = driverStandings(championship)
        val ts = teamStandings(championship)
        val completed = championship.races.filter { it.completed }
        if (completed.isEmpty()) return SeasonStatistics(null, null, null, null, null, null, null, 0, null, null)
        val bestAvgCandidates = ds.filter { it.averageFinish != null && it.raceStarts > 0 }
        val oneRace = completed.flatMap { race ->
            race.results.mapNotNull { result -> championship.drivers.firstOrNull { it.id == result.driverId }?.let { it to result.points } }
        }.maxByOrNull { it.second }
        return SeasonStatistics(
            championshipLeader = ds.firstOrNull(),
            mostWins = ds.maxWithOrNull(compareBy<DriverStanding> { it.wins }.thenBy { it.points }),
            mostPodiums = ds.maxWithOrNull(compareBy<DriverStanding> { it.podiums }.thenBy { it.points }),
            mostFastestLaps = ds.maxWithOrNull(compareBy<DriverStanding> { it.fastestLaps }.thenBy { it.points }),
            mostDnfs = ds.maxWithOrNull(compareBy<DriverStanding> { it.dnfs }.thenBy { it.points }),
            bestAverageFinish = bestAvgCandidates.minByOrNull { it.averageFinish!! },
            mostPointsInOneRaceDriver = oneRace?.first,
            mostPointsInOneRace = oneRace?.second ?: 0,
            highestScoringTeam = ts.firstOrNull(),
            lowestScoringTeam = ts.lastOrNull()
        )
    }

    fun driverComparator(): Comparator<DriverStanding> = Comparator { a, b ->
        compareByTiebreak(
            a.points,
            b.points,
            a.positionCounts,
            b.positionCounts,
            a.driver.number,
            b.driver.number,
            a.driver.id,
            b.driver.id
        )
    }

    fun teamComparator(): Comparator<TeamStanding> = Comparator { a, b ->
        compareByTiebreak(
            a.points,
            b.points,
            a.positionCounts,
            b.positionCounts,
            a.team.id,
            b.team.id,
            a.team.id,
            b.team.id
        )
    }

    private fun compareByTiebreak(
        pointsA: Int,
        pointsB: Int,
        countsA: List<Int>,
        countsB: List<Int>,
        stableA: Int,
        stableB: Int,
        idA: Int,
        idB: Int
    ): Int {
        if (pointsA != pointsB) return pointsB.compareTo(pointsA)
        for (i in 0 until DRIVER_COUNT) {
            val a = countsA.getOrElse(i) { 0 }
            val b = countsB.getOrElse(i) { 0 }
            if (a != b) return b.compareTo(a)
        }
        if (stableA != stableB) return stableA.compareTo(stableB)
        return idA.compareTo(idB)
    }
}
