@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.monoposto.championship

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.monoposto.championship.data.*
import com.monoposto.championship.domain.ChampionshipEngine
import com.monoposto.championship.ui.*
import java.util.Locale

@Composable
internal fun NewChampionshipDialog(onDismiss: () -> Unit, onCreate: (String, String, Int) -> Unit) {
    var name by remember { mutableStateOf("My Championship") }
    var season by remember { mutableStateOf("2026 Season") }
    var count by remember { mutableStateOf("20") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create championship") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("12 teams and 24 drivers will be created automatically.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedTextField(name, { name = it }, label = { Text("Championship name") }, singleLine = true)
            OutlinedTextField(season, { season = it }, label = { Text("Season / year") }, singleLine = true)
            OutlinedTextField(count, { if (it.all(Char::isDigit) && it.length <= 3) count = it }, label = { Text("Number of races") }, singleLine = true)
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
        } },
        confirmButton = { Button(onClick = { Feedback.emit(); val n = count.toIntOrNull(); if (n == null || n !in 1..100) error = "Race count must be between 1 and 100." else onCreate(name, season, n) }) { Text("Create") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
internal fun ChampionshipPickerDialog(championships: List<Championship>, selectedId: Long, onDismiss: () -> Unit, onSelect: (Long) -> Unit, onNew: () -> Unit, onDuplicate: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Championships") },
        text = { Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
            championships.forEach { c ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { Feedback.emit(FeedbackKind.NAVIGATION); onSelect(c.id) }.background(if (c.id == selectedId) MaterialTheme.colorScheme.primary.copy(alpha = .12f) else Color.Transparent).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (c.id == selectedId) Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked, null, tint = if (c.id == selectedId) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(10.dp)); Column { Text(c.name, fontWeight = FontWeight.Bold); Text(c.season, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }
        } },
        confirmButton = { TextButton(onClick = onNew) { Icon(Icons.Default.Add, null); Text("New") } },
        dismissButton = { Row { TextButton(onClick = onDuplicate) { Text("Duplicate current") }; TextButton(onClick = onDismiss) { Text("Close") } } }
    )
}

@Composable
internal fun RaceNameDialog(title: String, initial: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var value by remember { mutableStateOf(initial) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = { OutlinedTextField(value, { value = it }, label = { Text("Race name") }, singleLine = true) }, confirmButton = { Button(onClick = { Feedback.emit(); if (value.isNotBlank()) onSave(value.trim()) }, enabled = value.isNotBlank()) { Text("Save") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
internal fun ChampionshipInfoDialog(c: Championship, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var name by remember { mutableStateOf(c.name) }
    var season by remember { mutableStateOf(c.season) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Championship settings") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true); OutlinedTextField(season, { season = it }, label = { Text("Season") }, singleLine = true) } }, confirmButton = { Button(onClick = { Feedback.emit(); if (name.isNotBlank() && season.isNotBlank()) onSave(name.trim(), season.trim()) }) { Text("Save") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
internal fun TeamEditDialog(team: Team, onDismiss: () -> Unit, onSave: (Team) -> Unit) {
    var name by remember { mutableStateOf(team.name) }
    var abbr by remember { mutableStateOf(team.abbreviation) }
    var color by remember { mutableIntStateOf(team.colorArgb) }
    val palette = listOf(0xFFEF3340,0xFF3B82F6,0xFF22C55E,0xFFF59E0B,0xFFA855F7,0xFF06B6D4,0xFFF97316,0xFFE11D48,0xFF14B8A6,0xFF8B5CF6,0xFFEAB308,0xFF64748B).map { it.toInt() }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Edit team") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(name, { name = it }, label = { Text("Team name") }, singleLine = true)
        OutlinedTextField(abbr, { if (it.length <= 5) abbr = it.uppercase(Locale.ROOT) }, label = { Text("Abbreviation") }, singleLine = true)
        Text("Team color", fontWeight = FontWeight.Bold)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) { items(palette) { p -> Box(Modifier.size(32.dp).clip(RoundedCornerShape(10.dp)).background(Color(p)).clickable { Feedback.emit(FeedbackKind.NAVIGATION); color = p }.then(if (color == p) Modifier.padding(3.dp) else Modifier)) } }
    } }, confirmButton = { Button(onClick = { Feedback.emit(); if (name.isNotBlank() && abbr.isNotBlank()) onSave(team.copy(name = name.trim(), abbreviation = abbr.trim(), colorArgb = color)) }) { Text("Save") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
internal fun DriverEditDialog(c: Championship, driver: Driver, onDismiss: () -> Unit, onSave: (Driver, Driver?) -> Unit) {
    var name by remember { mutableStateOf(driver.name) }
    var number by remember { mutableStateOf(driver.number.toString()) }
    var abbr by remember { mutableStateOf(driver.abbreviation) }
    var swapWith by remember { mutableStateOf<Driver?>(null) }
    var showSwap by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val candidates = c.drivers.filter { it.id != driver.id && it.teamId != driver.teamId }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Edit driver") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(name, { name = it }, label = { Text("Driver name") }, singleLine = true)
        OutlinedTextField(number, { if (it.all(Char::isDigit) && it.length <= 3) number = it }, label = { Text("Number") }, singleLine = true)
        OutlinedTextField(abbr, { if (it.length <= 5) abbr = it.uppercase(Locale.ROOT) }, label = { Text("Abbreviation") }, singleLine = true)
        Text("Current team: ${c.teamOrPlaceholder(driver.teamId).name}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Box {
            OutlinedButton(onClick = { Feedback.emit(); showSwap = true }, modifier = Modifier.fillMaxWidth()) { Text(swapWith?.let { "Swap team with ${it.name}" } ?: "Change team by swapping driver") }
            DropdownMenu(expanded = showSwap, onDismissRequest = { showSwap = false }) { candidates.forEach { d -> DropdownMenuItem(text = { Text("${d.name} · ${c.teamOrPlaceholder(d.teamId).name}") }, onClick = { Feedback.emit(); swapWith = d; showSwap = false }) } }
        }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
    } }, confirmButton = { Button(onClick = { Feedback.emit();
        val n = number.toIntOrNull()
        when {
            name.isBlank() || abbr.isBlank() -> error = "Name and abbreviation are required."
            n == null || n !in 0..999 -> error = "Driver number must be between 0 and 999."
            c.drivers.any { it.id != driver.id && it.number == n } -> error = "Driver number $n is already in use."
            else -> onSave(driver.copy(name = name.trim(), number = n, abbreviation = abbr.trim()), swapWith)
        }
    }) { Text("Save") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
internal fun ConfirmDialog(title: String, message: String, confirm: String, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = { Text(message) }, confirmButton = { Button(onClick = onConfirm, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text(confirm) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}
