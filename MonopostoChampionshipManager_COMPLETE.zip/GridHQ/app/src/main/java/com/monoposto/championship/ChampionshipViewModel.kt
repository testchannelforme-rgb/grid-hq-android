package com.monoposto.championship

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.monoposto.championship.data.*
import com.monoposto.championship.domain.ChampionshipEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import android.net.Uri

data class AppState(
    val championships: List<Championship> = emptyList(),
    val selectedId: Long? = null,
    val loading: Boolean = true,
    val error: String? = null,
    val success: String? = null
) {
    val selected: Championship? get() = championships.firstOrNull { it.id == selectedId }
}

class ChampionshipViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = ChampionshipRepository(ChampionshipDatabase.get(application))
    private val writes = Mutex()
    private val preferences = application.getSharedPreferences("gridhq", 0)
    private val _state = MutableStateFlow(AppState())
    val state: StateFlow<AppState> = _state.asStateFlow()

    init { refresh() }

    fun refresh(preferredId: Long? = _state.value.selectedId ?: preferences.getLong("selected", -1).takeIf { it != -1L }) {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true)
            runCatching { withContext(Dispatchers.IO) { repository.loadAll() } }
                .onSuccess { all ->
                    val selected = preferredId?.takeIf { id -> all.any { it.id == id } } ?: all.firstOrNull()?.id
                    _state.value = AppState(all, selected, loading = false)
                }
                .onFailure { _state.value = _state.value.copy(loading = false, error = it.message ?: "Unable to load championships.") }
        }
    }

    fun select(id: Long) { preferences.edit().putLong("selected", id).apply(); _state.value = _state.value.copy(selectedId = id) }

    fun create(name: String, season: String, raceCount: Int) {
        val c = ChampionshipFactory.create(name.trim().ifBlank { "My Championship" }, season.trim().ifBlank { "Season" }, raceCount)
        save(c, selectAfter = true)
    }

    fun save(championship: Championship, selectAfter: Boolean = true) {
        viewModelScope.launch {
            runCatching { writes.withLock { withContext(Dispatchers.IO) { repository.save(championship); repository.loadAll() } } }
                .onSuccess { all ->
                    _state.value = _state.value.copy(championships = all, loading = false, success = "Changes saved", error = null)
                    if (selectAfter) select(championship.id)
                }
                .onFailure { _state.value = _state.value.copy(error = it.message ?: "Could not save changes.") }
        }
    }

    fun duplicate(championship: Championship) {
        val copy = championship.copy(id = java.util.UUID.randomUUID().mostSignificantBits.and(Long.MAX_VALUE), name = "${championship.name} Copy", revision = 0)
        save(copy, true)
    }

    fun delete(championship: Championship) {
        viewModelScope.launch {
            runCatching { withContext(Dispatchers.IO) { repository.delete(championship.id) } }
                .onSuccess { refresh(null) }
                .onFailure { _state.value = _state.value.copy(error = it.message ?: "Could not delete championship.") }
        }
    }

    fun importJson(json: String) {
        viewModelScope.launch {
            runCatching { withContext(Dispatchers.Default) { ChampionshipEngine.recalculateAll(BackupCodec.import(json, forceNewId = true)) } }
                .onSuccess { imported ->
                    runCatching { withContext(Dispatchers.IO) { repository.save(imported) } }
                        .onSuccess { refresh(imported.id) }
                        .onFailure { _state.value = _state.value.copy(error = it.message ?: "Import could not be saved.") }
                }
                .onFailure { _state.value = _state.value.copy(error = it.message ?: "Invalid backup file.") }
        }
    }

    fun exportJson(championship: Championship): String = BackupCodec.export(championship)

    fun clearSuccess() { _state.value = _state.value.copy(success = null) }

    fun clearError() { _state.value = _state.value.copy(error = null) }

    fun reportError(message: String) { _state.value = _state.value.copy(error = message) }

    fun exportTo(uri: Uri, c: Championship) {
        viewModelScope.launch {
            runCatching { withContext(Dispatchers.IO) {
                val stream = getApplication<Application>().contentResolver.openOutputStream(uri) ?: error("Cannot open destination.")
                stream.bufferedWriter().use { it.write(BackupCodec.export(c)) }
            } }.onSuccess { _state.value = _state.value.copy(success = "Backup exported successfully.") }.onFailure { reportError(it.message ?: "Export failed.") }
        }
    }

    fun importFrom(uri: Uri) {
        viewModelScope.launch {
            runCatching { withContext(Dispatchers.IO) {
                val stream = getApplication<Application>().contentResolver.openInputStream(uri) ?: error("Cannot open backup.")
                stream.bufferedReader().use { reader ->
                    val text = StringBuilder(); val buf = CharArray(8192)
                    while (true) { val n = reader.read(buf); if (n < 0) break; text.append(buf, 0, n); require(text.length <= 10_000_000) { "Backup exceeds 10 MB text limit." } }
                    text.toString()
                }
            } }.onSuccess { importJson(it) }.onFailure { reportError(it.message ?: "Import failed.") }
        }
    }
}
