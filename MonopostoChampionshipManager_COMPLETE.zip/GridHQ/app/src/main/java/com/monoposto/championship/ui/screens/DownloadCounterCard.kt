package com.monoposto.championship

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.monoposto.championship.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

@Composable
internal fun DownloadCounterCard() {
    val context = LocalContext.current
    val counter = remember { DownloadCounter(context.applicationContext) }
    var count by remember { mutableStateOf(counter.cached()) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("APK downloads", style = MaterialTheme.typography.titleMedium)
            if (ReleaseConfiguration.PUBLIC_RELEASE_REPOSITORY.isBlank()) Text("Download statistics are not available for this build.")
            else {
                Text(count?.count?.toString() ?: "Not fetched yet", style = MaterialTheme.typography.headlineSmall)
                Text("Release APK downloads, not unique users. Excludes GitHub Actions artifacts.")
                count?.let { Text("Last updated: ${DateFormat.getDateTimeInstance().format(Date(it.timestamp))}") }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                OutlinedButton({ Feedback.emit(); scope.launch {
                    busy = true; error = null
                    runCatching { withContext(Dispatchers.IO) { counter.refresh() } }.onSuccess { count = it }.onFailure { error = it.message }
                    busy = false
                } }, enabled = !busy) { Text(if (busy) "Refreshing…" else "Refresh (15-minute cache)") }
            }
        }
    }
}
