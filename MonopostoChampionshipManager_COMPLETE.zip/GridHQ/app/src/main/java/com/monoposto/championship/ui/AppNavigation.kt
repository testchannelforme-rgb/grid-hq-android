package com.monoposto.championship.ui

enum class TopTab(val label: String) {
    HOME("Home"),
    STANDINGS("Standings"),
    RACES("Races"),
    STATS("Stats"),
    SETTINGS("Settings")
}

sealed interface DetailRoute {
    data class Driver(val id: Int) : DetailRoute
    data class Team(val id: Int) : DetailRoute
    data class Race(val id: Int) : DetailRoute
    data object People : DetailRoute
    data object Scoring : DetailRoute
    data object Insights : DetailRoute
}
