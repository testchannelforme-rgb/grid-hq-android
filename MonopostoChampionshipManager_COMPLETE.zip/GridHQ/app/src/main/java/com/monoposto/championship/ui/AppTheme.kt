package com.monoposto.championship.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val McmRed = Color(0xFF48E5C2)
val McmBackground = Color(0xFF090B0F)
val McmSurface = Color(0xFF11151C)
val McmSurface2 = Color(0xFF181D26)
val McmText = Color(0xFFF4F7FB)
val McmMuted = Color(0xFF9DA7B5)
val McmGold = Color(0xFFFFC857)

private val DarkColors = darkColorScheme(
    primary = McmRed,
    onPrimary = Color(0xFF071A18),
    secondary = Color(0xFFB9C1CC),
    background = McmBackground,
    onBackground = McmText,
    surface = McmSurface,
    onSurface = McmText,
    surfaceVariant = McmSurface2,
    onSurfaceVariant = McmMuted,
    outline = Color(0xFF343A46),
    error = Color(0xFFFF6B6B)
)

private val AppTypography = Typography(
    headlineLarge = Typography().headlineLarge.copy(fontWeight = FontWeight.Black, letterSpacing = (-0.7).sp),
    headlineMedium = Typography().headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
    titleLarge = Typography().titleLarge.copy(fontWeight = FontWeight.Bold),
    titleMedium = Typography().titleMedium.copy(fontWeight = FontWeight.Bold),
    labelLarge = Typography().labelLarge.copy(fontWeight = FontWeight.Bold),
    bodyLarge = Typography().bodyLarge.copy(fontFamily = FontFamily.SansSerif)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, typography = AppTypography, content = content)
}
