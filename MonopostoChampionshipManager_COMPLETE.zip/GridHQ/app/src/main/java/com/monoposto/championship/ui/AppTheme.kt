package com.monoposto.championship.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp

val McmRed = Color(0xFFF32E43)
val McmBackground = Color(0xFF080C0F)
val McmSurface = Color(0xFF11161C)
val McmSurface2 = Color(0xFF191D26)
val McmText = Color(0xFFF4F7FB)
val McmMuted = Color(0xFFADB1BD)
val McmGold = Color(0xFFFFC857)

private val DarkColors = darkColorScheme(
    primary = McmRed,
    onPrimary = Color.White,
    secondary = McmRed,
    secondaryContainer = Color(0xFF351C25),
    onSecondaryContainer = McmText,
    primaryContainer = Color(0xFF351C25),
    onPrimaryContainer = McmText,
    surfaceContainer = McmSurface,
    surfaceContainerHigh = McmSurface2,
    surfaceContainerHighest = McmSurface2,
    background = McmBackground,
    onBackground = McmText,
    surface = McmSurface,
    onSurface = McmText,
    surfaceVariant = McmSurface2,
    onSurfaceVariant = McmMuted,
    outline = Color(0xFF343A46),
    error = Color(0xFFFF6B6B)
)

private val AppTypography = Typography(
    headlineLarge = Typography().headlineLarge.copy(fontWeight = FontWeight.Black, letterSpacing = (-0.7).sp),
    headlineMedium = Typography().headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
    titleLarge = Typography().titleLarge.copy(fontWeight = FontWeight.Bold),
    titleMedium = Typography().titleMedium.copy(fontWeight = FontWeight.Bold),
    labelLarge = Typography().labelLarge.copy(fontWeight = FontWeight.Bold),
    bodyLarge = Typography().bodyLarge.copy(fontFamily = FontFamily.SansSerif)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, typography = AppTypography, shapes = Shapes(medium = androidx.compose.foundation.shape.RoundedCornerShape(12.dp), large = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)), content = content)
}
