@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.monoposto.championship

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.monoposto.championship.data.*
import com.monoposto.championship.domain.ChampionshipEngine
import com.monoposto.championship.ui.*
import java.util.Locale

@Composable
internal fun ScoringScreen(c: Championship, onBack: () -> Unit, onSave: (Championship) -> Unit) {
    var fields by remember(c.id, c.scoring) { mutableStateOf(c.scoring.positionPoints.map { it.toString() }) }
    var fl by remember(c.id, c.scoring) { mutableStateOf(c.scoring.fastestLapPoints.toString()) }
    var error by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize()) {
        DetailTopBar("Scoring system", onBack)
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            item {
                Text("Set points for every finishing position. All completed races will be recalculated when you save.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(bottom = 8.dp)) }
            }
            itemsIndexed(fields) { index, value ->
                OutlinedTextField(
                    value = value,
                    onValueChange = { v -> if (v.all(Char::isDigit) && v.length <= 4) fields = fields.toMutableList().also { it[index] = v } },
                    label = { Text("P${index + 1} points") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                OutlinedTextField(fl, { v -> if (v.all(Char::isDigit) && v.length <= 4) fl = v }, label = { Text("Fastest lap points") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        }
        Surface(color = MaterialTheme.colorScheme.surface) {
            Button(onClick = { Feedback.emit();
                val pts = fields.map { it.toIntOrNull() }
                val fast = fl.toIntOrNull()
                if (pts.any { it == null } || fast == null) error = "Enter a valid non-negative points value for every field."
                else {
                    val newScoring = c.scoring.copy(positionPoints = pts.map { it!! }, fastestLapPoints = fast)
                    val recalculated = ChampionshipEngine.recalculateAll(c.copy(scoring = newScoring))
                    onSave(recalculated); onBack()
                }
            }, modifier = Modifier.fillMaxWidth().padding(12.dp)) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(7.dp)); Text("Save scoring & recalculate") }
        }
    }
}

@Composable
internal fun SettingsScreen(c: Championship, vm: ChampionshipViewModel, onPeople: () -> Unit, onScoring: () -> Unit, onRaces: () -> Unit, onDeleted: () -> Unit) {
    val context = LocalContext.current
    var editInfo by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var pendingExportId by rememberSaveable { mutableStateOf<Long?>(null) }
    val createDocument = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            val selected = vm.state.value.championships.firstOrNull { it.id == pendingExportId }
            if (selected == null) vm.reportError("Championship unavailable. Try exporting again.") else vm.exportTo(uri, selected)
        }
        pendingExportId = null
    }
    val openDocument = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importFrom(uri)
    }
    LazyColumn(contentPadding = PaddingValues(bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { SectionHeader("Settings", "Grid HQ 2.1.0 · Championship and local data") }
        item { ExperienceSettings()
                NotificationSettings() }
        item { DownloadCounterCard() }
        item { SettingsGroup("Championship") {
            SettingsRow(Icons.Default.Tune, "Championship settings", "Rename or change season") { editInfo = true }
            SettingsRow(Icons.Default.Calculate, "Scoring system", "Positions 1–24 + fastest lap") { onScoring() }
            SettingsRow(Icons.Default.Groups, "Drivers & teams", "Edit all 24 drivers and 12 teams") { onPeople() }
            SettingsRow(Icons.Default.CalendarMonth, "Race management", "Add, rename, delete and reorder races") { onRaces() }
        } }
        item { SettingsGroup("Backup") {
            SettingsRow(Icons.Default.FileUpload, "Export championship", "Complete JSON backup") {
                pendingExportId = c.id; createDocument.launch("${c.name.replace(Regex("[^A-Za-z0-9_-]"), "_")}.json")
            }
            SettingsRow(Icons.Default.FileDownload, "Import championship", "Restore a backup as a separate championship") { openDocument.launch(arrayOf("application/json", "text/plain")) }
        } }
        item { SettingsGroup("Season actions") {
            SettingsRow(Icons.Default.ContentCopy, "Duplicate championship", "Create an independent copy") { vm.duplicate(c) }
            SettingsRow(Icons.Default.DeleteForever, "Delete championship", "Permanently remove this season", destructive = true) { confirmDelete = true }
        } }
        item { Text("Championship data stays on this device. All management features work offline. The optional download counter contacts GitHub only when you refresh it.", Modifier.padding(18.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp) }
    }
    if (editInfo) ChampionshipInfoDialog(c, onDismiss = { editInfo = false }) { name, season -> vm.save(c.copy(name = name, season = season)); editInfo = false }
    if (confirmDelete) ConfirmDialog("Delete championship?", "${c.name} and all of its races, results, teams, drivers and scoring rules will be permanently deleted from this device.", "Delete", onDismiss = { confirmDelete = false }) {
        vm.delete(c); confirmDelete = false; onDeleted()
    }
}

@Composable
internal fun SettingsGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
            Text(title.uppercase(Locale.ROOT), Modifier.padding(16.dp, 8.dp, 16.dp, 6.dp), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Black, fontSize = 10.sp, letterSpacing = 1.2.sp)
            content()
        }
    }
}

@Composable
internal fun SettingsRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, destructive: Boolean = false, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = { Feedback.emit(); onClick() }).padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold, color = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface); Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
