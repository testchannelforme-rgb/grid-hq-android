# Verification status

The requested command `sh gradlew --no-daemon testDebugUnitTest lintDebug assembleDebug` was attempted against the updated project. It stopped at Gradle download with `java.net.UnknownHostException: services.gradle.org`. No Android SDK, local Gradle distribution or Kotlin compiler was found.

Therefore no Kotlin compilation, JUnit execution, Android lint, instrumented tests, APK generation or emulator/device UI verification is claimed locally. There is no APK in this delivery.

Local checks did pass for workflow YAML parsing, manifest/resource XML parsing, package/version invariants, duplicate shared-composable declarations, and executing the exact migration SQL against a SQLite v1 fixture with 12 teams, 24 drivers and 24 result rows. Those rows remained unchanged and foreign-key checks were clean. This is SQLite-level verification only, not Room/Android runtime verification. There are 30 JVM @Test methods plus one instrumented migration test in the source.

Source review and packaging checks are not substitutes for compilation. See the GitHub Actions reports after running the included workflow. Build/test failures must be fixed before distributing this as stable.

The source contains the original domain/backup tests, new GridHQ regression tests, and an instrumented v1 → v2 migration test that opens the actual migrated schema with Room, checks original records, performs a v2 save and rejects a stale save. The workflow runs these before publishing the APK artifact.

Device acceptance before public release:

1. Export v1 data. If the original signing key exists, install v2 over v1 and verify every season, scoring table, result and name.
2. Import a v1 backup as a separate championship and compare totals. Existing invalid fastest-lap/DNS combinations require correction before saving, since v2 rejects them.
3. Enter/edit/delete sprint and main-race results separately; check driver/team totals, countback and charts.
4. Enter grid positions and penalties, rotate while editing, test duplicate/invalid inputs, and verify notes survive back/cancel/rotation/restart.
5. Swap drivers after recording results and check historical constructor totals and contribution cards.
6. Test predictions with no results, one race, five races, all-DNF races and development toggles.
7. Export/import v2 data including notes, development and sprint rules. Check imported championships are independent.
8. Test airplane mode. For a configured public release repo, test API success, offline refresh and cached timestamp.
9. Check portrait/landscape on a small phone and tablet, long names, large text, back navigation and colour contrast.

The legacy project included a custom wrapper binary. CI replaces it with the official Gradle-generated wrapper before building. The original wrapper is retained only as inherited source content pending that regeneration.
