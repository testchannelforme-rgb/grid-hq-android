# Grid HQ 2.0.1 — presentation update

- Launcher label: Grid HQ; versionCode 3, versionName 2.0.1. Package unchanged.
- New original cyan G/grid mark replaces the legacy M icon. No official racing assets.
- Short skippable car drive-by intro while data loads in parallel. Fresh launches show the intro and Discord invitation; rotation, restoration, and returning from Discord do not repeat them.
- Discord invitation has close, Maybe later and Join Discord controls; no permanent dismissal. Join Discord opens the owner-supplied invitation https://discord.gg/yCHkDv9dTK, configured in CommunityConfig.DISCORD_INVITE in LaunchExperience.kt.
- Result/grid save confirmation animates after repository success; synthesized confirmation sound follows media volume and silent mode. Sound and reduced-motion settings persist locally. No audio assets, new permissions, or network audio.
- Cyan dark theme, session status banner, and expanding calendar cards.
- GitHub artifact contains Grid HQ.apk. Archive input filename remains unchanged for repository compatibility.
- No database or backup schema changes. Existing signing-key requirements still apply.

Verification: XML and ZIP structure checked locally. Android build, lint, unit tests and device animation/audio/accessibility checks remain pending GitHub. This source is not a tested APK.

Device checks: fresh launch → intro → invitation; close/back works; no repeat on rotation or returning from browser; restart shows invitation again. Save/edit race and sprint results → confirmation only after successful persistence; invalid/stale saves must not celebrate. Toggle sound, mute device, reduce motion, rotate during intro, test TalkBack and large text. Verify the configured invite opens the intended Discord server on a device.
