# Grid HQ 2.1 polish update

## Changes
- Reference-inspired near-black background (#080C0F), charcoal cards (#11161C/#191D26), red accent (#F32E43), white text; consistent dark Material 3 surfaces.
- Constructor crash: namespaced driver/race lazy-list keys prevent duplicate-ID collisions. Missing entities now show recoverable detail states. Missing driver/team references have display fallbacks.
- Owner-supplied launch MP4, fitted without cropping; static poster fallback, reduced motion, skip animation, real initial-data loading gate and fade into content. Film audio is muted.
- Shared short synthesized interaction cues, system-aware haptics, separate persistent toggles. Silent mode respected; no audio focus request and low playback volume.
- Optional daily local race highlights, randomized local delivery window (08–21 or 10–20), current database read at delivery, notification permission explanation, result/standings navigation.
- Reference-style statistics tiles with advanced graphs, predictions, development and rules retained.
- Home pull-to-refresh, animated standings totals, transitions, long-label handling and bounded tablet content width.
- New scheduling/content/fallback unit tests and constructor/driver/race navigation instrumentation regression tests.

## Compatibility and migration
Application ID remains com.monoposto.championship. Version code 4, version name 2.1.0.
Room remains version 2; existing MIGRATION_1_2 remains registered. No destructive migration. Championship backup format is unchanged. Feedback and notification preferences are device-local and not included in championship exports.
Export a backup from the installed app before installing a new APK. An in-place update requires the same signing certificate as that installed app. GitHub's temporary debug key does not guarantee this; configure the existing GRIDHQ signing secrets to produce an update-compatible APK. Never uninstall to resolve a signing conflict without exporting your data first.

## Notifications
Offline championship recaps, not external live motorsport results. WorkManager checks the day's randomly chosen target in the background, with one notification per local date. No exact-alarm permission. Android Doze, battery restrictions and force-stop can delay or skip delivery. No notifications deliberately sent outside the configured waking window. Notifications are silent so they do not interrupt other audio.

## Validation
CI runs unit tests, Android lint, a debug APK build, Room migration tests and navigation tests on an API 29 emulator. See the actual workflow outcome/reports for executed results; this document is not itself evidence of a passing run.
Physical-device haptic feel, video decoding across all vendors, 60/120fps guarantees and long-running Doze delivery require hardware QA. The reference screenshots do not identify their exact font file or dp scale; typography and spacing are matched visually using Android sans-serif and scalable sp values.

## Repository replacement
Preserve your existing repository history and signing secrets. Replace MonopostoChampionshipManager_COMPLETE.zip and .github/workflows/build-apk.yml, then run the build workflow. The source archive has a GridHQ directory. Download the tested APK only from a successful run for the new commit. Do not copy local.properties or build outputs into source control.
