# GridHQ 2.0 source changes

- Renamed visible app to GridHQ, preserved Android identity and original launcher artwork.
- Added race/sprint session separation, independent configurable rules, DSQ, optional fastest laps and eligibility controls.
- Added saved round notes, optional grid positions, points penalties and independent result deletion.
- Added cumulative points, per-round points and position comparisons for up to four drivers or teams, plus exact round-value cards.
- Added expanded driver/team statistics, season insights, deterministic predictions with factor breakdowns and data-coverage confidence.
- Added optional team development with a finite budget, capped levels, diminishing score gains, history and reset confirmation.
- Added optional GitHub release APK counter with timestamped cache and offline error handling; repository remains unconfigured.
- Added non-destructive Room migration, revision conflict detection, v1/v2 backup compatibility and historical team snapshots.
- Split original monolithic UI into screen files; restored explicit import/export feedback and added first-run backup restore.
- Added saved-state support and discard confirmation for result/grid/note editing.
- Added regression tests, Android migration test and a GitHub workflow that gates APK delivery on tests and lint.

Status: source implementation; Android build and device acceptance are pending. See BUILD_STATUS.md for precise limits.
