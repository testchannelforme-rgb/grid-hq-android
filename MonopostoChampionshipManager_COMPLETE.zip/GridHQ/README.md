# GridHQ 2.0 — source handoff

Offline Android championship tracking for 24 drivers and 12 teams. This is a source implementation awaiting its first Android CI build and device acceptance test, not a verified production release.

The application ID is still `com.monoposto.championship`; versionCode is 2 and versionName is 2.0.0. The visible name is GridHQ. The existing original vector launcher icon is retained. Internal package/theme/database identifiers and the backup-format marker remain unchanged for compatibility. No official game, racing-series, driver or team assets were added.

## Build

The delivery bundle's `build-apk.yml` replaces `.github/workflows/build-apk.yml` in your repository. The workflow expects `MonopostoChampionshipManager_COMPLETE.zip` at the repository root and the `GridHQ/` directory inside it.

The workflow installs Java 17, Android SDK 35 and Gradle 8.9. It regenerates the official Gradle wrapper before executing the project, replacing the inherited custom wrapper. It runs unit tests, lint, debug compilation and Android instrumentation tests. APK upload happens only after those steps succeed. Reports and generated Room schemas upload even when a test fails.

For Android Studio: extract this project, open GridHQ, use JDK 17 and SDK 35. With Gradle 8.9 installed, first run `gradle wrapper --gradle-version 8.9 --distribution-type bin`, then `./gradlew testDebugUnitTest lintDebug assembleDebug`. The APK output is `app/build/outputs/apk/debug/app-debug.apk`.

## Features and navigation

- Home, standings, editable calendar, driver/team editing, custom scoring and JSON backups remain.
- Open a calendar round for race/sprint entry, notes, grid positions and point deductions. Results can be deleted independently of notes.
- Race and sprint have separate scoring rules. Open Stats → Rules for both point tables and fastest-lap eligibility. Main-race countback resolves equal championship totals; sprint wins do not count as main-race wins.
- Stats → Predictions explains each driver's weighted deterministic estimate. Scores are not probabilities, not trained AI and not promises.
- Stats → Trends compares up to four drivers/teams by cumulative points, per-round points or championship position. Round chips and exact-value cards make the chart accessible without relying only on colour.
- Stats → Drivers / Teams contains streaks, reliability, recovery, weekend scoring, contributions and other metrics. Unknown grid positions are blank, not inferred.
- Stats → Development enables a 60-credit budget per team. Six attributes, five levels each, costs of 3/6/9/12/15 credits, diminishing gains. All attributes feed the same equally weighted development score, which contributes at most 4/100 prediction points. No separate mechanical race simulation is claimed. Reset requires confirmation; disabling retains history.
- Main-race result drafts, notes, grid drafts, active route and selected championship have saved-state support. Explicit discard confirmations protect race and note editing. Some older setup dialogs still use transient form state; save these before leaving them.
- First-run screen includes backup import; export/import failures now surface to the user.

## Data architecture

Domain logic lives in `domain/`; persistence and JSON encoding in `data/`; Compose screens in `ui/screens/`. Screen files retain the application package to preserve access to shared composables. MainActivity only hosts the UI.

Room v2 adds one non-null `payload` column to the championship row. An empty payload means “load original v1 normalized tables.” After a successful edit, the versioned aggregate JSON becomes authoritative. Legacy child tables remain intact but are no longer the authority for edited championships. This approach avoids destructive replacement of original records during migration. All v2 saves are one transactional upsert with optimistic revision checks. It is suitable for bounded 100-round local seasons; normalizing v2 fields further is a future optimization, not a prerequisite for this data volume.

See MIGRATION_AND_SIGNING.md before installing. Never uninstall the old app before exporting every championship.

## Download counter configuration

Set `PUBLIC_RELEASE_REPOSITORY` in `data/DownloadCounter.kt` to the public `owner/repository` that hosts release APKs. It is deliberately empty because no public release URL was supplied. No private token belongs in the app.

The counter totals `.apk` release-asset downloads across paginated releases. It excludes workflow artifacts and is not a unique-user count. It refreshes only on request and reuses cache for 15 minutes. Offline or API failures retain the previous count and show an error. The only new permission is INTERNET; the championship features work offline. No accounts, advertising or tracking were added.

## Definitions and limitations

- Main-race wins/podiums/averages and sprint wins/podiums are distinct. Championship points include both.
- Average classified finish and consistency exclude DNF/DNS/DSQ. Consistency = max(0, 1 − population standard deviation / 11.5), shown out of 100, with at least two classified finishes.
- DNF percentage divides DNFs by main-race starts; DNS does not start, DSQ does. Reliability/finish rate means classified finishes divided by starts.
- Current/longest streaks follow recorded main races in round order; DNS and non-scoring results break the relevant streak. Upcoming rounds are omitted.
- Grid P1 starts are not called qualifying poles. Recovery uses grid minus classified finish; without grid data it is unavailable. No timing data exists, so closest timed finishes and winning margins are omitted.
- Most improved compares first two versus last two starts, treating DNF/DSQ as P24. The overview's smallest points gap is explicitly not a timing gap.
- Development is a lightweight manual planning layer, not an economy or simulator. Attributes affect predictions only, equally; they do not alter reliability outcomes or stored results.
- Charts show recorded weekends only, including sprint-only weekends. A zero-point completed round appears. Deleted sessions stop contributing; complete removal of all sessions omits that weekend.
- All-time transfer histories predating this update cannot be recovered. On first load/import, old results inherit current team assignments; subsequent transfers preserve those snapshots.
- Android compilation, instrumented migration validation, screen rendering, accessibility and phone/tablet interaction testing still require the GitHub run and actual devices.

Reference APIs: https://developer.android.com/develop/ui/compose/state-saving and https://github.com/ReactiveCircus/android-emulator-runner .
