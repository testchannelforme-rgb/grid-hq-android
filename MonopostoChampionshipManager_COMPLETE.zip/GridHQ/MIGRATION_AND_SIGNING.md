# Migration and signing

## Before installation

In the currently installed app, open Settings → Export championship for each season. Keep the JSON files outside the app. This is the pre-migration export option; a new app cannot show a prompt before its first database open unless its startup is redesigned around the old database.

Do not uninstall v1 to resolve an installation error until those backups are safely exported. Android uninstall removes the local database (the original manifest disables Android automatic backup).

## Database

Migration 1 → 2 executes only:

```sql
ALTER TABLE championships ADD COLUMN payload TEXT NOT NULL DEFAULT '';
```

No table is dropped or cleared. Empty payload loads all legacy tables. First v2 edit validates, recalculates and atomically upserts the authoritative version-2 JSON payload, incrementing its revision. Legacy child rows are retained. Subsequent reads use payload; downgrading to v1 is unsupported and would not reflect v2 edits. Revision conflicts show an error instead of replacing another edit.

The database remains `monoposto_championship.db`. There is no destructive migration fallback. Room schema export is enabled; CI saves the generated schema. The instrumented test creates the actual v1 table definitions, inserts a full championship, opens with Room migration, verifies results and tests a v2 save plus stale-write rejection.

Backup JSON accepts format versions 1 and 2 and exports version 2. The original format marker is preserved deliberately. Imports receive new IDs and revision 0. Notes, scoring, grid, penalties, sprint results, historical teams and development history round-trip in v2. Version 1 defaults to no sprint and disabled development.

Historical team assignments missing in v1 are frozen using the assignments currently available on the device/import. They cannot reconstruct transfers made before v2. Invalid DNS/DSQ fastest-lap selections are rejected; correcting them removes any wrongly awarded fastest-lap bonus. All ordinary race scoring remains configurable.

## Install-over compatibility

Package: `com.monoposto.championship` (unchanged).
Version: code 2 / name 2.0.0.

An update also requires the exact original signing key. The old GitHub workflow did not preserve a key, so compatibility cannot be guaranteed. An APK contains a certificate, not the recoverable signing private key. The original project ZIP does not include a signing keystore.

If you have the original keystore, configure these repository Actions secrets:

- GRIDHQ_KEYSTORE_BASE64: base64 of the original keystore file.
- GRIDHQ_KEYSTORE_PASSWORD
- GRIDHQ_KEY_ALIAS
- GRIDHQ_KEY_PASSWORD

Do not paste secret values into chats, source files or workflow YAML. The workflow decodes the key only in the ephemeral runner and never uploads it.

Without those secrets the workflow builds a temporary debug-signed APK. It is suitable for testing, but may not update existing installs and its key may change on a later run. Before a public release, establish and retain a stable signing key securely. An optional test install can be performed on a separate device/emulator without touching the original installation.

Only compare APK signing certificates or perform a backed-up installation test to confirm compatibility. It is not confirmed for this handoff.
